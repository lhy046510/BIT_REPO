from ..utils import bitly, xbmcutil
from . import veetle

def addStreams():
    pBar = xbmcutil.createProgressBar('Dutch Sports Streams', 'Laden van streams...')

    xbmcutil.updateProgressBar(pBar, 49, 'LMMG - Stream 1')
    lmmg1 = bitly.getLink('lmmg1')
    veetle.addChannel('LaatMijMaarGaan - Stream 1', lmmg1)

    xbmcutil.updateProgressBar(pBar, 98, 'LMMG - Stream 2')
    lmmg2 = bitly.getLink('lmmg2')
    veetle.addChannel('LaatMijMaarGaan - Stream 2', lmmg2)

    xbmcutil.updateProgressBar(pBar, 100,'Gereed!')
    xbmcutil.endOfList()