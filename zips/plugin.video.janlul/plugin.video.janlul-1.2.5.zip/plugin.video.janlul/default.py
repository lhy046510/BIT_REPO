import sys, urllib2, urllib
#import janlul, dazsports, dscplus, ads, stv, sopcast
#import stream, bitly
import xbmcgui
import xbmcplugin, xbmcaddon
import urlparse
import paths

import socket, sys

from lib.streams import *
from lib.utils import *

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

pDialog = xbmcgui.DialogProgress()
_PERCENT_ = 0
progIncrease = 19

xbmcplugin.setContent(addon_handle, 'movies')

addon = xbmcaddon.Addon('plugin.video.janlul')
newFeatures = addon.getSetting('newFeatures')

def addSubMenu(internal, readable):
    print 'adding ' + internal
    url = build_url({'site': internal})
    icon = getIcon(internal)
    li = xbmcgui.ListItem(label=readable, iconImage=icon, thumbnailImage=icon)
    fanart = getFanart(internal)
    li.setProperty('fanart_image',fanart)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

def mainMenu():
    addSubMenu('janlul', 'JanLul Streams')
    addSubMenu('dsc','DSC+ Streams')
    addSubMenu('daz','DazSports Streams')
    addSubMenu('ads','Achterdijn Sports')
    addSubMenu('stv','STV Streams')
    addSubMenu('13stream', '13th stream')
    addSubMenu('bvls','BVLS Streams - [COLOR green]NEW[/COLOR]')
    addSubMenu('lmmg','LMMG Streams - [COLOR green]NEW[/COLOR]')
    if newFeatures == "true":
        addSubMenu('hdstreams','HD Streams - [COLOR red]Unsupported[/COLOR]')
    addDummyItem('')
    addDummyItem('Facebook: www.facebook.com/xbmcdss', True, 'facebook')
    addDummyItem('[COLOR green]Online Stream[/COLOR]')
    addDummyItem('[COLOR red]Offline Stream[/COLOR]')
    xbmcplugin.endOfDirectory(addon_handle)

def getIcon(streamer):
    icon = os.path.join(paths.iconDir, streamer+'.png')
    return icon
	
def getFanart(streamer):
    fanart = os.path.join(paths.fanartDir, streamer+'.jpg')
    if os.path.isfile(fanart) :
        fanart = fanart
    else :
        fanart = os.path.join(paths.fanartDir, 'newyear.jpg')
    return fanart

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)
    
def addDummyItem(labelString, icon=False, iconName = '', fanart=False, fanartName=''):
    if icon:
        iconimg = getIcon(iconName)
        li = xbmcgui.ListItem(label=labelString, iconImage=iconimg, thumbnailImage=iconimg)
    else:
        li = xbmcgui.ListItem(label=labelString)

    li.setProperty('IsPlayable','false')
    if fanart:
        fanartimg = getFanart(fanartName)
        li.setProperty('fanart_image',fanartimg)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url='plugin://plugin.video.janlul/none', listitem=li)

argSite = args.get('site', None)
playUrl = args.get('play', None)
p2pMode = args.get('mode', None)
streamName = args.get('streamName', None)

if argSite is None:
    if playUrl is None :
        mainMenu()
    else :
        if p2pMode is not None :
            playUrl[0] = str(playUrl[0]) + "&mode=" + str(p2pMode[0])
        while xbmc.Player().isPlaying():
            xbmc.Player().stop()
            xbmc.sleep(5)
        pl=xbmc.PlayList(1)
        pl.clear()
        #credits = os.path.join(paths.videoDir, 'credits.mp4')
        #li = xbmcgui.ListItem('Credits')
        #li.setProperty('IsPlayable','true')
        #xbmc.PlayList(1).add(credits, li)
        li = xbmcgui.ListItem(str(streamName[0]))
        li.setProperty('IsPlayable', 'true')
        xbmc.PlayList(1).add(str(playUrl[0]), li)
        xbmc.Player().play(pl)
else:
    site = argSite[0]
    pDialog.create('Dutch Sports Streams', 'Laden van streams...')
    if site == 'janlul':
        janlul.addStreams()
    elif site == 'daz':
        dazsports.addStreams()
    elif site == 'dsc':
        dscplus.addStreams()
    elif site == 'ads':
        ads.addStreams()
    elif site == 'stv':
        stv.addStreams()
    elif site == 'ctv':
        ctv.addStreams()
    elif site == 'lmmg':
        lmmg.addStreams()
    elif site == 'bvls':
        bvls.addStreams()
    elif site == '13stream':
        sopcast.add13Stream()
    elif site == 'hdstreams':
        sopcast.addStreams()
    else:
        mainMenu()

    xbmcplugin.endOfDirectory(addon_handle)