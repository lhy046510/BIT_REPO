# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu

#!/usr/bin/python
# -*- coding: utf-8 -*-         #print ""+url
# Copyright (c) 2013
# Writer (c) 2013, xbmcTR Team by HappyFeets
# Turkiye, E-mail: androidmkersco@gmail.com

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="UK_TV"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


action='rtmpe://209.95.34.58:1935/live/action pageUrl=http://www.hdcast.org/hpg_disco token=#yw%tt#w@kku'
great='rtmpe://209.95.34.58:1935/live/greats pageUrl=http://www.hdcast.org/hpg_disco token=#yw%tt#w@kku'
premier='rtmpe://209.95.34.58:1935/live/premierx pageUrl=http://www.hdcast.org/hpg_disco token=#yw%tt#w@kku'
scifi='rtmpe://209.95.34.58:1935/live/scifi pageUrl=http://www.hdcast.org/hpg_disco token=#yw%tt#w@kku'
thril='rtmpe://209.95.34.58:1935/live/thriller pageUrl=http://www.hdcast.org/hpg_disco token=#yw%tt#w@kku'

actionth='http://skysport.tv/movie/images/movieact.png'
greatth='http://skysport.tv/movie/images/moviegrt.png'
premierth='http://skysport.tv/movie/images/movieprem.png'
scifith='http://skysport.tv/movie/images/moviescifi.png'
thrilth='http://skysport.tv/movie/images/movietri.png'

liveth='http://www.planet-london.com/images/liveandstreaming.jpg'

atlath='https://pbs.twimg.com/profile_images/413603704357392384/fpEWiU6t_400x400.jpeg'

def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul   
        #url='http://en.iphone-tv.eu/channels/it'
        hasbah='http://freelifetv.blogspot.co.uk/2014/03/england-channel-for-vlc-and-simpletv.html'
        benim='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L3NreS54bWw='

        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR blue][B]Sky Movies Action [/B][/COLOR]', "oynat(name,url)",action,actionth)
        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR pink][B]Sky Movies Moders Greats [/B][/COLOR]', "oynat(name,url)",great,greatth)
        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR blue][B]Sky Movies Premier [/B][/COLOR]', "oynat(name,url)",premier,premierth)
        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR pink][B]Sky Movies Scifi & Horror [/B][/COLOR]', "oynat(name,url)",scifi,scifith)
        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR blue][B]Sky Movies Crime & Thriller [/B][/COLOR]', "oynat(name,url)",thril,thrilth)
##        araclar.addDir(fileName,'[COLOR gold][B]>>[/B][/COLOR] [COLOR beige][B]Atlantic and Moore [/B][/COLOR]', "benim(url)",(base64.b64decode(benim)),atlath)
        link=araclar.get_url(hasbah)
        match=re.compile('#EXTINF:-1,(.*?)\n(.*?)\n').findall(link)
        for name,url in match:
            araclar.addDir(fileName,'[COLOR lightblue][B]>> [/COLOR][COLOR lightgreen]'+ name+'[/B][/COLOR]','oynat(name,url)',url,'special://home/addons/plugin.video.dream-clup/resources/images/UK_LiveTV.png')
##        link=araclar.get_url(url)
##        link=link.replace('amp;','')
##        match=re.compile('<a href="(.*?)" title=".*?"><img src=".*?" width="90" height="80" alt="(.*?)"></a>\n').findall(link)
##        for url,name in match:
##                url='http://en.iphone-tv.eu/'+url
##                araclar.addDir(fileName,'[COLOR blue]>> [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]',url,2,ithumb)

def yeni(url):#1
        link=araclar.get_url(url)
        match=re.compile('id="iframe" src="(.*?)" ').findall(link)
        for url2 in match:
                print url2
                link=araclar.get_url(url2)
                match=re.compile('id="iframe" src="(.*?)" ').findall(link)
                for url3 in match:
                        print url3
                        link=araclar.get_url(url3)
                        match=re.compile('fid=\'(.*?)\'').findall(link)
                        for idi in match:
                                name='[COLOR pink]>> inizio [/COLOR]'
                                url='rtmp://31.220.0.134:1935/live playpath='+idi+' swfUrl=http://www.eucast.tv/ePlayerr.swf token=%ZZri(nKa@#Z pageUrl=http://www.flashtv.co/embed.php?live='+idi+'&vw=620&vh=490 live=1'
        #                        rtmp://31.220.0.134:1935/live playpath=skycalcioit swfUrl=http://www.eucast.tv/ePlayerr.swf token=%ZZri(nKa@#Z pageUrl=http://www.eucast.tv/embed.php?live=skycalcioit&vw=620&vh=490 live=1
                                #rtmp://31.220.0.195:1935/live playpath=sky1ita swfUrl=http://www.flashtv.co/ePlayerr.swf pageUrl=http://www.flashtv.co/embed.php?live=sky1ita&vw=620&vh=490 live=1
                                playList.clear()
                                playList.add(name)
                                araclar.addLink(name,url,'http://www.fornokia.net/data/programs/images/31790004_256x256-192x192__programView1_8225.jpg')
                        if playList:
                                xbmcPlayer.play(playList)
               
def boblisteicerik(url):#2
        link=araclar.get_url(url)
        match=re.compile('var\|(.*?)\|(.*?)\|(.*?)\|1345\|auth\|eu\|http\|streamURL\|ipm\|iphone\|tv\|\|(.*?)\|.*?').findall(link)
        for index,m3,kanal,token in match:
                name='[COLOR pink]>> inizio [/COLOR]'
                m3='.'+m3+'?c='
                token='&auth='+token+'&gts=false'
                url='http://ipm.iphone-tv.eu:1345/'+index+m3+kanal+token
                playList.clear()
                playList.add(name)
                araclar.addLink(name,url,'http://www.fornokia.net/data/programs/images/31790004_256x256-192x192__programView1_8225.jpg')
        if playList:
                xbmcPlayer.play(playList)

def benim(url):
        link=araclar.get_url(url)
        match=re.compile('#EXTINF:-1,(.*?)\n(.*?)\n').findall(link)
        for name,url in match:
                araclar.addDir(fileName,'[COLOR lightblue][B]>> [/COLOR][COLOR lightgreen]'+ name+'[/B][/COLOR]','oynat(name,url)',url,'special://home/addons/plugin.video.dream-clup/resources/images/UK_LiveTV.png')
                
        

def oynat(name,url):#4
        playList.clear()        
        araclar.addLink(name,url,'http://www.planet-london.com/images/liveandstreaming.jpg')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList) 
                


##        if match >0:
##                del match[0]

