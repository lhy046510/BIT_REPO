# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu,urlresolver

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Box_Office_FRAGMANLAR"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


urlt='http://oneonethreeeight.files.wordpress.com/2011/09/box-office.gif'
cst='http://tognacci.com/images/coming-soon-sign.jpg'

def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul  
        url='http://www.showcasecinemas.co.uk/films/now-booking'
        cs='http://www.showcasecinemas.co.uk/films/coming-soon'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR blue][B]Latest Movies [COLOR lightyellow] / [COLOR red] Sinemada Bu Hafta [/B][/COLOR]', "urll(url)",url,urlt)
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Coming SOON [COLOR lightyellow] / [COLOR orange] Yakinda Sinemalarda [/B][/COLOR]', "csicerik(url)",cs,cst)

def urll(url):
        link=araclar.get_url(url)
        match=re.compile(' href="(.*?)"><img id=".*?" class="imgItem" OnError=".*?" src="/images/(.*?)" alt="(.*?)"').findall(link)
        for url,t,name in match:
                url='http://www.showcasecinemas.co.uk/films/'+url
                t='http://www.showcasecinemas.co.uk/images/'+t

        match1=re.compile(' href="(.*?)"><img id=".*?" class="imgItem" OnError=" this.src=&#39;/Global/img/Empty.png&#39;;" src="http://images.mymovies.net/(.*?)" alt="(.*?)"').findall(link)
        for url,t,name in match1:
                url='http://www.showcasecinemas.co.uk/films/'+url
                t='http://images.mymovies.net/'+t
                araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]','icerik(url)',url,t)

def icerik(url):
    link=araclar.get_url(url)
    thumb=re.compile(' src="/images/(.*?)"').findall(link)
    for t in thumb:
            t='http://www.showcasecinemas.co.uk/images/'+t

    mymovies=re.compile('" src="http://images.mymovies.net/(.*?)" ').findall(link)
    for t in mymovies:
            t='http://images.mymovies.net/'+t

    na=re.compile('<li class="releaseDateListItem"><span>Release</span>(.*?)</li>\r\n').findall(link)
    for name in na:
            name=name+'[COLOR red]'+' Sinemalarda '+'[/COLOR]'
    
    match=re.compile('<source src=\'(.*?).mp4\'').findall(link)
    for url in match:
            url=url+'.mp4'
            araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+' Watch Trailer[/B][/COLOR]','oynat(name,url)',url,t)

    info=re.compile('<h1 id="cph_mainPlaceholder_ctrlFilmSynopsisControl_lblFilmName" itemprop="name">(.*?)</h1>').findall(link)
    for infoo in info:
            url='http://afdah.com/?s='+infoo+'&x=7&y=16&type=title'
            name='Filmi izle / Watch Movie'
            araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR orange][B]'+name+'[/B][/COLOR]','Yeni(url)',url,t)



def csicerik(url):
        link=araclar.get_url(url)
        match=re.compile(' href="(.*?)"><img id=".*?" class="imgItem" OnError=" this.src=&#39;/Global/img/Empty.png&#39;;" src="/images/(.*?)" alt="(.*?)"').findall(link)
        for url,t,name in match:
                url='http://www.showcasecinemas.co.uk/films/'+url
                t='http://www.showcasecinemas.co.uk/images/'+t

        match1=re.compile(' href="(.*?)"><img id=".*?" class="imgItem" OnError=" this.src=&#39;/Global/img/Empty.png&#39;;" src="http://images.mymovies.net/(.*?)" alt="(.*?)"').findall(link)
        for url,t,name in match1:
                url='http://www.showcasecinemas.co.uk/films/'+url
                t='http://images.mymovies.net/'+t
                araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]','cssicerik(url)',url,t)

def cssicerik(url):#2
    link=araclar.get_url(url)          
    thumb=re.compile(' src="/images/(.*?)"').findall(link)
    for t in thumb:
            t='http://www.showcasecinemas.co.uk/images/'+t

    mymovies=re.compile('" src="http://images.mymovies.net/(.*?)" ').findall(link)
    for t in mymovies:
            t='http://images.mymovies.net/'+t

    na=re.compile('<li class="releaseDateListItem"><span>Release</span>(.*?)</li>\r\n').findall(link)
    for name in na:
            name=name+'[COLOR red]'+' <<< Cikis Tarihi '+'[/COLOR]'
            print name
    
    match=re.compile('<source src=\'(.*?).mp4\'').findall(link)
    for url in match:
            url=url+'.mp4'
            araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+' Watch Trailer[/B][/COLOR]','oynat(name,url)',url,t)

    info=re.compile('<h1 id="cph_mainPlaceholder_ctrlFilmSynopsisControl_lblFilmName" itemprop="name">(.*?)</h1>').findall(link)
    for infoo in info:
            url='http://afdah.com/?s='+infoo+'&x=7&y=16&type=title'
            print url,'AAAQQQRRR'
            name='Filmi izle / Watch Movie'
            araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR orange][B]'+name+'[/B][/COLOR]','Yeni(url)',url,t)


##def Search():
##        keyboard = xbmc.Keyboard("", 'Search', False)
##        keyboard.doModal()
##        if keyboard.isConfirmed():
##            query = keyboard.getText()
##            query =query.replace(' ','+')
##            url = ('http://afdah.com/?s='+query+'&x=0&y=0&type=title')
##            Yeni(url)


def Search():
        query=infoo
        
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://afdah.com/?s='+query+'&x=7&y=16&type=title')
            Yeni(url) 
          

def Yeni(url):
    link=araclar.get_url(url)
    match=re.compile('<img src="(.*?)s.jpg" width=".*?" height=".*?" alt="(.*?)" /></a></div><h3 class="entry-title"><a href="(.*?)"').findall(link)
    if match:
        
            
        for t,name,url in match:
                t='http://afdah.com'+t+'.jpg'#
                araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]','ayris(url)',url,t)

    if not match:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(fileName,"Site uyarisi","     Film Siteye henuz yuklenmedi   ","  Yayinlandiktan sonra yüklenecektir.  ")
        return False  


def ayris(url):
    link=araclar.get_url(url)    
    match=re.compile('<img src="/player/bullet.gif" border="0"> (.*?)</td><td style="text-align:center;">(.*?)</td><td style="width:100px;"><a rel="nofollow" href="(.*?)"').findall(link)
    for name,iki,url in match:
            name=name+'  '+'[COLOR orange]'+iki+'[/COLOR]'
            name=name.replace('.com','').replace('.net','').replace('.eu','').replace('.sx','').replace('.me','').replace('.is','').replace('.es','').replace('.in','')
            araclar.addDir(fileName,name,'UrlResolver_Player(name,url)',url,"http://afdah.com/player/play_video.gif")

def UrlResolver_Player(name,url):
##        safe='aHR0cDovL3hibWN0ci50di8='
##        link=araclar.get_url(base64.b64decode(safe))
##        match1=re.compile('sir>>(.*?)<<be').findall(link)
##        for kkk in match1:
##                print kkk
    UrlResolverPlayer = url
    playList.clear()
    media = urlresolver.HostedMediaFile(UrlResolverPlayer)
    source = media
    if source:
            url = source.resolve()
            araclar.addLink(name,url,'')
            araclar.playlist_yap(playList,name,url)
            xbmcPlayer.play(playList)

def oynat(name,url):
    playList.clear()        
    araclar.addLink(name,url,'http://a4.mzstatic.com/eu/r30/Purple6/v4/72/94/4f/72944fa9-b57c-9287-88e9-f0581dd1fd1b/icon_256.png')
    listitem = xbmcgui.ListItem(name)
    playList.add(url, listitem)
    xbmcPlayer.play(playList) 
