# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,urlresolver,base64
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="LOAD7"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


############# ANA GIRIS KLASORLERI ##############################
def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        url='http://loads7.com/'
        #araclar.addDir(fileName,name,"mode(name,url)",url,thumbnail)
        araclar.addDir(fileName,'[COLOR gold][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR gold][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Load7Search()", "","special://home/addons/plugin.video.Test/resources/images/search.png")

        ##### KATEGORILERI OKU EKLE ##########################
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("td", {"style": "width:100%"})
        liste=BeautifulSoup(str(panel))
        for td in liste.findAll('td'):
                a=td.find('a')
                url= a['href']
                name= td.text
                name=name.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR gold][B]>>[/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]', "Yeni(url)",url,"")


def Yeni(url):
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("td", {"class": "archiveEntries"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "eMessage"})
        for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('a')['href']
                name=replace_fix(name)
                name=name_fix(name)
                thumbnailgelen=panel[i].find('p')
                thumbnail=thumbnailgelen.find('img')['src'].encode('utf-8', 'ignore')
                thumbnail=replace_fix(thumbnail)
                thumbnail='http://loads7.com/'+thumbnail
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"Linkler(url)",url,thumbnail)
                

                         

        page=re.compile('<span>.*?</span></b> <a href="(.*?)" onclick=".*?">(.*?)</a>').findall(link)        
        for url,name in page:
                araclar.addDir(fileName,'[COLOR purple][B]>>'+'Sayfa ' + name+'[/B][/COLOR]',"Yeni(url)",url,"special://home/addons/plugin.video.Test/resources/images/sonrakisayfa.png")

def Load7Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=name_fix(query)
			
        try:
            araclar.addDir(fileName,'[COLOR blue][B]-----LOADS7-----[/B][/COLOR]', "","","Search")
            Url = ('http://loads7.com/search/?q='+query)
            link=araclar.get_url(Url)
            soup = BeautifulSoup(link)
            panel = soup.findAll("td", {"valign": "top", "style": "padding:0px 10px 0px 10px;", },smartQuotesTo=None)
            panel = panel[0].findAll("div", {"class": "eTitle"})
            for i in range (len (panel)):
                    url=panel[i].find('a')['href']
                    name=panel[i].find('a').text
                    araclar.addDir(fileName,'[COLOR lightgreen][B]>> -'+name+'[/B][/COLOR]', "Linkler(url)",url,'')
        except:
            xbmc.executebuiltin('Notification("[COLOR yellow][B]xbmcTR[/B][/COLOR]","[COLOR yellow][B]Loads7 Acilamadi[/B][/COLOR]")')

def Linkler(url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        link=araclar.get_url(url)
        match=re.compile('http:\/\/streamcloud.eu\/(.*?)"').findall(link)
        for url in match:
                url='http://streamcloud.eu/'+url
                print url
                araclar.addDir(fileName,'Streamcloud >>',"cozucu.magix_player(name,url)",url,'')
        match1=re.compile('http://www.nowvideo.sx/video/(.*?)"').findall(link)
        for url in match1:
                url='http://www.nowvideo.sx/video/'+url
                araclar.addDir(fileName,'NowVideo >>',"cozucu.magix_player(name,url)",url,'')
        match3=re.compile('http:\/\/www.movshare.net\/video\/(.*?)"').findall(link)
        for url in match3:
                url='http://www.movshare.net/video/'+url
                araclar.addDir(fileName,'MoVShr >>',"cozucu.magix_player(name,url)",url,'')
        match4=re.compile('"http:\/\/www.youtube.com\/embed\/(.*?)\?').findall(link)
        for url in match4:
                url='http://www.youtube.com/embed/'+url
                araclar.addDir(fileName,'YouTube >>',"cozucu.magix_player(name,url)",url,'')
              
##def streamcloud(name,url):
##        playList.clear()
##        link=araclar.get_url(url)  
##        match=re.compile('http:\/\/streamcloud.eu\/(.*?).avi.html').findall(link)
##        print match
##        for url in match:
##                url='http://streamcloud.eu/'+url+'.avi.html'
##                print url
##                Sonuc=cozucu.videobul(url)
##                print "donen sonuc",Sonuc
##                if Sonuc=="False":
##                        dialog = xbmcgui.Dialog()
##                        i = dialog.ok(name,"Site uyarisi","     Film Siteye henuz yuklenmedi   ","  Yayinlandiktan sonra yüklenecektir.  ")
##                        return False 
##                else:                                
##                        for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
##                                        araclar.addLink(name,url,'')
##                                        araclar.playlist_yap(playList,name,url) 
##                        xbmcPlayer.play(playList)
##def NowVideo(name,url):
##        playList.clear()
##        link=araclar.get_url(url)  
##        match=re.compile('http://www.nowvideo.eu/video/(.*?)"').findall(link)
##        print match
##        for url in match:
##                url='http://www.nowvideo.eu/video/'+url
##                print url
##                Sonuc=cozucu.videobul(url)
##                print "donen sonuc",Sonuc
##                if Sonuc=="False":
##                        dialog = xbmcgui.Dialog()
##                        i = dialog.ok(name,"Site uyarisi","     Film Siteye henuz yuklenmedi   ","  Yayinlandiktan sonra yüklenecektir.  ")
##                        return False 
##                else:                                
##                        for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
##                                        araclar.addLink(name,url,'')
##                                        araclar.playlist_yap(playList,name,url) 
##                        xbmcPlayer.play(playList)
       


def name_fix(x):        
        x=x.replace('-',' ').replace('_',' ')
        return x[0].capitalize() + x[1:]
        
def replace_fix(x):        
        x=x.replace('&#8211;', '-').replace('&#038;', '&').replace('http://loads7.com/blog/', '').replace('http://loads7.com', '').replace(' ', '')
        return x
       
