# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Film_PALAST"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        FILMSAATI='http://www.filmpalast.to/'
        
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Filme Suche - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<[/B][/COLOR]', "Search()", "","search.png")

        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Neue Filme [/B][/COLOR]', "neuead(url)",FILMSAATI,"yeni")
        link=araclar.get_url(FILMSAATI)
        match=re.compile('<li>  <a href="http://www.filmpalast.to/search/genre/(.*?)">(.*?)</a></li>').findall(link)
        for url,name in match:
                name=name.replace('&#8211','').replace('&','')
                url='http://www.filmpalast.to/search/genre/'+url
                araclar.addDir(fileName,'[COLOR green][B][COLOR red]>[/COLOR]'+name+'[/B][/COLOR]', "neuead2(url)",url,"")
#-----------------#
def neuead(url):
        link=araclar.get_url(url)
        match1=re.compile('<a href="http://www.filmpalast.to/(.*?)" title="(.*?)">\n\t\t       \t   <img src="/files/(.*?)"').findall(link)
        for url,name,thumbnail in match1:
                thumbnail='http://www.filmpalast.to/files/'+thumbnail
                url='http://www.filmpalast.to/'+url
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url,thumbnail)
                
                #----#
        page=re.compile('<a class="pageing button-small rb active"  >.*?</a> <a  class="pageing button-small rb"  href=(.*?)>(.*?)</a>').findall(link)
        for url,name in page:
                url='http://www.filmpalast.to/'+url
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+ '[COLOR red][B]'+name+'[/B][/COLOR]', "neuead(url)",url,'')
#-----------------#
def neuead2(url):
        link=araclar.get_url(url)
        match1=re.compile('</div>\r\n    <a href="(.*?)" title="(.*?)"> <img src="(.*?)" class="cover-opacity"').findall(link)
        for url,name,thumbnail in match1:
                thumbnail='http://www.filmpalast.to'+thumbnail
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url,thumbnail)
                #------#
        page=re.compile('class="pageing button-small rb active"  >.*?</a> <a  class="pageing button-small rb"   href=\'http://(.*?)\'>(.*?)</a>').findall(link)
        for url,name in page:
                url='http://'+url
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+ '[COLOR red][B]'+name+'[/B][/COLOR]', "neuead2(url)",url,'')
                #-----#
        page2=re.compile('<a class="pageing button-small rb active"  >.*?</a> <a  class="pageing button-small rb"  href=(.*?)>(.*?)</a>').findall(link)
        for url,name in page2:
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+ '[COLOR red][B]'+name+'[/B][/COLOR]', "neuead2(url)",url,'')
#-----------------#
def ayrisdirma(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        link=araclar.get_url(url)
        match3=re.compile('target="_blank" href="http:\/\/(.*?)\/(.*?)" >').findall(link)
        for name,a in match3:
                

                url='http://'+name+'/'+a
                araclar.addDir(fileName,'[COLOR red][B]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,"")
#-----------------#          
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://www.filmpalast.to/search/title/'+query)
            neuead2(url)
#-----------@xbmctrTeam---------------------------------#


