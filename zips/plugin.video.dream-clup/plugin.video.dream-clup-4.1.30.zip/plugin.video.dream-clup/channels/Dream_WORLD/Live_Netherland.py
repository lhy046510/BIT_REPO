# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


import araclar,cozucu
addon_id = 'plugin.video.dream-clup'
__settings__ = xbmcaddon.Addon(id=addon_id)
__language__ = __settings__.getLocalizedString


fileName="Live_Netherland"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

t='http://www.fornokia.net/data/programs/images/31790006_256x256-192x192__programView1_8226.jpg'

def main():
        hasbah='aHR0cDovLzAxLmdlbi50ci9IYXNCYWhDYV9JUFRWL0hvbGxhbmQubTN1'
        #araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR lightgreen][B] German TV List [/B][/COLOR]', "hasbah(url)", hasbah,yenit)
        #araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B] Your TV List [/B][/COLOR]', "Livee(url)", Live,"http://1.bp.blogspot.com/-P1ykZvW7YQs/Tcg_hZHZ-xI/AAAAAAAAAt8/jB8Cx2KQfv8/s1600/Wallpaper+Flag+of+Romania.jpg")
        link=araclar.get_url(base64.b64decode(hasbah))
        link=link.replace('rtmp://$OPT:rtmp-raw=',"")
        match=re.compile('#EXTINF:-.*?,(.*?)\r\n(.*?)\r\n').findall(link)
        if match >0:
                del match[0]

                for name,url in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]>> [/B][/COLOR]'+'[COLOR lightblue][B]' + name+'[/B][/COLOR]',"oynat(name,url)",url,t)             

def oynat(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'http://us.cdn4.123rf.com/168nwm/blueskyimage/blueskyimage1310/blueskyimage131000152/22670734-close-up-of-face-art-netherlands-flag-is-painted-on-woman-face.jpg')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

##################
