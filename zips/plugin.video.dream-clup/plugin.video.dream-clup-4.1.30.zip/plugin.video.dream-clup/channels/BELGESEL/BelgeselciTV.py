# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS
import araclar,cozucu


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="BelgeselciTV"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
    url='http://www.belgeselci.tv/'
    link=araclar.get_url(url)
    match=re.compile('\r\n<a href="http:\/\/www.belgeselci.tv\/kategori\/(.*?)" title=".*?">(.*?)</a>').findall(link)
    for url,name in match:
        url='http://www.belgeselci.tv/kategori/'+url
        araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>>> [/COLOR]'+name+'[/B][/COLOR]', "liste(url)",url,'http://www.belgeselci.tv/logo.png')

def liste(url):
    link=araclar.get_url(url)
    match=re.compile('<a href="(.*?)" title=".*?"><img src=\'(.*?)\' width="136" height="110" alt="(.*?)" />').findall(link)
    for url,thumbnail,name in match:
        araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>>> [/COLOR]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url,thumbnail)
    page=re.compile('Sayfalar: </strong><span>.*?</span><a href="/kategori/(.*?)">().*?</a>').findall(link)
    for url,name in page:
        url='http://www.belgeselci.tv/kategori/'+url
        araclar.addDir(fileName,'[COLOR beige][B][COLOR blue]>>> Sonraki Sayfa [/COLOR]'+name+'[/B][/COLOR]', "liste(url)",url,'')

def ayrisdirma(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
    link=araclar.get_url(url)
    match=re.compile('src="http://vk.com/(.*?)"').findall(link)
    for vk in match:
            vk=''
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>VK Video   '+name+'[/COLOR]', "VIDEOLINKS2(name,url)",url,"")
    link=araclar.get_url(url)
    match1=re.compile('movieSrc=mail\/(.*?)"').findall(link)
    for mailru in match1:
            mailru=''
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>Mail Ru 1   '+name+'[/COLOR]', "VIDEOLINKS2(name,url)",url,"")
    link=araclar.get_url(url)
    match2=re.compile('<iframe src="http://api.video.mail.ru/videos/embed/mail/(.*?).html"').findall(link)
    for mailru in match2:
            mailru=''
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>Mail Ru 2   '+name+'[/COLOR]', "VIDEOLINKS2(name,url)",url,"")
    link=araclar.get_url(url)
    match2=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
    for dm in match2:
            mailru=''
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>dm   '+name+'[/COLOR]', "VIDEOLINKS2(name,url)",url,"")
    link=araclar.get_url(url)
    match2=re.compile('data="http:\/\/www.belgeselci.tv\/player\/player1.swf\?config\=(.*?)"').findall(link)
    for feleve in match2:

        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        link=araclar.get_url(feleve)       
        you_match=re.compile('<file>http:\/\/www.youtube.com\/watch\?v\=(.*?)</file>').findall(link)
        for url in you_match:
            url='http://www.youtube.com/embed/'+url
            Sonuc=cozucu.videobul(url)
            if Sonuc=="False":
                dialog = xbmcgui.Dialog()
                i = dialog.ok(name,"Site uyarisi","     Film Siteye henuz yuklenmedi   ","  Yayinlandiktan sonra yuklenecektir.  ")
                return False
            else:
                for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
                                araclar.addLink(name,url,'')
                                araclar.playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)
    link=araclar.get_url(url)
    match2=re.compile('<embed src="http:\/\/www.youtube.com\/v\/(.*?)\?version\=3\&feature\=player_detailpage" type=".*?" allowfullscreen=".*?" allowScriptAccess=".*?" width=".*?" height=".*?">').findall(link)
    for yout in match2:
            yout=''
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>yout   '+name+'[/COLOR]', "VIDEOLINKS2(name,url)",url,"")
         
def VIDEOLINKS2(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
    #---------------------------#
    urlList=[]
    #---------------------------#
    playList.clear()
    link=araclar.get_url(url)
    link=link.replace('&amp;', '&').replace('&', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

    #---------------------------------------------#
    vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
    for url in vk_2:
            url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
            cozucu.magix_player(name,url)
    #---------------------------------------------#
    veka=re.compile('value="http:\/\/.*?\/veka.swf\?file\=(.*?)\&otobaslat\=0"').findall(link)
    for url in veka:
            url = 'http://'+str(url).encode('utf-8', 'ignore')
            cozucu.magix_player(name,url)
    #---------------------------------------------#
    divxstage=re.compile('src=\'http://embed.divxstage.eu/(.*?)&').findall(link)
    for url in divxstage:
            url = 'http://embed.divxstage.eu/'+str(url).encode('utf-8', 'ignore')
            cozucu.magix_player(name,url)
        #---------------------------------------------#
    yout=re.compile('<embed src="http:\/\/www.youtube.com\/v\/(.*?)\?version\=3\&feature\=player_detailpage" type=".*?" allowfullscreen=".*?" allowScriptAccess=".*?" width=".*?" height=".*?">').findall(link)
    for url in yout:
            url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
            cozucu.magix_player(name,url)
    #---------------------------------------------#
    movshare=re.compile('src=\'http://embed.movshare.net/(.*?)&').findall(link)
    for url in movshare:
            url = 'http://embed.movshare.net/'+str(url).encode('utf-8', 'ignore')
            cozucu.magix_player(name,url)
    #---------------------------------------------#
    uploadc=re.compile('src="(.*?)uploadc(.*?)"').findall(link)
    for url,uploadcgelen in uploadc:
            url = str(url)+'uploadc'+str(uploadcgelen).encode('utf-8', 'ignore')
            cozucu.magix_player(name,url)
    #---------------------------------------------#
    mailru=re.compilematch=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link)
    for mailrugelen in mailru:
            url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
            #print url
            urlList.append(url)
    #-------------------------------
    dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
    for url in dm:
            url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore')
            cozucu.magix_player(name,url)
    #-------------------------------
    mailru3=re.compile('movieSrc: "(.*?)"').findall(link)
    for mailrugelen in mailru3:
            url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
            urlList.append(url)
    #---------------------------------------------#
    mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link)
    for mailrugelen in mailru2:
            url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
            urlList.append(url)
    #---------------------------------------------#
    video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
    for videodgelen in video:
            url =videogelen
            cozucu.magix_player(name,url)
    #---------------------------------------------#
    divxstage=re.compile('src="(.*?)divxstage(.*?)"').findall(link)
    for url,divxstagegelen in divxstage:
            url = str(url)+'divxstage'+str(divxstagegelen).encode('utf-8', 'ignore')
            cozucu.magix_player(name,url)
    #---------------------------------------------#
    #---------------------------------------------#
    #---------------------------------------------#
    if not urlList:
            match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
            print match
            if match:
                    for url in match:
                            VIDEOLINKS(name,url)
   
    if urlList:
            Sonuc=playerdenetle(name, urlList)
            for name,url in Sonuc:
                    araclar.addLink(name,url,'')
                    listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                    listitem.setInfo('video', {'name': name } )
                    playList.add(url,listitem=listitem)
            xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
