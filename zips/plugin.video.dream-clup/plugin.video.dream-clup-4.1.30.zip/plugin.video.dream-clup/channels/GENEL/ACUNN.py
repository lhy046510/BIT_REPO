# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="ACUNN"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)




macozet='http://www.acunn.com/video/mac-ozetleri'
Komedi='http://www.acunn.com/tum-komedi-videolari'
Spor1='http://www.acunn.com/tum-spor-videolari'
Hayvanlar='http://www.acunn.com/tum-hayvanlar-videolari'
Otomobil='http://www.acunn.com/tum-otomobil-videolari'
Film='http://www.acunn.com/tum-film-ve-tv-videolari'
Cocuklar='http://www.acunn.com/tum-cocuklar-videolari'
Magazin='http://www.acunn.com/tum-insan-videolari'
Videooyun='http://www.acunn.com/tum-oyunlar-videolari'
Kadinca='http://www.acunn.com/tum-kadinca-videolari'
Bilim='http://www.acunn.com/tum-bilim-ve-teknoloji-videolari'
Egitim='http://www.acunn.com/tum-okul-videolari'
Sanat='http://www.acunn.com/tum-sanat-videolari'
Seyahat='http://www.acunn.com/tum-seyahat-videolari'
Televizyon='http://www.acunn.com/tum-televizyon-videolari'
def main():
        acun= 'http://www.acunn.com/'
        spor = 'http://www.acunn.com/spor'
        magazin= 'http://www.acunn.com/haber/magazin'
        sinema='http://www.acunn.com/sinema'
        muzik='http://www.acunn.com/haber/muzik'
        fotogaleri='http://www.acunn.com/galeri'
        saglik='http://www.acunn.com/saglik'
        teknoloji='http://www.acunn.com/haber/teknoloji'
        haber='http://www.acunn.com/haber'
        Yetenek='http://www.acunn.com/yetenek-sizsiniz/videolar#anasayfa'
        Oses='http://www.acunn.com/o-ses-turkiye/videolar#anasayfa'
        survi='http://www.acunn.com/survivor/videolar#anasayfa'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR beige][B]Yarismalar[/B][/COLOR]', "yarismalar()",acun,"yeni")
##        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR beige][B]Super Lig Mac Ozetleri[/B][/COLOR]', "macozetleri(url)",macozet,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR beige][B]Acunn Tum Videolar [/B][/COLOR]', "videolar()",acun,"yeni")
##        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR beige][B]Spor [/B][/COLOR]', "spor(url)",spor,"yeni")
##        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR beige][B]Sinema[/B][/COLOR]', "sinema(url)",sinema,"yeni")
##        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR beige][B]Magazin[/B][/COLOR]', "spor(url)",magazin,"yeni")
##        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR beige][B]Haber[/B][/COLOR]', "spor(url)",haber,"yeni")
##        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR beige][B]Muzik[/B][/COLOR]', "spor(url)",muzik,"yeni")
##        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR beige][B]Saglik[/B][/COLOR]', "saglik(url)",saglik,"yeni")
##        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR beige][B]Teknoloji[/B][/COLOR]', "spor(url)",teknoloji,"yeni")



def yarismalar():
        survi='http://www.acunn.com/video/survivor/kategori/tum-bolumler/17/sayfa/1'
        Yetenek='http://www.acunn.com/yetenek-sizsiniz/videolar#anasayfa'
        Oses='http://www.acunn.com/o-ses-turkiye/videolar#anasayfa'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Survivor [/B][/COLOR]', "OsesIzlenen(url)",survi,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yetenek Sizsiniz Turkiye [/B][/COLOR]', "OsesYeni(url)",Yetenek,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]O Ses Turkiye [/B][/COLOR]', "OsesYeni(url)",Oses,"yeni")


def videolar():
        Yetenek='http://www.acunn.com/yetenek-sizsiniz/videolar#anasayfa'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Komedi [/B][/COLOR]', "videolar2(url)",Komedi,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Spor [/B][/COLOR]', "videolar2(url)",Spor1,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Hayvanlar [/B][/COLOR]', "videolar2(url)",Hayvanlar,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Otomobil[/B][/COLOR]', "videolar2(url)",Otomobil,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Film ve TV [/B][/COLOR]', "videolar2(url)",Film,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Cocuklar [/B][/COLOR]', "videolar2(url)",Cocuklar,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Magazin [/B][/COLOR]', "videolar2(url)",Magazin,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Video Oyunlari [/B][/COLOR]', "videolar2(url)",Videooyun,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Kadinca[/B][/COLOR]', "videolar2(url)",Kadinca,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Bilim ve Teknoloji [/B][/COLOR]', "videolar2(url)",Bilim,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Egitim [/B][/COLOR]', "videolar2(url)",Egitim,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Sanat [/B][/COLOR]', "videolar2(url)",Sanat,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Seyahat [/B][/COLOR]', "videolar2(url)",Seyahat,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Televizyon[/B][/COLOR]', "videolar2(url)",Televizyon,"yeni")


def videolar2(url):
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"class": "arama-cevre"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "video-box"})
        for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('a')['href']
                name=replace_fix(name)
                name=name_fix(name)
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEO(url,name)",url,thumbnail)

        page=re.compile('<a class="number" href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "videolar2(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")

                
def macozetleri(url):
        sinema='http://www.acunn.com/saglik'
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"id": "Left-main"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "text-box"})
        for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('a').text.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "saglikdetay(url)",url,'')


def oses():
        Oses='http://www.acunn.com/o-ses-turkiye/videolar#anasayfa'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]En Yeniler [/B][/COLOR]', "OsesYeni(url)",Oses,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]En Cok Izlenenler [/B][/COLOR]', "OsesIzlenen(url)",Oses,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Bizim Sectiklerimiz [/B][/COLOR]', "OsesBizim(url)",Oses,"yeni")

def OsesYeni(url):     
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"class": "tabresim"},smartQuotesTo=None)
        #panel = panel[0].findAll("div", {"class": "v6-video-part"})
        for i in range (len (panel)):
                url=panel[i].find('a')['href']
                #name=panel[i].find('a').text.encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR cyan]'+name+'[/COLOR]', "VIDEO(url,name)",url,thumbnail)
        


def OsesIzlenen(url):
        link=araclar.get_url(url)
        match=re.compile('src="http://s.acunn.com//upload/shows/survivor/(.*?)" alt="" /></a></div><div class="text-icerik"><a href="(.*?)">(.*?)</a>').findall(link)
        for thumbnail,url,name in match:
                thumbnail='http://s.acunn.com//upload/shows/survivor/'+thumbnail
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEO(url,name)",url,thumbnail)
        page=re.compile('<a class="number" href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "OsesIzlenen(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")

                

def OsesBizim(url):     
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"class": "rightTab"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "v6-video-part"})
        for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('a').text.encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEO(url,name)",url,thumbnail)




def yetenek():
        Yetenek='http://www.acunn.com/yetenek-sizsiniz/videolar#anasayfa'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]En Yeniler [/B][/COLOR]', "OsesYeni(url)",Yetenek,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]En Cok Izlenenler [/B][/COLOR]', "YetenekIzlenen(url)",Yetenek,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Bizim Sectiklerimiz [/B][/COLOR]', "YetenekBizim(url)",Yetenek,"yeni")

def saglik(url):
        sinema='http://www.acunn.com/saglik'
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"class": "saglik_left"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "s-kategori-box"})
        for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "saglikdetay(url)",url,thumbnail)

def saglikdetay(url):
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"class": "saglik_left"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "makaletext"})
        for i in range (len (panel)):
                name=panel[i].find('p').text.encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEO(url,name)",'',thumbnail)   


def sinema(url):
        sinema='http://www.acunn.com/sinema'
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"id": "Left"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "index-list-1"})
        for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "detay(url)",url,thumbnail)


def spor(url):
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"class": "solkutular"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "solkutu"})
        for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "detay(url)",url,thumbnail)

def detay(url):
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"class": "leftpartition"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "detailstext"})
        for i in range (len (panel)):
                name=panel[i].find('p').text.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEO(url,name)",'','')        

def YetenekYeni(url):     
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"class": "middleTab"},smartQuotesTo=None)
       # panel = panel[0].findAll("div", {"class": "tabkutu"})
        for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEO(url,name)",url,thumbnail)
        


def YetenekIzlenen(url):     
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"class": "leftTab"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "tabkutu"})
        for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEO(url,name)",url,thumbnail)

def YetenekBizim(url):     
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"class": "rightTab"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "tabkutu"})
        for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEO(url,name)",url,thumbnail)


def VIDEO(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xf6',"o").replace('&amp;',"&").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")
        response.close()        
        match=re.compile('{VideoUrl: "(.*?)"').findall(link)
        for url in match:
                VIDEOLINKS(name,url)
               # araclar.addDir(fileName,'[COLOR lightyellow][B]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'')


def VIDEOLINKS(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList) 
def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]

def replace_fix(x):        
        x=x.replace('&#8211;', '-').replace('&#038;', '&').replace('&amp;', '&').replace('http://www.acunn.com/video/izle/', '')
        return x
