# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="OSAHNE"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        url='http://www.osahne.com/'  
        araclar.addDir(fileName,'[COLOR red][B]>>  Bilgilendirme  <<[/B][/COLOR] ', "INFO(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/OSAHNE.png')
        link=araclar.get_url(url)
        match=re.compile('<li class=".*?"><a href="(.*?)" title=".*?">(.*?)</a></li>').findall(link)
        for url,name in match:
            url='http://www.osahne.com'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"Yeni(url)",url,'special://home/addons/plugin.video.dream-clup/resources/images/OSAHNE.png')

        araclar.addDir(fileName,'[COLOR yellow][B]>>> Daha Fazla Kategori [/COLOR][/B]','recent(name,url)',url,'special://home/addons/plugin.video.dream-clup/resources/images/OSAHNE.png')

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/230008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xc4\xb1',"i").replace('\xc3\xb6',"O").replace('\xc3\xbc',"u").replace('\xc5\x9f',"s").replace('\xc3\xa7',"c").replace('\xe2\x80\x93',"").replace('\xc4\xb0',"i").replace('&#8211;'," ").replace('&#8211;'," ").replace('\xc5\x9e',"S")#.replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        response.close()
        return link

def Yeni(url):
        link=araclar.get_url(url)  
        match=re.compile('<li class=".*?">\n\t\t\t\t\t<a href="(.*?)" title=".*?">\n\t\t\t\t\t\t<figure>\n\t\t\t\t\t\t\t<span class=".*?">\n\t\t\t\t\t\t\t\t<span>\n\t\t\t\t\t\t\t\t\t<span>\n\t\t\t\t\t\t\t\t\t\t<img src="(.*?)" alt="(.*?)" title=".*?" />').findall(link)
        for url,thumbnail,name in match:
            url='http://www.osahne.com'+url
            araclar.addDir(fileName,'[COLOR orange][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        sayfalama=re.compile('<div class="paging minOval">&nbsp;<strong>.*?</strong>&nbsp;<a href="(.*?)">(.*?)</a>').findall(link) 
        for url,name in sayfalama:
            url='http://www.osahne.com'+url 
            araclar.addDir(fileName,'[COLOR purple][B]'+name+' Sayfa [/B][/COLOR]',"Yeni(url)",url,'')

def recent(name,url):
        link=araclar.get_url(url)
        match=re.compile('<li><a style=".*?" href="(.*?)">(.*?)</a></li>').findall(link)
        for url,name in match:
            url='http://www.osahne.com'+url
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "Yeni(url)",url,'')
                
def VIDEOLINKS(name,url):
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()

                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()

                you_match=re.compile('<iframe width=".*?" height=".*?" src="\/\/www.youtube.com\/embed\/(.*?)\?rel\=0&wmode\=transparent&autoplay\=1&showinfo\=0&modestbranding\=0" frameborder=".*?" allowfullscreen></iframe>').findall(link)
                print you_match
                for code in you_match:
                        yt=('plugin://plugin.video.youtube/?action=play_video&videoid='+str(code))
                        addLink('~~izle~~',yt,'')
                        playList.add(yt)
                xbmcPlayer.play(playList)
                if not xbmcPlayer.isPlayingVideo():
                        d = xbmcgui.Dialog()
                        d.ok('Sunucu Hatasi', 'Aranan Video Bulunamadi.','Baska Video Deneyiniz.')

def INFO(name):
  try:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(name, "[COLOR pink]Unutulmayan, [/COLOR][COLOR yellow]Can Alici[/COLOR] [COLOR pink] SAHNELER.[/COLOR]","!!! [COLOR yellow] Hepsi [/COLOR][COLOR turquoise]Elinizin [/COLOR][COLOR yellow]Altinda. [/COLOR]!!!")
  except:
        
        pass                 

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

