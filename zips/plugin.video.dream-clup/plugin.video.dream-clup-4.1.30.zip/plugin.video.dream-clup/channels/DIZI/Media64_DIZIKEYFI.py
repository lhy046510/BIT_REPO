# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Media64_DIZIKEYFI"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        url='http://www.canlidizihd1.com/'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR blue][B]Dizi Keyfi ( Son Eklenenler )[/B][/COLOR]', "dizikeyfisoneklenenler(url)",url,'http://www.canlidizihd1.com/img/logo1.png')
        link=araclar.get_url(url)
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="(.*?)" title=".*?">(.*?)</a>\n</li>\n\t').findall(link) 
        for url,name in match:
                araclar.addDir(fileName,'[COLOR yellow][B]'+name+'[/B][/COLOR]',"diziizlekategoriicerik(url)",url,'http://www.canlidizihd1.com/img/logo1.png')

def dizikeyfisoneklenenler(url): 
        link=araclar.get_url(url) 
        match=re.compile('<div class="kutu-resim">\n\t\t\t\t\t\t\t\t\t\t    <a href="(.*?)" title=".*?"><img style="border-width: 0px; height: 84px; width: 94px;" src="(.*?)" alt="(.*?)" width="70" height="70"/></a>\n\t\t\t\t\t\t\t\t\t\t  </div>').findall(link)
        for url,thumbnail,name in match:
                araclar.addDir(fileName,'[COLOR blue][B][COLOR red]>>[/COLOR]'+ name+'[/B][/COLOR]', "parts(url)",url,thumbnail) 

def diziizlekategoriicerik(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="kutu">\n\t\t\t           <div class="kutu-resim">\n\t\t\t\t\t\t\t\t\t\t    <a href="(.*?)" title=".*?"><img style="border-width: 0px; height: 84px; width: 94px;" src="(.*?)" alt="(.*?)" width="70" height="70"/></a>\n\t\t').findall(link) 
        for url,thumbnail,name in match:
                araclar.addDir(fileName,'[COLOR red][B]'+name+'[/B][/COLOR]',"parts(url)",url,thumbnail) 
        sayfalama=re.compile('<a class="nextpostslink" href="(.*?)">.*?</a>\n').findall(link) 
        for url in sayfalama:
                name='Sonraki Sayfa' 
                araclar.addDir(fileName,'[COLOR blue][B]'+name+'[/B][/COLOR]',"diziizlekategoriicerik(url)",url,'http://www.canlidizihd1.com/img/logo1.png') 

def parts(url):
        link=araclar.get_url(url)
        match=re.compile('<div id="part">\n<p> <span>(.*?)</span> <a href="(.*?)">').findall(link)
        for name,url in match:
                araclar.addDir(fileName,'[COLOR blue][B][COLOR red]>>[/COLOR]'+ name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'')
        duz=re.compile('asdsadsadas').findall(link)
        print url
        name=' V Server Bulundu'
        araclar.addDir(fileName,'[COLOR blue][B][COLOR red]>>[/COLOR]'+ name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'')

        ##        <iframe src="http://vk.com/video_ext.php?oid=254935785&#038;id=169210882&#038;hash=c76fdb222448bd71&#038;hd=1"




def VIDEOLINKS(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        #---------------------------# 
        urlList=[] 
        #---------------------------# 
        playList.clear() 
        link=araclar.get_url(url) 
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/') 
  
        #---------------------------------------------# 
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link) 
        for url in vk_2: 
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url)#
        #---------------------------------------------# 
        youtube=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link) 
        for url in youtube: 
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #---------------------------------------------# 
        youtube1=re.compile(' value="http://www.youtube.com/v/(.*?)\?.*?"').findall(link) 
        for url in youtube1: 
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        mailru=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link) 
        for mailrugelen in mailru: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                print url 
                urlList.append(url) 
        mailru4=re.compile(' value\="movieSrc\=mail/(.*?)\&autoplay\=0"').findall(link) 
        for mailrugelen in mailru4: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url) 
        #-------------------------------                
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link) 
        for url in dm: 
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #-------------------------------  
        mailru3=re.compile('movieSrc: "(.*?)"').findall(link) 
        for mailrugelen in mailru3: 
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url) 
        #---------------------------------------------# 
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link) 
        for mailrugelen in mailru2: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url) 
        #---------------------------------------------# 
        mailru5=re.compile('<iframe src=\'http://api.video.mail.ru/videos/embed/mail/(.*?).html\'').findall(link) 
        for mailrugelen in mailru5: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url) 
        #---------------------------------------------# 
        video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link) 
        for videodgelen in video: 
                url =videogelen 
                cozucu.magix_player(name,url) 
        if not urlList: 
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link) 
                print match 
                if match: 
                        for url in match: 
                                VIDEOLINKS(name,url) 
         
        if urlList: 
                Sonuc=playerdenetle(name, urlList) 
                for name,url in Sonuc: 
                        araclar.addLink(name,url,'') 
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='') 
                        listitem.setInfo('video', {'name': name } ) 
                        playList.add(url,listitem=listitem) 
                xbmcPlayer.play(playList) 
       
def playerdenetle(name, urlList): 
        value=[] 
        import cozucu 
        for url in urlList if not isinstance(urlList, basestring) else [urlList]: 
  
  
                if "mail.ru" in url: 
                    value.append((name,cozucu.MailRu_Player(url))) 
                      
        if  value: 
            return value 
