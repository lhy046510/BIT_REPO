# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="YABANCIDIZI"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


############# ANA GIRIS KLASORLERI ##############################
def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul 
        #araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","special://home/addons/plugin.video.dream-clup/resources/images/ARAMA_SEARCH.png")
        ##araclar.addDir(fileName,'[COLOR blue][B]>> [/B][/COLOR][COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "Yeni(url)",(base64.b64decode(url)),"special://home/addons/plugin.video.dream-clup/resources/images/XbmcTR_Sinema.png" )
                ##### KATEGORILERI OKU EKLE ##########################
        url='aHR0cDovL3d3dy5oZHlhYmFuY2lkaXppLmNvbS9rYXRlZ29yaS8xL1lhYmFuY2lfRGl6aWxlci8xLmh0bWw='
        link=araclar.get_url(base64.b64decode(url))
        match=re.compile('<img src="(.*?)" width="20" height="20" title=".*?" alt="(.*?)" border="0" />\n        <a href="(.*?)">.*?</a>\n').findall(link)
        for t,name,url in match:
            araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"soupfilm(url)",url,t)

###################################################################                

                                                
########                       
##def Search():
##        keyboard = xbmc.Keyboard("", 'Search', False)
##        keyboard.doModal()
##        if keyboard.isConfirmed():
##            query = keyboard.getText()
##            query=query.replace(' ','+')
##            url = ('http://www.filmbulucu.com/?s='+query)
##            Yeni(url)
##
##############

def soupfilm(url):
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)"><img src="(.*?)" width="90" height="90" title=".*?" alt="(.*?)" /></a>\n').findall(link)
        for url,t,name in match:
                araclar.addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR]'+'[COLOR lightgreen][B]' + name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,t)
        match1=re.compile('<div class="subcategory">\n        <img src="(.*?)" width="20" height="20" title=".*?" alt="(.*?)" border="0" />\n        <a href="(.*?)">.*?</a>\n      </div>\n').findall(link)
        for t,name,url in match1:
                araclar.addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR]'+'[COLOR lightgreen][B]' + name+'[/B][/COLOR]',"sezonicerik(url)",url,t)


def sezonicerik(url):
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)"><img src="(.*?)" width="90" height="90" title=".*?" alt="(.*?)" /></a>\n').findall(link)
        for url,t,name in match:
                araclar.addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR]'+'[COLOR lightgreen][B]' + name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,t)
                
def VIDEOLINKS(name,url):
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

        #---------------------------------------------#
        vk_2=re.compile(' src="https://vk.com/(.*?)\&hd\=.*?"').findall(link)
        for url in vk_2:
                name='[COLOR beige][B][COLOR orange]>>>   [/COLOR] V Server [/B][/COLOR]'
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)        
        #---------------------------------------------#
        youtube=re.compile(' src\="\/\/www.youtube.com\/embed\/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
        #---------------------------------------------#
        mailru=re.compile(' src="http:\/\/videoapi.my.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link)
        for mailrugelen in mailru:
                name='[COLOR beige][B][COLOR green]>>>   [/COLOR] M Server [/B][/COLOR]' 
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                urlList.append(url)
        #-------------------------------
        mailru4=re.compile('<iframe src=\'http://api.video.mail.ru/videos/embed/mail/(.*?).html\'').findall(link)
        for mailrugelen in mailru4:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
        #-------------------------------
        mailru3=re.compile('movieSrc: "(.*?)"').findall(link)
        for mailrugelen in mailru3:
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url)
        #---------------------------------------------#
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
        #---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
