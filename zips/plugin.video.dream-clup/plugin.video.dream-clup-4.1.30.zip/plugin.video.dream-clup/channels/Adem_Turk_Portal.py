# -*- coding: utf-8 -*-
import xbmcplugin,urlresolver,xbmcgui,time,cozucu,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,araclar,base64

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Adem_Turk_Portal"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
urll='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L0FkZW1UdXJrX0VrbGVudGlsZXJpLw=='
def main(): 
        url='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L0FkZW1UdXJrX0VrbGVudGlsZXJpLw=='
        link=araclar.get_url(base64.b64decode(url))
        match=re.compile('<li><a href="(.*?).png"> .*?</a></li>\n').findall(link)
        for url in match:
                name=url
                thumbnail=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')+'.png'
                url=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')+'.xml'
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]''[COLOR pink]'+name+'[/B][/COLOR]', "icerik(url)",url,thumbnail)

def icerik(url):
        link=araclar.get_url(url)
        match=re.compile('<title> (.*?) </title>\r\n    <link>(.*?)</link>\r\n    <thumbnail>(.*?)</thumbnail>\r\n').findall(link)
        for videoTitle,Thumbnail,Url in match:
                addVideoLink(videoTitle,Url,Thumbnail)
        match1=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n    <logo_30x30><!\[CDATA\[(.*?)\]\]></logo_30x30>\n    <description>.*?</description>\n    <stream_url><!\[CDATA\[(.*?)\]\]></stream_url>\n').findall(link)
        for name,thumbnail,url in match1:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)
        match2=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n    <link><!\[CDATA\[(.*?)\]\]></link>\n    <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n').findall(link)
        for videoTitle,Thumbnail,Url in match2:
                addVideoLink(videoTitle,Url,Thumbnail)
        match3=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\r\n    <link><!\[CDATA\[(.*?)\]\]></link>\r\n    <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\r\n').findall(link)
        for videoTitle,Thumbnail,Url in match3:
                addVideoLink(videoTitle,Url,Thumbnail)
        match4=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\r\n    <logo_30x30><!\[CDATA\[(.*?)\]\]></logo_30x30>\r\n    <description>.*?</description>\r\n    <stream_url><!\[CDATA\[(.*?)\]\]></stream_url>\r\n').findall(link)
        for name,thumbnail,url in match4:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "UrlResolver_Player(name,url)",url,thumbnail)
        match5=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\r\n    <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\r\n    <link><!\[CDATA\[(.*?)\]\]></link>\r\n').findall(link)
        for name,thumbnail,url in match5:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "UrlResolver_Player(name,url)",url,thumbnail)

def canli(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def UrlResolver_Player(name,url):
        UrlResolverPlayer = url
        playList.clear()
        media = urlresolver.HostedMediaFile(UrlResolverPlayer)
        source = media
        if source:
                url = source.resolve()
                araclar.addLink(name,url,'')
                araclar.playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xf6',"o").replace('&amp;',"&").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")
        link=link.replace('\xc5\x9f',"s").replace('&#038;',"&").replace('&#8217;',"'").replace('\xc3\xbc',"u").replace('\xc3\x87',"C").replace('\xc4\xb1',"?").replace('&#8211;',"-").replace('\xc3\xa7',"c").replace('\xc3\x96',"O").replace('\xc5\x9e',"S").replace('\xc3\xb6',"o").replace('\xc4\x9f',"g").replace('\xc4\xb0',"I").replace('\xe2\x80\x93',"-")
        response.close()
        return link

def addFolder(FILENAME, videoTitle, method, url="", thumbnail="",fanart=""):
        u = sys.argv[0]+"?fileName="+urllib.quote_plus(FILENAME)+"&videoTitle="+urllib.quote_plus(videoTitle)+"&method="+urllib.quote_plus(method)+"&url="+urllib.quote_plus(url)+"&fanart="+urllib.quote_plus(fanart)
        if thumbnail != "":
                thumbnail = os.path.join(IMAGES_PATH, thumbnail+".png")
        liz = xbmcgui.ListItem(videoTitle, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
        liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
        liz.setProperty( "Fanart_Image", fanart )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    

def addVideoLink(linkTitle, url, thumbnail=""):
    liz = xbmcgui.ListItem(linkTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
    liz.setInfo(type="Video", infoLabels={"Title":linkTitle})
    liz.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)


def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param
