# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,time
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="FILMSAATI"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        ######
        url2='http://xbmctr.com/ahd.mp4'
        name2='[COLOR orange]~~~Reklami Izlediginiz Icin Tesekkür ederiz !!~~~[/COLOR]'
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name2,url2,'')
        listitem = xbmcgui.ListItem(name2)
        playList.add(url2, listitem)
        xbmcPlayer.play(playList)
        ######
        FILMSAATI='http://filmtvizle.biz/'
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","search.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "FILMSAATIRecent(url)",FILMSAATI,"yeni")
        link=araclar.get_url(FILMSAATI)
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="(.*?)" title=".*?">(.*?)</a>\n</li>').findall(link)
        for url,name in match:
                araclar.addDir(fileName,'[COLOR green][B][COLOR red]>[/COLOR]'+name+'[/B][/COLOR]', "FILMSAATIRecent(url)",url,"")

def FILMSAATIRecent(url):
        link=araclar.get_url(url)
        match1=re.compile('<a href="(.*?)" title="(.*?)">\n\t\t\t\t\t<img width="225" height="325" src="(.*?)"').findall(link)
        for url,name,thumbnail in match1:
                name=name.replace('&#8217','').replace('&#8211','')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)
        page=re.compile('class=\'page-numbers current\'>.*?</span>\n<a class=\'page-numbers\' href=\'(.*?)\'>(.*?)</a>').findall(link)
        for url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+ '[COLOR red][B]'+name+'[/B][/COLOR]', "FILMSAATIRecent(url)",url,"next")

def ayrisdirma(name,url):
        link=araclar.get_url(url)
        match1=re.compile('<a href="(.*?)">Fragman</a>').findall(link)
        for url in match1:
                name=' FRAGMAN Izle '
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        match2=re.compile('"http://vk.com/(.*?)"').findall(link)
        for code in match2:
                code=''
                name=' Tek PARCA VK'
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        match=re.compile('rel="nofollow"(.*?)">Part(.*?)</a>').findall(link)
        for url,name in match:
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]Vk -'+name+'  PART [/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        	
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://filmtvizle.biz/?s='+query)
        
            FILMSAATIRecent(url)
######

class Anapencere( xbmcgui.WindowXMLDialog ):
    def __init__( self, *args, **kwargs ):
        self.shut = kwargs['close_time'] 
        xbmc.executebuiltin( "Skin.Reset(AnimeWindowXMLDialogClose)" )
        xbmc.executebuiltin( "Skin.SetBool(AnimeWindowXMLDialogClose)" )
        pass

    def setTableText(self, tab):
        self.tabText = tab
        
    def getTableText(self):
        return self.tabText     
        
                                       
    def onInit( self ):
 
        while self.shut > 0:
            xbmc.sleep(1000)
            self.shut -= 1
##        xbmc.Player().stop()
        self._close_dialog()

    
    def getLabel(self):
        """Returns the listitem label."""
        self.getControl(MESSAGE_TITLE).setLabel(self.getTableText()[''])

    def onFocus( self, controlID ): pass
    
    def onClick( self, controlID ): 
        if controlID == 12:
##            xbmc.Player().stop()
            self._close_dialog()
        if controlID == 7:
##            xbmc.Player().stop()
            self._close_dialog()

    def onAction( self, action ):
        if action in [ 5, 6, 7, 9, 10, 92, 117 ] or action.getButtonCode() in [ 275, 257, 261 ]:
##            xbmc.Player().stop()
            self._close_dialog()

    def _close_dialog( self ):
        xbmc.executebuiltin( "Skin.Reset(AnimeWindowXMLDialogClose)" )
        time.sleep( .4 )
        self.close()
        

def pencere():
    if xbmc.getCondVisibility('system.platform.ios'):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.atv"):           
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.linux"):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.android"):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.osx"):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.windows"):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    else:
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    ac.doModal()
    del ac
    ##
def VIDEOLINKS(name,url):
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
                try:
                        
                        time.sleep(30)
                        pencere()
                        time.sleep(2500)
                        pencere()
                except:
                        pass

		#---------------------------------------------#

        youtube=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

		#---------------------------------------------#
        mailru2=re.compile('"movieSrc":   "mail/(.*?)"').findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#

        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]

def replace_fix(x):        
        x=x.replace('&#8211;', '-').replace('&#038;', '&').replace('&amp;', '&')
        return x
