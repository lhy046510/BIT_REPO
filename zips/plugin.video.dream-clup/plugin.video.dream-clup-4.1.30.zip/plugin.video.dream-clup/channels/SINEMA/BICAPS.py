# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon,os,base64,sys,xbmc,urlresolver
import cozucu, araclar
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS
import simplejson as json

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString
IMAGES_PATH = xbmc.translatePath(os.path.join(Addon.getAddonInfo('path'), 'resources', 'images'))
addon_icon    = __settings__.getAddonInfo('icon')

fileName = "BICAPS"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


def main():
 ##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        bicaps='http://bicaps.net/'
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "bicapsSearch()", "","special://home/addons/plugin.video.dream-clup/resources/images/search.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "bicapsRecent(url)",bicaps,"special://home/addons/plugin.video.dream-clup/resources/images/yeni.png")

                ##### KATEGORILERI OKU EKLE #######
        link=araclar.get_url(bicaps)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"class": "sidebar-right"})
        liste=BeautifulSoup(str(panel))
        for li in liste.findAll('li'):
            a=li.find('a')
            url= a['href']
            name= li.text
            name=name.encode('utf-8', 'ignore')
            araclar.addDir(fileName,'[COLOR green][B][COLOR red]>[/COLOR]'+name+'[/B][/COLOR]', "bicapsRecent(url)",url,"")

def bicapsRecent(Url):
        link=araclar.get_url(Url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"class": "leftC"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "moviefilm"})
        for i in range (len (panel)):
            url=panel[i].find('a')['href']
            name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
            thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
            araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "bicapsvideolinks(url,name)",url,thumbnail)
				
        #############    SONRAKI SAYFA  >>>> #############
        page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link)
        for Url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "bicapsRecent(url)",Url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")

        #############     ONCEKISAYFA SAYFA  <<<< #############
        page2=re.compile('</a><a href=\'(.*?)\' class=\'page smaller\'>.*?</a><span class=\'current\'>.*?</span>').findall(link)
        for Url in page2:
                araclar.addDir(fileName,'[COLOR red][B]Onceki Sayfa Sayfa[/B][/COLOR]', "bicapsRecent(url)",Url,"special://home/addons/plugin.video.dream-clup/resources/images/oncekisayfa.png")

        #############      ^^^^ANASAYFA^^^^      #############
        araclar.addDir(fileName,'[COLOR red][B]ANA SAYFA[/B][/COLOR]', "main()",Url,"special://home/addons/plugin.video.dream-clup/resources/images/main.png")	
				
########	?	ARAMA	?	########
def bicapsSearch():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=araclar.name_fix(query)
			
        try:
            araclar.addDir(fileName,'[COLOR blue][B]-----BICAPS-----[/B][/COLOR]', "","","Search")
            Url = ('http://bicaps.net/'+'?s='+query)
            link=araclar.get_url(Url)
            soup = BeautifulSoup(link)
            panel = soup.findAll("div", {"class": "leftC"},smartQuotesTo=None)
            panel = panel[0].findAll("div", {"class": "moviefilm"})
            for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR green][B]>> - [/B][/COLOR]'+name, "bicapsvideolinks(url,name)",url,thumbnail)

            #############    SONRAKI SAYFA  >>>> #############
            page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link)
            for Url,name in page:
                    araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "bicapsRecent(url)",Url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")

            #############     ONCEKISAYFA SAYFA  <<<< #############
            page2=re.compile('</a><a href=\'(.*?)\' class=\'page smaller\'>.*?</a><span class=\'current\'>.*?</span>').findall(link)
            for Url in page2:
                    araclar.addDir(fileName,'[COLOR red][B]Onceki Sayfa Sayfa[/B][/COLOR]', "bicapsRecent(url)",Url,"special://home/addons/plugin.video.dream-clup/resources/images/oncekisayfa.png")
        except:
            xbmc.executebuiltin('Notification("[COLOR yellow][B]Dream - Clup[/B][/COLOR]","[COLOR yellow][B]Bicaps Acilamadi[/B][/COLOR]")')

        araclar.addDir(fileName,'[COLOR yellow][B]YENI ARAMA YAP[/B][/COLOR]', "bicapsSearch()","","Search")
        araclar.addDir(fileName,'[COLOR red][B]ANA SAYFAYA GIT[/B][/COLOR]', "main()",Url,"anasayfa")
########   linkleri topla   ########
def bicapsvideolinks(url,name):
	araclar.addDir(fileName,'[COLOR red]'+name+'[/COLOR]', "VIDEOLINKS(name,url)",url,"")
	link=araclar.get_url(url)
	soup = BeautifulSoup(link)
	panel = soup.findAll("div", {"class": "keremiya_part"})
	match=re.compile('href="(.*?)"><span>(.*?)</span>').findall(str(panel[0]))
	for url,name in match:
		araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,"")						

##'''#############################################################################################'''
##'''#############################################################################################'''
#######################################    VIDEO    ###############################################
def VIDEOLINKS(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)        
		#---------------------------------------------#
        youtube=re.compile(' src\="\/\/www.youtube.com\/embed\/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        mailru=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                urlList.append(url)
        #-------------------------------
        mailru4=re.compile('<iframe src=\'http://api.video.mail.ru/videos/embed/mail/(.*?).html\'').findall(link)
        for mailrugelen in mailru4:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
        #-------------------------------
        mailru3=re.compile('movieSrc: "(.*?)"').findall(link)
        for mailrugelen in mailru3:
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url)
		#---------------------------------------------#
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
