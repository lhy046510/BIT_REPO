# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS
import time

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="BAGLANBIZE"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        ######
        url2='http://xbmctr.com/ahd.mp4'
        name2='[COLOR orange]~~~Reklami Izlediginiz Icin Tesekkür ederiz !!~~~[/COLOR]'
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name2,url2,'')
        listitem = xbmcgui.ListItem(name2)
        playList.add(url2, listitem)
        xbmcPlayer.play(playList)
        ######
        baglanfilmizle='http://www.baglanfilmizle.com/'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "baglanfilmizleRecent(url)",baglanfilmizle,"yeni")
        link=araclar.get_url(baglanfilmizle)
        match=re.compile('<li><a href="http://www.baglanfilmizle.com/film-izle/kategoriler/(.*?)">(.*?)</a></li>').findall(link)
        for url,name in match:
                url='http://www.baglanfilmizle.com/film-izle/kategoriler/'+url
                araclar.addDir(fileName,'[COLOR green][B][COLOR lightblue]> [/COLOR]'+name+'[/B][/COLOR]', "baglanfilmizleRecent(url)",url,"")

def baglanfilmizleRecent(url):
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)" title=".*?">\r\n    <figure><img src="(.*?)" alt="(.*?)" height="296" width="203" /></figure>\r\n').findall(link)
        for url,t,name in match:
                name=name.replace('&#8211','').replace('&#8217','').replace('&#038;','')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url,t)
##        soup = BeautifulSoup(link)
##        panel = soup.findAll("div", {"class": "body"},smartQuotesTo=None)
##        panel = panel[0].findAll("div", {"class": "filmm sol"})
##        for i in range (len (panel)):
##            gelenurl=panel[i].find("div", {"class": "bt"})
##            url=gelenurl.find('a')['href'].encode('utf-8', 'ignore')
##            name=panel[i].find("div", {"class": "bs"}).text.encode('utf-8', 'ignore')
##            thumbnail=panel[i].find("img", {"class": "afis-resim"})['src'].encode('utf-8', 'ignore')
##            name=name.replace('&#8211','').replace('&#8217','')
            
				
        #############    SONRAKI SAYFA  >>>> #############
        page=re.compile('<a class="next page-numbers" href="(.*?)">').findall(link)
        for Url in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+'[/B][/COLOR]', "baglanfilmizleRecent(url)",Url,"next")

class Anapencere( xbmcgui.WindowXMLDialog ):
    def __init__( self, *args, **kwargs ):
        self.shut = kwargs['close_time'] 
        xbmc.executebuiltin( "Skin.Reset(AnimeWindowXMLDialogClose)" )
        xbmc.executebuiltin( "Skin.SetBool(AnimeWindowXMLDialogClose)" )
        pass

    def setTableText(self, tab):
        self.tabText = tab
        
    def getTableText(self):
        return self.tabText     
        
                                       
    def onInit( self ):
 
        while self.shut > 0:
            xbmc.sleep(1000)
            self.shut -= 1
##        xbmc.Player().stop()
        self._close_dialog()

    
    def getLabel(self):
        """Returns the listitem label."""
        self.getControl(MESSAGE_TITLE).setLabel(self.getTableText()[''])

    def onFocus( self, controlID ): pass
    
    def onClick( self, controlID ): 
        if controlID == 12:
##            xbmc.Player().stop()
            self._close_dialog()
        if controlID == 7:
##            xbmc.Player().stop()
            self._close_dialog()

    def onAction( self, action ):
        if action in [ 5, 6, 7, 9, 10, 92, 117 ] or action.getButtonCode() in [ 275, 257, 261 ]:
##            xbmc.Player().stop()
            self._close_dialog()

    def _close_dialog( self ):
        xbmc.executebuiltin( "Skin.Reset(AnimeWindowXMLDialogClose)" )
        time.sleep( .4 )
        self.close()
        

def pencere():
    if xbmc.getCondVisibility('system.platform.ios'):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.atv"):           
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.linux"):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.android"):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.osx"):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    elif xbmc.getCondVisibility("system.platform.windows"):
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    else:
        ac = Anapencere('reklam.xml',__settings__.getAddonInfo('path'),'DefaultSkin',close_time=10,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%__settings__.getAddonInfo('path'))
    ac.doModal()
    del ac




def ayrisdirma(name,url):
        link=araclar.get_url(url)
        link=link.replace('&nbsp;'," ")#.replace('(VK)','')

        fragman=re.compile('<a href="http://www.baglanfilmizle.com/(.*?)" rel="nofollow">(.*?)</a> ').findall(link)
        for url,name in fragman:
                url='http://www.baglanfilmizle.com/'+url
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        match4=re.compile('(.*?)a class="active">Part 1</a>').findall(link)
        for code  in match4:
                code=''
                name='PART  1'
                url=url
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        match2=re.compile('<a href="http://www.baglanfilmizle.com/(.*?)">Part(.*?)</a>').findall(link)
        for url,name in match2:
                url='http://www.baglanfilmizle.com/'+url
                name='PART '+name
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')

        match3=re.compile('<a href="(.*?)">PART(.*?)</a>').findall(link)
        for url,name in match3:
                #url='http://www.baglanfilmizle.com/'+url
                name='PART '+name
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')

        	

def baglanfilmizleRecent2(Url):
        link=araclar.get_url(Url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("span", {"class": "filmm sol"})
        for i in range (len (panel)):
                gelenurl=panel[i].find("div", {"class": "bt"})
                url=gelenurl.find('a')['href'].encode('utf-8', 'ignore')
                name=panel[i].find("div", {"class": "bs"}).text.encode('utf-8', 'ignore')
                name=name.replace('&#8211','').replace('&#8217','')
                img=re.compile('src="(.*?)"').findall(str(panel[i]))
                for a in img:
                    if not "bt" in a:
                            thumbnail =a
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url+'/30',thumbnail)
        page=re.compile('<a class=\'aktif\'>.*?</a><a href=\'(.*?)\' class=\'inaktif\' >(.*?)</a>').findall(link)
        for Url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "baglanfilmizleRecent2(url)",Url,"next")
        page2=re.compile('<link rel=\'prev\' href=\'(.*?)\' />').findall(link)
        for Url in page2:
                araclar.addDir(fileName,'[COLOR red][B]Onceki Sayfa[/B][/COLOR]', "baglanfilmizleRecent2(url)",Url,"onceki")

def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]

def replace_fix(x):        
        x=x.replace('&#8211;', '-').replace('&#038;', '&').replace('&amp;', '&')
        return x

def VIDEOLINKS(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
                try:
                        
                        time.sleep(30)
                        pencere()

                except:
                        pass
		#---------------------------------------------#
        youtube=re.compile(' src\="\/\/www.youtube.com\/embed\/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
                try:
                        
                        time.sleep(30)
                        pencere()

                except:
                        pass
		#---------------------------------------------#
        mailru=re.compile('<iframe src=\'http://videoapi.my.mail.ru/videos/embed/mail/(.*?).html').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                urlList.append(url)
                try:
                        
                        time.sleep(30)
                        pencere()

                except:
                        pass
        #-------------------------------
        mailru4=re.compile('<iframe src=\'http://api.video.mail.ru/videos/embed/mail/(.*?).html\'').findall(link)
        for mailrugelen in mailru4:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
                try:
                        
                        time.sleep(30)
                        pencere()
  
                except:
                        pass
        #-------------------------------
        mailru3=re.compile('movieSrc: "(.*?)"').findall(link)
        for mailrugelen in mailru3:
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url)
                try:
                        
                        time.sleep(30)
                        pencere()

                except:
                        pass
		#---------------------------------------------#
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
                try:
                        
                        time.sleep(30)
                        pencere()

                except:
                        pass
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
