# -*- coding: utf-8 -*-
import re,xbmcplugin,xbmcgui,xbmcaddon,xbmc
import araclar, cozucu,base64
from BeautifulSoup import BeautifulSoup
Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
addon_icon    = __settings__.getAddonInfo('icon')
images = 'special://home/addons/plugin.video.dream-clup/resources/images/'
FILENAME = "IZLEDUR"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        hdfilmsehri='http://www.sinemaseyret.com/'
        #araclar.addDir(FILENAME,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "hdfilmsehriSearch()", "",images+"search.png")
        araclar.addDir(FILENAME,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "hdfilmsehriRecent(url)",hdfilmsehri,'')

                ##### KATEGORILERI OKU EKLE #######
        link=araclar.get_url(hdfilmsehri)
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="(.*?)" title=".*?">(.*?)</a>\n</li>').findall(link)
        for url,name in match:
                araclar.addDir(FILENAME,'[COLOR lightgreen][B][COLOR lightblue]> [/COLOR]'+name+'[/B][/COLOR]', "hdfilmsehriRecent(url)",url,"")

def hdfilmsehriRecent(Url):
        link=araclar.get_url(Url)
        match=re.compile(' href="(.*?)">\n<span class=".*?"></span><img src="(.*?)" alt="(.*?)"').findall(link)
        for url,thumbnail,name in match:
            araclar.addDir(FILENAME,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "hdfilmsehrivideolinks(url,name,thumbnail)",url,thumbnail)
        match1=re.compile('<a href="(.*?)">\n<img src="(.*?)" alt="(.*?)"').findall(link)
        for url,thumbnail,name in match1:
                araclar.addDir(FILENAME,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "hdfilmsehrivideolinks(url,name,thumbnail)",url,thumbnail)				
        #############    SONRAKI SAYFA  >>>> #############
        page=re.compile('<a class="nextpostslink" href="(.*?)"').findall(link)
        for url in page:
                name='Sonraki Sayfa'
                araclar.addDir(FILENAME,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "hdfilmsehriRecent(url)",Url,images+"sonrakisayfa.png")

        #############     ONCEKI SAYFA  <<<< #############
##        page2=re.compile('href=\'(.*?)\'>.*?</a> <span class=\'page-numbers current\'>.*?</span>').findall(link)
##        for Url in page2:
##                araclar.addDir(FILENAME,'[COLOR red][B]Onceki Sayfa[/B][/COLOR]', "hdfilmsehriRecent(url)",Url,images+"oncekisayfa.png")

##        #############      ^^^^ANASAYFA^^^^      #############
##        araclar.addDir(FILENAME,'[COLOR red][B]ANA SAYFA[/B][/COLOR]', "main()",Url,"anasayfa")	
##
##        #############      ^^^^SAYFAYAGIT^^^^      #############
##        araclar.addDir(FILENAME,'[COLOR blue][B]SAYFAYA GIT[/B][/COLOR]', "hdfilmsehrigit(url)",sayfagit,"anasayfa")
		
def hdfilmsehrigit(Url):
        gelengit = Url
        if 'page' in gelengit:
            page1=re.compile('(.*?)/page/.*?').findall(gelengit)
            for url in page1:
                git=url
        else:
            git=gelengit
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=araclar.name_fix(query)
            Url = (git+'/page/'+query)
            return hdfilmsehriRecent(Url)
			
########	?	ARAMA	?	########
def hdfilmsehriSearch():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=araclar.name_fix(query)
			
        try:
            araclar.addDir(FILENAME,'[COLOR blue][B]-----HDFILMSEHRI-----[/B][/COLOR]', "","","Search")
            Url = ('http://www.hdfilmsehri.com/index.php/'+'?s='+query)
            link=araclar.get_url(Url)
            soup = BeautifulSoup(link)
            panel = soup.findAll("div", {"id": "content"},smartQuotesTo=None)
            panel = panel[0].findAll("article", {"class": "article"})
            for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(FILENAME,'[COLOR green][B]>> - [/B][/COLOR]'+name, "hdfilmsehrivideolinks(url,name,thumbnail)",url,thumbnail)

            #############    SONRAKI SAYFA  >>>> #############
            page=re.compile('<span class=\'page-numbers current\'>.*?</span> <a class=\'page-numbers\' href=\'(.*?)\'>(.*?)</a>').findall(link)
            for Url,name in page:
                    araclar.addDir(FILENAME,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "hdfilmsehriRecent(url)",Url,images+"sonrakisayfa.png")
        except:
            xbmc.executebuiltin('Notification("[COLOR yellow][B]Dream - Clup[/B][/COLOR]","[COLOR yellow][B]hdfilmsehri Acilamadi[/B][/COLOR]")')

        araclar.addDir(FILENAME,'[COLOR yellow][B]YENI ARAMA YAP[/B][/COLOR]', "hdfilmsehriSearch()","","Search")
        araclar.addDir(FILENAME,'[COLOR red][B]ANA SAYFAYA GIT[/B][/COLOR]', "main()",Url,"anasayfa")
########   linkleri topla   ########

def hdfilmsehrivideolinks(url,name,thumbnail):
        link=araclar.get_url(url)
        mailru=re.compile(' <a href="(.*?)"><span>Tek Part M-RU</span></a>').findall(link)
        for url in mailru:
                name='Tek Part M-RU'
                araclar.addDir(FILENAME,'[COLOR orange][B] >> [COLOR blue]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        vk=re.compile(' <a href="(.*?)"><span>Tek Part VK</span></a>').findall(link)
        for url in vk:
                name='Tek Part VK'
                araclar.addDir(FILENAME,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'')

        direkvk=re.compile('asdsadsad').findall(link)
        print url
        name='V Server Bulundu'
        araclar.addDir(FILENAME,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'')

        epname= 'Part '
        a=0
        match=re.compile(' <a href="(.*?)"><span>(.*?)</span></a>').findall(link)
        for url,name in match:
                a= a+1
                name = epname + ' - '+str(a)
                araclar.addDir(FILENAME,'[COLOR orange][B] >> [COLOR blue]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')

         
                
def VIDEOLINKS(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)        
		#---------------------------------------------#
        youtube=re.compile(' src\="\/\/www.youtube.com\/embed\/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        mailru=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                urlList.append(url)
        #-------------------------------
        mailru4=re.compile('<iframe src=\'http://api.video.mail.ru/videos/embed/mail/(.*?).html\'').findall(link)
        for mailrugelen in mailru4:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
        #-------------------------------
        mailru3=re.compile('movieSrc: "(.*?)"').findall(link)
        for mailrugelen in mailru3:
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url)
		#---------------------------------------------#
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
            
def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]
        
def replace_fix(x):        
        x=x.replace('&#8211;', '-').replace('&#038;', '&').replace('&amp;', '&')
        return x
