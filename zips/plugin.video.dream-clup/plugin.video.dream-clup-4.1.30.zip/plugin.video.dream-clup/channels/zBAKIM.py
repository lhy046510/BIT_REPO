# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys,time
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


#------------------eklenecek kısım------------------
import araclar,cozucu
addon_id = 'plugin.video.dream-clup'
__settings__ = xbmcaddon.Addon(id=addon_id)
__language__ = __settings__.getLocalizedString
#art = main.art

#---------------------------------------------------


fileName="zBAKIM"

        
def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        araclar.addDir(fileName,'[COLOR red][B]>>  INFOYU OKUYUNUZ  <<[/B][/COLOR] ', "INFO(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/unlem.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]PACKAGES TEMIZLIGI - 1 -[/B][/COLOR] ', "MAINDEL(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/bakito.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]CACHE TEMIZLIGI - 2 -[/B][/COLOR] ', "MAINDEL2(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/bakito.png')
        araclar.addDir(fileName,'[COLOR yellow][B]>> [/B][/COLOR]'+ '[COLOR yellow][B]Sadece Apple TV lerde CACHE Temizligi !![/B][/COLOR] ', "MAINDEL3(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/bakito.png')
        #araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Skin Temizligi[/B][/COLOR] ', "findaddon(url,name)",'','special://home/addons/plugin.video.dream-clup/resources/images/bakito.png')

def MAINDEL(name):
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno('Dream - Clup UYARI', 'PACKAGES temizliginden Eminmisiniz ! ','','','No', 'Yes')
        if ret:
            import os 
            folder = xbmc.translatePath(os.path.join('special://home/addons/packages/', ''))
            for the_file in os.listdir(folder):
                file_path = os.path.join(folder, the_file)
                try:
                    if os.path.isfile(file_path):
                        os.unlink(file_path)
                except Exception, e:
                    dialog = xbmcgui.Dialog(e)
                    i = dialog.ok('!!! Packages !!!', "[COLOR beige]Packages Temizliginiz Bitmistir[/COLOR]","[COLOR pink]iyi kullanimlar.[/COLOR]")
def MAINDEL2(name):
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno('Dream - Clup UYARI', 'CACHE temizliginden Eminmisiniz ! ','','','No', 'Yes')
        if ret:
            import os 
            folder = xbmc.translatePath(os.path.join('special://home/cache', ''))
            for the_file in os.listdir(folder):
                file_path = os.path.join(folder, the_file)
                try:
                    if os.path.isfile(file_path):
                        os.unlink(file_path)
                except Exception, e:
                    dialog = xbmcgui.Dialog(e)
                    i = dialog.ok('Temizlendi Uyarisi !!!', "[COLOR beige]Temizliginiz basariyla bitmistir[/COLOR]","[COLOR pink]iyi kullanimlar.[/COLOR]")
def MAINDEL3(name):
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno('Dream - Clup UYARI', 'Apple TV - CACHE temizliginden Eminmisiniz ! ','','','No', 'Yes')
        if ret:
            import os 
            folder = xbmc.translatePath(os.path.join('special://home/temp', ''))
            for the_file in os.listdir(folder):
                file_path = os.path.join(folder, the_file)
                try:
                    if os.path.isfile(file_path):
                        os.unlink(file_path)
                except Exception, e:
                    dialog = xbmcgui.Dialog(e)
                    i = dialog.ok('Temizlendi Uyarisi !!!', "[COLOR beige]Temizliginiz basariyla bitmistir[/COLOR]","[COLOR pink]iyi kullanimlar.[/COLOR]")

def findaddon(url,name):  
    print '############################################################       REMOVE ADDON             ###############################################################'
    pluginpath = xbmc.translatePath(os.path.join('special://home/addons',''))
    import glob
    for file in glob.glob(os.path.join(pluginpath, url+'*')):
        name=str(file).replace(pluginpath,'').replace('plugin.','').replace('audio.','').replace('video.','').replace('skin.','').replace('repository.','')
        iconimage=(os.path.join(file,'icon.png'))
        fanart=(os.path.join(file,'fanart.jpg'))
        addDir(name,file,26,iconimage,fanart,'')
        setView('movies', 'SUB') 

def INFO(name):
  try:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(name, "[COLOR beige]XBMC yi kapatmadan once temizligi gerceklestirin.[/COLOR]","[COLOR pink]iyi kullanimlar.[/COLOR]")
  except:
        
        pass 



