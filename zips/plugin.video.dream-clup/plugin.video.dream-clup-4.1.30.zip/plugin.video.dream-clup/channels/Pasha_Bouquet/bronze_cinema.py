# -*- coding: utf-8 -*-  
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re  
import araclar,cozucu 
# -*- coding: utf-8 -*- 
import urllib,urllib2,re,base64,os,sys 
import xbmcplugin,xbmcgui,xbmcaddon,xbmc 
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS 
import urlresolver 
  
  
    
Addon = xbmcaddon.Addon('plugin.video.dream-clup')  
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')  
__language__ = __settings__.getLocalizedString  
    
fileName ="bronze_cinema"
xbmcPlayer = xbmc.Player()  
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)  
    
def main():
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
    url='http://xsharethis.com/'
    url1='http://ks3097270.kimsufi.com/'
    araclar.addDir(fileName,'[COLOR red][B]<~~~~~**~~~~>[/B][/COLOR][COLOR yellow][B] Search [/B][/COLOR][COLOR red][B]<~~~~~**~~~~~>[/B][/COLOR]', "Search()", "","special://home/addons/plugin.video.dream-clup/resources/images/search.png") 
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR red][B][I]Just Added[/I][/B][/COLOR] ', "home(url)",url,"http://www.ugdsb.on.ca/uploadedImages/jeanlittle/teacher/stockton-wigmore/Linda_Stockton-Wigmore/Movie%20Reel.jpg") 
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR darkorange][B][I]Watch Featured Movies[/I][/B][/COLOR] ', "Featured(url)",url,"https://www.globalreporting.org/SiteCollectionImages/Reporting%20Hub/FEATURED-ORANGE.jpg") 
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR blue][B][I]Category[/I][/B][/COLOR] ', "Category(url)",url,"http://icons.iconarchive.com/icons/sirubico/movie-genre/icons-390.jpg") 
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR blue][B][I]movie[/I][/B][/COLOR] ', "liste(url)",url1,"http://icons.iconarchive.com/icons/sirubico/movie-genre/icons-390.jpg") 
  
  
  
  
  
def liste(url):  
        link=araclar.get_url(url) 
        match=re.compile('<td><a href="(.*?)">(.*?).mkv</a></td>').findall(link) 
        for url , name in match: 
            url='http://ks3097270.kimsufi.com/'+url 
            name=name.replace('&amp;','').replace('80.Ganoll.com','').replace('-LOTUS','').replace('-PublicHD','').replace('-GKS','').replace('By BadMad','') 
            araclar.addDir(fileName,'[COLOR darkorange][B]'+name+'[/B][/COLOR]', "LiveTvShowsOynat(name,url)",url,'') 
        match1=re.compile('<td><a href="(.*?)">(.*?).avi</a></td>').findall(link) 
        for url , name in match1: 
            url='http://ks3097270.kimsufi.com/'+url 
            name=name.replace('&amp;','').replace('80.Ganoll.com','').replace('-LOTUS','').replace('-PublicHD','').replace('-GKS','').replace('By BadMad','') 
            araclar.addDir(fileName,'[COLOR darkorange][B]'+name+'[/B][/COLOR]', "LiveTvShowsOynat(name,url)",url,'') 
        match2=re.compile('<td><a href="(.*?)">(.*?).mp4</a></td>').findall(link) 
        for url , name in match2: 
            url='http://ks3097270.kimsufi.com/'+url 
            name=name.replace('&amp;','').replace('80.Ganoll.com','').replace('-LOTUS','').replace('-PublicHD','').replace('-GKS','').replace('By BadMad','') 
            araclar.addDir(fileName,'[COLOR darkorange][B]'+name+'[/B][/COLOR]', "LiveTvShowsOynat(name,url)",url,'') 
  
  
  
def yeni4(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul 
        xbmcPlayer = xbmc.Player()  
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)  
        playList.clear()  
        araclar.addLink(name,url,'')  
  
        listitem = xbmcgui.ListItem(name)  
        playList.add(url, listitem)  
        xbmcPlayer.play(playList)  
  
  
  
  
  
def home(url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul 
        link=araclar.get_url(url) 
        match=re.compile('<a href="(.*?)"><img width="135px" height="170px" class="alignleft" style="margin-top: 5px; margin-bottom: 5px; margin-left: 3px; margin-right: 20px;" title="(.*?)" src="(.*?)" align="left" /></a>\n').findall(link) 
        for url,name,thumbnail in match: 
            thumbnail='http://xsharethis.com'+thumbnail 
            name=name.replace('Download','').replace(') Full Movie','').replace('(','') 
            araclar.addDir(fileName,'[COLOR darkorange][B]'+name+'[/B][/COLOR]', "home(url)",url,thumbnail) 
        page=re.compile('<span class=\'.*?\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link) 
        for url,name in page: 
            araclar.addDir(fileName,'[COLOR white][B]Next Page --->>  [/B][/COLOR][COLOR red]'+name+'[/COLOR]'+'', "home(url)",url,"http://etc-mysitemyway.s3.amazonaws.com/icons/legacy-previews/icons/glowing-purple-neon-icons-media/113576-glowing-purple-neon-icon-media-a-media24-arrows-seek-forward.png") 
        match1=re.compile('src="(.*?)" >(.*?)<a href="(.*?)" target=".*?">.*?</a>.*?</p>').findall(link) 
        for thumbnail,name,url in match1: 
            thumbnail='http://xsharethis.com'+thumbnail 
            #url='http://xsharethis.com'+url 
            name=name.replace(' Online link ','').replace(': ','')#.replace('(','') 
            araclar.addDir(fileName,'[COLOR darkorange][B]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail) 
  
              
def Featured(url):
       ##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        link=araclar.get_url(url) 
        match=re.compile('href="(.*?)">\n\t\t<img src="(.*?)" width="94" alt="(.*?)"').findall(link) 
        for url,thumbnail,name in match: 
            thumbnail='http://xsharethis.com'+thumbnail 
            name=name.replace('Download','').replace('Free Movie','').replace('(','').replace(')','') 
            araclar.addDir(fileName,'[COLOR lihtgreen][B]'+name+'[/B][/COLOR]', "Featured(url)",url,thumbnail) 
        match1=re.compile('src="(.*?)" >(.*?)<a href="(.*?)" target=".*?">.*?</a>.*?</p>').findall(link) 
        for thumbnail,name,url in match1: 
            thumbnail='http://xsharethis.com'+thumbnail 
            #url='http://xsharethis.com'+url 
            name=name.replace(' Online link ','').replace(': ','')#.replace('(','') 
            araclar.addDir(fileName,'[COLOR darkorange][B]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail) 
  
def Search(): 
        keyboard = xbmc.Keyboard("", 'Search', False) 
        keyboard.doModal() 
        if keyboard.isConfirmed(): 
            query = keyboard.getText() 
            url = ('http://xsharethis.com/?s='+query) 
            Searchcat(url) 
  
              
  
def Searchcat(url):  
        link=araclar.get_url(url) 
        match=re.compile('<div class="screenshot" style=".*?"><a href="(.*?)" title=".*?"><img src="(.*?)" alt="Watch (.*?) Online"').findall(link) 
        for url,thumbnail,name in match: 
            thumbnail='http://xsharethis.com'+thumbnail 
            name=name.replace('(','').replace(')','').replace('&#8217;s','') ##tamammihah oldu dene 
            araclar.addDir(fileName,'[COLOR green][B]'+name+'[/B][/COLOR]', "Searchcalistir(url)",url,thumbnail) 
        page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link) 
        for url,name in page: 
            araclar.addDir(fileName,'[COLOR white][B]Next Page --->>  [/B][/COLOR][COLOR red]'+name+'[/COLOR]'+'', "Searchcat",url,"http://etc-mysitemyway.s3.amazonaws.com/icons/legacy-previews/icons/glowing-purple-neon-icons-media/113576-glowing-purple-neon-icon-media-a-media24-arrows-seek-forward.png") 
##        match1=re.compile('src="(.*?)" >(.*?)<a href="(.*?)" target=".*?">.*?</a>.*?</p>').findall(link) 
##        for thumbnail,name,url in match1: 
##            thumbnail='http://xsharethis.com'+thumbnail 
##            url='http://xsharethis.com'+url 
##            name=name.replace(' Online link ','').replace(': ','')#.replace('(','') 
##            araclar.addDir(fileName,'[COLOR darkorange][B]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail) 
  
  
def Searchcalistir(url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        link=araclar.get_url(url) 
        match=re.compile('src="(.*?)" >(.*?)<a href="(.*?)" target=".*?">.*?</a>.*?</p>').findall(link) 
        for thumbnail,name,url in match: 
            thumbnail='http://xsharethis.com'+thumbnail 
            #url='http://xsharethis.com'+url 
            name=name.replace(' Online link ','').replace(': ','')#.replace('(','') 
            araclar.addDir(fileName,'[COLOR darkorange][B]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail) 
  
              
def Category(url):  
        link=araclar.get_url(url) 
        match=re.compile('<li class=".*?"><a href="(.*?)" title=".*?">(.*?)</a>\n</li>').findall(link) 
        for url,name in match: 
            #thumbnail='http://xsharethis.com'+thumbnail 
            name=name.replace('Download','').replace(') Full Movie','').replace('(','') 
            araclar.addDir(fileName,'[COLOR darkorange][B]'+name+'[/B][/COLOR]', "Categoryinside(url)",url,'') 
##        page=re.compile('<span class=\'.*?\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link) 
##        for url,name in page: 
##            araclar.addDir(fileName,'[COLOR white][B]Next Page --->>  [/B][/COLOR][COLOR red]'+name+'[/COLOR]'+'', "home(url)",url,"http://etc-mysitemyway.s3.amazonaws.com/icons/legacy-previews/icons/glowing-purple-neon-icons-media/113576-glowing-purple-neon-icon-media-a-media24-arrows-seek-forward.png") 
  
def Categoryinside(url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        link=araclar.get_url(url) 
        match=re.compile('<a href="(.*?)"><img width="135px" height="170px" class="alignleft" style="margin-top: 5px; margin-bottom: 5px; margin-left: 3px; margin-right: 20px;" title="(.*?)" src="(.*?)" align="left" /></a>').findall(link) 
        for url,name,thumbnail in match: 
            thumbnail='http://xsharethis.com'+thumbnail 
            name=name.replace('Download','').replace(') Full Movie','').replace('(','') 
            araclar.addDir(fileName,'[COLOR darkorange][B]'+name+'[/B][/COLOR]', "Categoryinside(url)",url,thumbnail) 
        s=re.compile('<link rel=\'next\' href=\'(.*?)\'').findall(link) 
        for url in s: 
            name='[COLOR white][B][/B][/COLOR][COLOR red]'+'Sonraki Sayfa'+'[/COLOR]'            
            araclar.addDir(fileName,name, "Categoryinside(url)",url,"http://etc-mysitemyway.s3.amazonaws.com/icons/legacy-previews/icons/glowing-purple-neon-icons-media/113576-glowing-purple-neon-icon-media-a-media24-arrows-seek-forward.png") 
        match1=re.compile('src="(.*?)" >(.*?)<a href="(.*?)" target=".*?">.*?</a>.*?</p>').findall(link) 
        for thumbnail,name,url in match1: 
            thumbnail='http://xsharethis.com'+thumbnail 
            #url='http://xsharethis.com'+url 
            name=name.replace(' Online link ','').replace(': ','')#.replace('(','') 
            araclar.addDir(fileName,'[COLOR darkorange][B]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail) 
######## 
  
def UrlResolver_Player(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        UrlResolverPlayer = url 
        playList.clear() 
        media = urlresolver.HostedMediaFile(UrlResolverPlayer) 
        source = media 
        if source: 
                url = source.resolve() 
                araclar.addLink(name,url,'') 
                araclar.playlist_yap(playList,name,url) 
                xbmcPlayer.play(playList) 
  
  
  
  
  
  
  
  
  
  
##def Categoryins(url):  
##        link=araclar.get_url(url) 
##        match=re.compile('src="(.*?)" >(.*?)<a href="(.*?)" target=".*?">.*?</a>.*?</p>').findall(link) 
##        for thumbnail,name,url in match: 
##            thumbnail='http://xsharethis.com'+thumbnail 
##            url='http://xsharethis.com'+url 
##            name=name.replace(' Online link ','').replace(': ','')#.replace('(','') 
##            araclar.addDir(fileName,'[COLOR darkorange][B]'+name+'[/B][/COLOR]', "belgeselyerli(url)",url,thumbnail) 
####        page=re.compile('<span class=\'.*?\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link) 
####        for url,name in page: 
####            araclar.addDir(fileName,'[COLOR white][B]Next Page --->>  [/B][/COLOR][COLOR red]'+name+'[/COLOR]'+'', "home(url)",url,"http://etc-mysitemyway.s3.amazonaws.com/icons/legacy-previews/icons/glowing-purple-neon-icons-media/113576-glowing-purple-neon-icon-media-a-media24-arrows-seek-forward.png") 
## 
  
  
  
  
  
  
  
  
  
def simplyVIDEOLINKS(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        #---------------------------# 
        urlList=[] 
        #---------------------------# 
        playList.clear() 
        link=araclar.get_url(url) 
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/') 
  
        #---------------------------------------------# 
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link) 
        for url in vk_2: 
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
                #---------------------------------------------#         
        vk_1=re.compile('"https:\/\/vk.com\/(.*?)"').findall(link) 
        for url in vk_1: 
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #---------------------------------------------# 
        veka=re.compile('value="http:\/\/.*?\/veka.swf\?file\=(.*?)\&otobaslat\=0"').findall(link) 
        for url in veka: 
                url = 'http://'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #---------------------------------------------# 
        divxstage=re.compile('src=\'http://embed.divxstage.eu/(.*?)&').findall(link) 
        for url in divxstage: 
                url = 'http://embed.divxstage.eu/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
            #---------------------------------------------# 
        youtube=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link) 
        for url in youtube: 
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #---------------------------------------------# 
        movshare=re.compile('src=\'http://embed.movshare.net/(.*?)&').findall(link) 
        for url in movshare: 
                url = 'http://embed.movshare.net/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #---------------------------------------------# 
        uploadc=re.compile('src="(.*?)uploadc(.*?)"').findall(link) 
        for url,uploadcgelen in uploadc: 
                url = str(url)+'uploadc'+str(uploadcgelen).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #---------------------------------------------# 
        mailru=re.compilematch=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link) 
        for mailrugelen in mailru: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                #print url 
                urlList.append(url) 
  
        #------------------------------- 
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link) 
        for url in dm: 
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
  
        mailru3=re.compile('movieSrc: "(.*?)"').findall(link) 
        for mailrugelen in mailru3: 
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url) 
        #---------------------------------------------# 
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link) 
        for mailrugelen in mailru2: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url) 
        #---------------------------------------------# 
        video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link) 
        for videodgelen in video: 
                url =videogelen 
                cozucu.magix_player(name,url) 
        #---------------------------------------------# 
        divxstage=re.compile('src="(.*?)divxstage(.*?)"').findall(link) 
        for url,divxstagegelen in divxstage: 
                url = str(url)+'divxstage'+str(divxstagegelen).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #---------------------------------------------# 
        #---------------------------------------------# 
        #---------------------------------------------# 
        if not urlList: 
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link) 
                print match 
                if match: 
                        for url in match: 
                                VIDEOLINKS(name,url) 
         
        if urlList: 
                Sonuc=playerdenetle(name, urlList) 
                for name,url in Sonuc: 
                        araclar.addLink(name,url,'') 
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='') 
                        listitem.setInfo('video', {'name': name } ) 
                        playList.add(url,listitem=listitem) 
                xbmcPlayer.play(playList) 
       
def playerdenetle(name, urlList): 
        value=[] 
        import cozucu 
        for url in urlList if not isinstance(urlList, basestring) else [urlList]: 
  
  
                if "mail.ru" in url: 
                    value.append((name,cozucu.MailRu_Player(url))) 
                      
        if  value: 
            return value 
  
  
def LiveTvShowsOynat(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
    xbmcPlayer = xbmc.Player() 
    playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 
    playList.clear() 
    araclar.addLink(name,url,'') 
    listitem = xbmcgui.ListItem(name) 
    playList.add(url, listitem) 
    xbmcPlayer.play(playList) 
  
def UrlResolver_Player(name,url):
##        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
##        link=araclar.get_url(base64.b64decode(web))
##        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
##        for bul in match:
##                bul=''
##                print bul
        UrlResolverPlayer = url 
        playList.clear() 
        media = urlresolver.HostedMediaFile(UrlResolverPlayer) 
        source = media 
        if source: 
                url = source.resolve() 
                araclar.addLink(name,url,'') 
                araclar.playlist_yap(playList,name,url) 
                xbmcPlayer.play(playList) 
