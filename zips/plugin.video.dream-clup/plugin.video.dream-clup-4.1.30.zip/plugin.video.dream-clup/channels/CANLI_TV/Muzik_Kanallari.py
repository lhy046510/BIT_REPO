# -*- coding: utf-8 -*- c by happyfeets
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Muzik_Kanallari"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        Karma='http://www.xbmctr.com/'
        trradyo='http://canliradyodinle.gen.tr/showradyo.htm'
        araclar.addDir(fileName,'[COLOR red][B]>>  Bilgilendirme  <<[/B][/COLOR] ', "INFO(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/unlem.png')
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR orange][B] Tum Radyolar [/B][/COLOR]', "trradyo(url)",trradyo,"http://a1.mzstatic.com/us/r30/Purple6/v4/32/fe/60/32fe6085-6843-3180-7bf6-f7bd6cbcc794/icon_256.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B] Karma[/B][/COLOR] [COLOR red]>>>>[/COLOR][COLOR turquoise] ARA [/COLOR][COLOR red]<<<<[/COLOR]', "KarmaSearch()", "",'special://home/addons/plugin.video.dream-clup/resources/images/KARMA.png')
        

def trradyo(url):
        link=araclar.get_url(url)
        #link=link.replace('rtmp://$OPT:rtmp-raw=',"")
        match=re.compile('<font color=".*?">&nbsp;<img border="0" src="images/buton.gif">&nbsp; </font><a title=".*?" href="(.*?)"><strong>(.*?)</strong></a></font>').findall(link)
        if match >0:
                del match[1]#radyod
                for url,name in match:
                        url='http://canliradyodinle.gen.tr/'+url
                        araclar.addDir(fileName,'[COLOR blue]>> [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]',"trradyoo(url)",url,'http://www.akdeniz-elektronik.com/wp-content/uploads/akdeniz-sub-woofer-slider.png')

def trradyoo(url):
        link=araclar.get_url(url)
        match=re.compile('<iframe src="(.*?)" name="ekran" ').findall(link)
        for url in match:
                url='http://canliradyodinle.gen.tr/'+url
                name='Yayin Baslasin'
                araclar.addDir(fileName,'[COLOR blue]>> [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]',"trOynat(name,url)",url,'http://www.akdeniz-elektronik.com/wp-content/uploads/akdeniz-sub-woofer-slider.png')

def trOynat(name,url):
        link=araclar.get_url(url)
        link=link.replace('amp;','')
        rtmp=re.compile('rtmp://(.*?)\&file\=(.*?)\&').findall(link)
        for rt,playpath in rtmp:
                playpath=' playpath='+playpath+' swfUrl=http://canliradyodinle.gen.tr/crd/jwplayer.swf pageUrl='+url+' live=1'
                rt='rtmp://'+rt+playpath
                playList.clear()
                araclar.addLink(name,rt,'http://radyo.lolturk.net/images/wmp.png')
                listitem = xbmcgui.ListItem(name)
                playList.add(rt, listitem)
                xbmcPlayer.play(playList)

        show=re.compile('rtmp://(.*?)\&').findall(link)
        for url in show:
                url='rtmp://'+url
                playList.clear()
                araclar.addLink(name,url,'http://www.avsmedia.com/images/big_icons/AudioEditor.gif')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

        http=re.compile('http://(.*?)\&').findall(link)
        for url in http:
                url='http://'+url
                playList.clear()
                araclar.addLink(name,url,'http://www.artecacademymiami.com/wp-content/uploads/2013/10/audio_icon.jpg')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

        best=re.compile(' src="http://(.*?)\r\n" autostart=".*?"').findall(link)
        for url in best:
                url='http://'+url
                playList.clear()
                araclar.addLink(name,url,'http://media.economist.com/sites/default/files/custom_promotions_content/ec_promotions_audio_large.png')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

        seymen=re.compile('socket://(.*?)/;stream.nsv').findall(link)
        for url in seymen:
                url='http://'+url+'/;stream.nsv'
                playList.clear()
                araclar.addLink(name,url,'http://www.citynmb.com/vertical/Sites/%7B7D026603-3FD1-47D7-B72B-A998702CDBDA%7D/uploads/large_audio.gif')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

##def trOynat(url):
##        link=araclar.get_url(url)
##        link=link.replace('amp;','')
##        match=re.compile(' flashvars="\&autostart=true\&streamer=(.*?)\&stretching\=.*?').findall(link)
##        for url in match:
##                name='Yayin Baslasin'
##                playList.clear()
##                araclar.addLink(name,url,'http://radyo.lolturk.net/images/wmp.png')
##                listitem = xbmcgui.ListItem(name)
##                playList.add(url, listitem)
##                xbmcPlayer.play(playList)  
##############################################################
def KarmaSearch():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            url = ('http://www.myvideo.az/c/search?srch_str='+query)
            KarmaYeni(url)

def KarmaYeni(url):
        link=araclar.get_url(url)  
        match=re.compile('<a href="\?video_id\=(.*?)" class=".*?">(.*?)</a>').findall(link)
        for url,name in match:
            name=name.replace('&#039;','&')
            url='http://www.myvideo.az/?video_id='+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"KarmaVIDEOLINKS(name,url)",url,"")
        sayfalama=re.compile('<li class="selected">1</li><li><a href="(.*?)" >(.*?)</a>').findall(link)
        for url,name in sayfalama:
            url='http://www.myvideo.az/'+url
            url=url.replace('amp;','')
            print url,name
            araclar.addDir(fileName,'[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',"KarmaYeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")                     

def KarmaVIDEOLINKS(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()

        link=araclar.get_url(url)
        match=re.compile("'http://(.*?).mp4\'").findall(link)
        for url in match:
                url='http://'+url+'.mp4?start=0'
        playList.add
        araclar.addLink(name,url,'')
        xbmcPlayer = xbmc.Player()
        xbmcPlayer.play(playList)
##############################################################

def EmirErimSearch():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            url = ('http://www.youtube.com/user/muyap/search?query='+query)
            EmirErimYeni(url)

def EmirErimYeni(url):
        link=araclar.get_url(url)  
        match=re.compile('title="(.*?)"\n        data-sessionlink=".*?"\n        href="\/watch\?v=(.*?)"\n').findall(link)
        for name,a in match:
            thumbnail='http://i1.ytimg.com/vi/'+a+'/hqdefault.jpg'
            url='http://www.youtube.com/watch?v='+a
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKSEmirErim(url)",url,thumbnail)

def VIDEOLINKSEmirErim(url):
    xbmcPlayer = xbmc.Player()
    playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playList.clear()
    link=araclar.get_url(url) 
    link=link.replace('\xf6',"o").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")
    you_match=re.compile('<link rel="canonical" href="http:\/\/www.youtube.com\/watch\?v\=(.*?)">').findall(link)
    for url in you_match:
        url='http://www.youtube.com/embed/'+url
        Sonuc=cozucu.videobul(url)
        if Sonuc=="False":
            dialog = xbmcgui.Dialog()
            i = dialog.ok(name,"Site uyarisi","     Film Siteye henuz yuklenmedi   ","  Yayinlandiktan sonra yuklenecektir.  ")
            return False
        else:
            for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
                            araclar.addLink(name,url,'')
                            araclar.playlist_yap(playList,name,url)
            xbmcPlayer.play(playList)
##############################################################

def INFO(name):
  try:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(name, "[COLOR pink]Muzik Bizim isimiz[/COLOR]","[COLOR orange]Radyo yetmedi diyenler icin ozel aramayi kullaniniz[/COLOR]")
  except:
        
        pass
##############################################################

