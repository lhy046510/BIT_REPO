# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


#------------------eklenecek kısım------------------
import araclar,cozucu
addon_id = 'plugin.video.dream-clup'
__settings__ = xbmcaddon.Addon(id=addon_id)
__language__ = __settings__.getLocalizedString

#---------------------------------------------------
web='aHR0cDovL3hibWN0ci5jb20vYmVzaXIv'

fileName="EUROTV"
#--------------- YENI KOMUTLAR  --------------------
# sayfa taratma --> araclar.get_url(url)
# klasor ekleme --> araclar.addDir(fileName,name, mode, url="", thumbnail="")
# link ekleme   --> araclar.addLink(name,url,thumbnail)
# videolink bulma --> urlList=cozucu.videobul(url)
# sonrasında     --> for url in urlList if not isinstance(urlList, basestring) else [urlList]:
#                               araclar.addlink(name,url,thumbnail) yada playList.add(url)
#---------------------------------------------------
        
def main():
        araclar.addDir(fileName,__language__(30030), "BuildPage(code='tr',dil='TR.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/tr.png')
        araclar.addDir(fileName,__language__(30031), "BuildPage(code='de',dil='Alman.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/de.png')
        araclar.addDir(fileName,__language__(30035), "BuildPage(code='sn',dil='Sinema.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/sn.png')
        araclar.addDir(fileName,__language__(30034), "BuildPage(code='klp',dil='Klipler.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/klp.png')
        araclar.addDir(fileName,__language__(30029), "BuildPage(code='rdy',dil='Radyo.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/rdy.png')

                

def BuildPage(code,dil):
    a=0
    link=araclar.get_url(base64.b64decode(web)+dil)
    tr=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    de=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    sn=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    klp=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    rdy=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    
    if code is 'tr':
         for videoTitle,Url,Thumbnail in tr:
              a=a+1
              araclar.addLink(str(a)+' - '+videoTitle,Url,Thumbnail)
    else:
        pass
    if code is 'de':
          for videoTitle,Url,Thumbnail in de:
               a=a+1
               araclar.addLink(str(a)+' - '+videoTitle,Url,Thumbnail)
    else:
        pass
    if code is 'sn':
          for videoTitle,Url,Thumbnail in sn:
               a=a+1
               araclar.addLink(str(a)+' - '+videoTitle,Url,Thumbnail)
    else:
        pass
    if code is 'klp':
          for videoTitle,Url,Thumbnail in sn:
               a=a+1
               araclar.addLink(str(a)+' - '+videoTitle,Url,Thumbnail)
    else:
        pass
    if code is 'rdy':
          for videoTitle,Url,Thumbnail in sn:
               a=a+1
               araclar.addLink(str(a)+' - '+videoTitle,Url,Thumbnail)
    else:
        pass


def INFO(url):
  try:
        #CATEGORIES()
        dialog = xbmcgui.Dialog()
        i = dialog.ok(url, "www.xmbctr.com TEAM katkilariyla","Iyi seyirler dileriz...","Hazirlayan @Besir")
  except:
        #print "Hata olustu"
        pass 
