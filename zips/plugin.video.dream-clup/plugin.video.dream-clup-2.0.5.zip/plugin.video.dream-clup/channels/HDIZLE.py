# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="HDIZLE"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


############# ANA GIRIS KLASORLERI ##############################
def main():
        url='http://www.hdfilmsitesi.com'
        #araclar.addDir(fileName,name,"mode(name,url)",url,thumbnail)
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","special://home/addons/plugin.video.dream-clup/resources/images/ARAMA_SEARCH.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR][COLOR lightblue][B] Yeni Eklenen Filmler [/B][/COLOR]', "Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/yeni.png" )
        araclar.addDir(fileName,'[COLOR red][B]>>[/B][/COLOR][COLOR pink][B] Turkce Dublaj [/B][/COLOR]', "Edit(url)",'http://www.hdfilmsitesi.com/izle/filmler/yabanci-filmler/turkce-dublaj-filmler',"")
        araclar.addDir(fileName,'[COLOR gold][B]>>[/B][/COLOR][COLOR beige][B] TR Altyazili [/B][/COLOR]', "Edit(url)","http://www.hdfilmsitesi.com/izle/filmler/yabanci-filmler/turkce-altyazili-filmler","")
        araclar.addDir(fileName,'[COLOR green][B]>>[/B][/COLOR][COLOR lightgreen][B] Boxset Filmler [/B][/COLOR]', "Edit(url)","http://www.hdfilmsitesi.com/izle/boxset-filmler","")
        araclar.addDir(fileName,'[COLOR purple][B]>>[/B][/COLOR][COLOR gold][B] IMDB 7.0 Uzeri [/B][/COLOR]', "Edit(url)","http://www.hdfilmsitesi.com/izle/filmler/yabanci-filmler/imdb-7-ve-uzeri-filmler","")
        ##### KATEGORILERI OKU EKLE ##########################
        
        #link=araclar.get_url(url)
        #match=re.compile('<a href="http://www.baglanfilmizle.com/film-izle/kategoriler/(.*?)"><span class="kat"><span class="iki">(.*?)</span').findall(link)
        #for url,name in match:               
                #araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]' +'[COLOR beige][B]'+ name+'[/B][/COLOR]',"Yeni(url)",url,"")

###################################################################                

                                                
######                       
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://www.hdfilmsitesi.com/?s='+query)
            Dublaj(url)

############
def Yeni(url):
        link=araclar.get_url(url)  
        match=re.compile('</div> <img  src="(.*?)" alt=".*?" title=".*?" width="135" height="180" /><a href="(.*?)" title=".*?" class="play">(.*?)</a></div>').findall(link)
        for thumbnail,url,name in match:
                #url = url+'/2'
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)

        page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?) class=\'page larger\'>(.*?)</a>').findall(link)
        
        for url,name in page:
                araclar.addDir(fileName,'[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',"Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")                     
        
###########        
def Edit(url):
        link=araclar.get_url(url)       
        match=re.compile('</div><img alt=".*?" src="(.*?)" title=".*?" width="135" height="180" /><a href="(.*?)" title=".*?" class="play">(.*?)</a></div>').findall(link)
        for thumbnail,url,name in match:
                #url = url+'/2'
                araclar.addDir(fileName,'[COLOR lightblue][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
                
        page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?) class=\'page larger\'>(.*?)</a>').findall(link)
        
        for url,name in page:
                araclar.addDir(fileName,'[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',"Edit(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png") 
                                
###########
def Dublaj(url):
        link=araclar.get_url(url)  
        match=re.compile('</div> \r\n   \r\n\t\t\t\t\r\n\r\n\t\t\r\n\r\n<img alt=".*?" src="(.*?)" title=".*?" width="135" height="180" /><a href="(.*?)" title="(.*?)" class="play">izle</a>\r\n\r\n\r\n\r\n</div>').findall(link)
        for thumbnail,url,name in match:
                araclar.addDir(fileName,'[COLOR pink][B]'+name+'[/B][/COLOR]',"tek(url)",url,thumbnail)
                
        page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?) class=\'page larger\'>(.*?)</a>').findall(link)
        for url,name in page:
                araclar.addDir(fileName,'[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',"Dublaj(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")



        
#############
def VIDEOLINKS(name,url):
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        vk_1=re.compile('src="http://vk.com/(.*?)"').findall(link)
        for url in vk_1:
                url = 'http://vk.com/'+str(url)
                url=url.strip(' \t\n\r').replace("&amp;","&").replace("?rel=0","").replace(";=","=")
                #-----------------------#
                urlList.append(url)
                #-----------------------#
        try:
                code=re.match(r"http://www.youtube.com/embed/(.*?)$", url).group(1)
                url='plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code)
                urlList.append(url)
        except:
                pass
        if not urlList:
                match=re.compile('<li><h1><a  href="(.*?)"').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                dialog = xbmcgui.Dialog()
                karar=("izle","indir- Henuz yapılmadı")
                ret = dialog.select(__language__(30008),karar)
        
                if ret == 0:
                        Sonuc=cozucu.videobul(urlList)
                        for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
                                araclar.addLink(name,url,'')
                                araclar.playlist_yap(playList,name,url) 
                        xbmcPlayer.play(playList)

                if ret == 1:
                        Sonuc=cozucu.videobul(urlList)
                        urlList=[]
                        for isim,new_url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
                                urlList.append(new_url)  
                        araclar.indir(isim,urlList)
        else:
             return araclar.hata()
             
        

