# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu
from BeautifulSoup import BeautifulSoup

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="WEBTEIZLE"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

web = 'http://www.webteizle.com/'
web2 = 'http://www.webteizle.com/filmyili.asp'
############# ANA GIRIS KLASORLERI ##############################
def main():
        url='http://www.webteizle.com'
        #araclar.addDir(fileName,name,"mode(name,url)",url,thumbnail)
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","special://home/addons/plugin.video.dream-clup/resources/images/ARAMA_SEARCH.png")
        araclar.addDir(fileName,'[COLOR pink][B]>>[/B][/COLOR] [COLOR beige][B]Yerli Dizi En Yeni Bolumler [/B][/COLOR]', "Hepsi(url)","http://www.webteizle.com/YerlidiziFilmler.asp","" )
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR beige][B]Yeni Eklenen Filmler [/B][/COLOR]', "Hepsi(url)","http://www.webteizle.com/filmyili.asp","special://home/addons/plugin.video.dream-clup/resources/images/yeni.png" )
        araclar.addDir(fileName,'[COLOR beige][B]>>[/B][/COLOR] [COLOR beige][B]Yabanci Filmler [/B][/COLOR]', "Hepsi(url)","http://www.webteizle.com/YabanciFilmler.asp","")
        araclar.addDir(fileName,'[COLOR gold][B]>>[/B][/COLOR] [COLOR beige][B]Yerli Filmler [/B][/COLOR]', "Hepsi(url)","http://www.webteizle.com/YerliFilmler.asp","")
        araclar.addDir(fileName,'[COLOR green][B]>>[/B][/COLOR] [COLOR beige][B]Belgeseller [/B][/COLOR]', "Hepsi(url)","http://www.webteizle.com/BelgeselFilmler.asp","")
        araclar.addDir(fileName,'[COLOR purple][B]>>[/B][/COLOR] [COLOR beige][B]Turkce Dublaj Filmler [/B][/COLOR]', "Hepsi(url)","http://www.webteizle.com/tr-dublaj-filmler","")
        araclar.addDir(fileName,'[COLOR yellow][B]>>[/B][/COLOR] [COLOR beige][B]Turkce Altyazili Filmler [/B][/COLOR]', "Hepsi(url)", "http://www.webteizle.com/tr-altyazili-filmler","")
        araclar.addDir(fileName,'[COLOR orange][B]>>[/B][/COLOR] [COLOR beige][B]Cocuk Filmleri [/B][/COLOR]', "Hepsi(url)","http://www.webteizle.com/CizgiFilmler.asp","")
        ##### KATEGORILERI OKU EKLE ##########################
        
        #link=araclar.get_url(url)
        #match=re.compile('<a href="http://www.baglanfilmizle.com/film-izle/kategoriler/(.*?)"><span class="kat"><span class="iki">(.*?)</span').findall(link)
        #for url,name in match:
                #url=web+url                
                #araclar.addDir(fileName,'[COLOR orange][B]>> ' + name+'[/B][/COLOR]',"Yeni(url)",url,"")

###################################################################                

                                                
######                       
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://www.webteizle.com/Arama.asp?Sozcuk='+query+'&Kategori=yabanci')
            Arama(url)

############
def Yeni(url):
        link=araclar.get_url(url)  
        match=re.compile('<a href="(.*?)" class="red-link" title=".*?"><img src="(.*?)" alt="(.*?)" style="border-width: 0px; height: 150px; width: 110px;"').findall(link)
        for url,thumbnail,name in match:
                url=web+url
                #url = url+'/2'
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)

        soup = BeautifulSoup(link)
        x=soup.find("div", {"style": "float:left;clear:both;"})
        y=x('a')[0]['href']
        print y
        araclar.addDir(fileName,'[COLOR purple][B]>>Sonraki Sayfa[/B][/COLOR]',' ','Yeni(url)','special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png')                   
        
###########        

                                
###########
def Hepsi(url):
        link=araclar.get_url(url)  
        match=re.compile('<a href="(.*?)" class="red-link" title=".*?"><img src="(.*?)" alt="(.*?)" style="border-width: 0px; height: 150px; width: 110px;"').findall(link)
        for url,thumbnail,name in match:
                url=web+url
                araclar.addDir(fileName,'[COLOR pink][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
                
        soup = BeautifulSoup(link)
        x=soup.find("div", {"style": "float:left;clear:both;"})
        y=x('a')[0]['href']
        print y
        araclar.addDir(fileName,'[COLOR purple][B]>>Sonraki Sayfa[/B][/COLOR]',web2+y,'Hepsi(url)','special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png')


def Arama(url):
        link=araclar.get_url(url)  
        match=re.compile('<a href="(.*?)" class="red-link" title=".*?"><img src="(.*?)" alt="(.*?)" style="border-width: 0px; height: 150px; width: 110px;" /></a>').findall(link)
        for url,thumbnail,name in match:
                url=web+url
                thumbnail=web+thumbnail
                araclar.addDir(fileName,'[COLOR pink][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)

    

        
#############
def VIDEOLINKS(name,url):
        link=araclar.get_url(url)  
        match=re.compile('src=\'http://embed.divxstage.eu/(.*?)&').findall(link)
        print match
        for url in match:
                url='http://embed.divxstage.eu/'+url
                print url
                Sonuc=cozucu.videobul(url)
                print "donen sonuc",Sonuc
                for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
                        print "isim:",name,"url:",url
                        araclar.addLink(name,url,'')
        match=re.compile('src="http://vk.com/(.*?)"').findall(link)
        print match
        for url in match:
                url='http://vk.com/'+url
                print url
                Sonuc=cozucu.videobul(url)
                print "donen sonuc",Sonuc
                for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
                        print "isim:",name,"url:",url
                        araclar.addLink(name,url,'')
        match=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link)
        print match
        for url in match:
                url='http://www.youtube.com/embed/'+url
                print url
                Sonuc=cozucu.videobul(url)
                print "donen sonuc",Sonuc
                for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
                        print "isim:",name,"url:",url
                        araclar.addLink(name,url,'')
        match=re.compile('src=\'http://embed.movshare.net/(.*?)&').findall(link)
        print match
        for url in match:
                url='http://embed.movshare.net/'+url
                print url
                Sonuc=cozucu.videobul(url)
                print "donen sonuc",Sonuc
                for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
                        print "isim:",name,"url:",url
                        araclar.addLink(name,url,'')

