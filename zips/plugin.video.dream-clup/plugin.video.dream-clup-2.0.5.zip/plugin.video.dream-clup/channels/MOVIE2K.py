# -*- coding: iso-8859-9 -*-
import urllib,urllib2,re,sys
# xbmctr MEDIA CENTER, is an XBMC add on that sorts and displays 
# video content from several websites to the XBMC user.
#
# Copyright (C) 2011, Emin Ayhan Colak
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# for more info please visit http://xbmctr.com

import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import araclar,cozucu
import urlresolver
from t0mm0.common.net import Net
from BeautifulSoup import BeautifulSoup as BS
Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName = "MOVIE2K"


'''Constants'''
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


def main():
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","special://home/addons/plugin.video.dream-clupdream-clup/resources/images/ARAMA_SEARCH.png")
        araclar.addDir(fileName,'[COLOR brown][B]>>[/B][/COLOR][COLOR beige][B] Yeni Eklenen Filmler [/B][/COLOR]', "scan2(url)", "http://www.movie2k.to/movies-updates.html","special://home/addons/plugin.video.dream-clup/resources/images/yeni.png")
        base="http://www.movie2k.to/index.php?lang="
        urllist=["us","de","tr","es","fr","it","jp","ru"]
        for code in urllist:
                url=base+code
                if code=="us" or code=="de" :
                        araclar.addDir(fileName,code, "scan1(url)",url,"search")
                else:
                        araclar.addDir(fileName,code, "scan2(url)",url,"search")
def scan1(url):
        link=araclar.get_url(url)
        rec=re.compile('<a href="(.*?)" ><img src="(.*?)" border=0 style="width:105px;max-width:105px;max-height:160px;min-height:140px;" alt="(.*?)" title=".*?">').findall(link)
        for url,thumbnail,name in rec:
                url='http://www.movie2k.to/'+url
                araclar.addDir(fileName,name+' - 1',"Serverlist(name,url)",url,thumbnail)
        
        rec2=re.compile('<a href="(.*?)" ><img src="(.+?)" alt=".*?" title="(.*?)"').findall(link)
        for url,thumbnail,name in rec2:
                thumbnail=thumbnail.replace('" border=0 style="width:105px;max-width:105px;max-height:160px;min-height:140px;','')
                name=name.replace('watch ','').replace('for','').replace('free','').replace('online','')
                url='http://www.movie2k.to/'+url
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+ name+'[/B][/COLOR]',"Serverlist(name,url)",url,thumbnail)
def scan2(url):
        link=araclar.get_url(url)
        soup=BS(link)
        div = soup.findAll("table",{"id":"tablemoviesindex"})
        td= BS(str(div)).findAll("td",{"width":"550"})
        for x in td:
            url= x.a['href']
            name= x.text.encode("utf-8")
            url='http://www.movie2k.to/'+url
            araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+ name+'[/B][/COLOR]',"Serverlist(name,url)",url,"")
def Serverlist(name,url):
        playList.clear()
        urlList=[]
        link=araclar.get_url(url)
        link=link.replace('\\',"")
        soup = BS(link)
        serverlist=['Yesload','Movshare','Novamov','Stream2k','Divxstage','Flashx','Putlocker']
        for div in soup.findAll('tr',  {"id": "tablemoviesindex2"},smartQuotesTo=None):
            name = div.a.text
            name=name.replace("&nbsp;"," / ")
            date=re.match('(.*?)/.*?',name).group(1)
            name=name.lstrip('0123456789 \./')
            url= 'http://www.movie2k.to/'+str(div.find('a')['href'])
            thumbnail= div.find('img')['src']
            print ('CHOOSE SONUCU',name,date,url)
            if name in serverlist:
                    araclar.addDir(fileName,name,"resolve(name,url)",url,"")


                
def resolve(name,url):
        if xbmcPlayer.isPlaying():
                xbmcPlayer.stop()
        playList.clear()

        url=Match(url)

        
        urlList=cozucu.videobul(url)
        print "cozucu cevap:",urlList
        
        if  urlList:
                for name,url in urlList if not isinstance(urlList, basestring) else [urlList]:
                        print "final isim url",name,url
                        araclar.playlist_yap(playList,name,url)
                        araclar.addLink(name,url,"")
                xbmcPlayer.play(playList)
        

def Match(url):
        link=araclar.get_url(url)
        soup = BS(link)
        match=re.compile('<a target="_blank" href="(.*?)"><img border=0 src="http://img.movie2k.to/img/click_link.jpg" alt=".*?" title=".*?" width="742"></a>').findall(link)
        if match:
                url=match[0]
                return url
        match=re.compile('<div id="emptydiv"><script type="text/javascript" src="(.*?)">').findall(link)
        if match:
                url=match[0]
                return url
        match=re.compile('<div id="emptydiv"><iframe src="(.*?)" width="600" height="360" frameborder="0" scrolling="no">').findall(link)
        if match:
                url=match[0]
                return url
        
        else:
                try:
                        for div in soup.findAll('div',{"id":"emptydiv"}):
                            url=str(div.find('iframe')['src'])
                except:
                        url="http://www.youtube.com/watch?v=dZhjUcGTZ2c"
                return url
def thumb(url):  
        match=re.compile('(.*?)online-film-(.*?).html').findall(url)
        for x,y in match:
                url='http://img.movie2k.to/thumbs/cover-'+y+'-'+x+'movie2k-film.jpg'
        return url
##        http://img.movie2k.to/thumbs/cover-2084866-Berserk-The-Golden-Age-Arc-The-Egg-of-the-King-movie2k-film.jpg
##        <a href="Berserk-The-Golden-Age-Arc-The-Egg-of-the-King-online-film-2084866.html
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=araclar.name_fix(query)       
            Url = ('http://www.movie2k.to/searchAutoCompleteNew.php?search=' + query)
            link=araclar.get_url(Url)
            soup = BS(link)
            for tr in soup.findAll('tr'):
                name= tr.a.text
                name=name.encode("utf-8")
                url= u'http://www.movie2k.to/'+str(tr.find('a')['href'])
                url=url.encode("utf-8")
                print 'adres 1',url
                match=search_choose(url)
                for url,name in match:
                        url=url.strip(' \t\n\r')
                        name=name.strip(' \t\n\r')
                        url='http://www.movie2k.to/'+str(url)
                        araclar.addDir(fileName,name,"Serverlist(name,url)",url,"")

def search_choose(url):
        link=araclar.get_url(url)
        match=re.compile('\t\t<TD width="550" id="tdmovies">\n            \t\t    <a href="(.*?)">(.*?)\t\t ').findall(link)
        return match
def Recent(url):
        link=araclar.get_url(url)
        soup = BS(link)
        for div in soup.findAll('tr',  {"id": "tablemoviesindex"},smartQuotesTo=None):
            name = div.a.text
            name=name.replace("&nbsp;"," / ")
            url= div.find('a')['href']
            print 'URL',url
            araclar.addDir(fileName,name+' - DE',"reise(name,url)",url,"")
            
def MAINMENU(Url):
         araclar.addDir(fileName,'<<<'+__language__(30002),"main()",'',"")

