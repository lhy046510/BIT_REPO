# -*- encoding: utf-8 -*- 
"""
 Plugin for accessing videos on http://www.iprima.cz/archiv
"""

import sys
from lib.xbmcPluginInterface import *

# plugin constants 
__plugin__ = "PrimaTV"
__author__ = "Miroslav Vit"
__version__ = "1.0"


def run():
    from primatvPlugin import PrimatvPlugin
    iface = XBMCPluginInterface("plugin.video.xbmc-czech.PrimaTV")
    plugin = PrimatvPlugin( iface )
    plugin.call( *sys.argv )


if __name__ == '__main__':
    run()

