# -*- encoding: utf-8 -*- 
""" PrimaTV plugin for accessing prima.stream.cz videos from XBMC """

__all__ = ["PrimatvPlugin"]

from lib.basePlugin import *
import urlparse
from lib.parseutils import *
import re
import time
import datetime

CDN_URL  = "http://cdn-dispatcher.stream.cz/?id=%d"
RE_CDN_ID_LQ = re.compile('cdnLQ=(\d+)')
RE_CDN_ID_HQ = re.compile('cdnHQ=(\d+)')
RE_CDN_ID_HD = re.compile('cdnHD=(\d+)')

class PrimatvPlugin(BasePlugin):
    """ PrimaTV plugin class """
    BASE_URL = "http://prima.stream.cz"


    @plugin_folder
    def root(self):
        """ plugin root folder """
        self.core.setSorting('NONE')
        
        url = self.BASE_URL
        self.wget.request(url)
        
        for item in self.wget.select('#sekce_kanalu a'):
            title = item.getText(" ").encode('utf-8')
            yield PFolder(label=title, call='PrimaProgramDirectory', param={'path': item['href']})


    @plugin_folder
    def PrimaProgramDirectory(self, path):
        """ list newest videos """
        self.core.setSorting('NONE')

        url = path
        doc=read_page(url)
        items=doc.find('div', id='videa_kanalu_list')

        for item in items.findAll('div', 'kanal_1video'):
            img = item.find('a', 'kanal_1video_pic')
            img = img['style']
            img = img[(img.find('url(') + len('url(') + 1):] 
            img = img[:(img.find(')') - 1)]

            title = item.find('a', 'kanal_1video_title')
            title_name = title.getText(" ").encode('utf-8')

            url_episode = title['href']

            comment = item.find('div', 'kanal_1video_text')
            comment = comment.getText(" ").encode('utf-8')


            info = {
                     'title': str(title_name),
                     'plot': str(comment)
                   }

            yield PItem(
                         label   = str(title_name),
                         call    = 'play',
                         param   = {'path': url_episode},
                         info    = info,
                         iconURL = img
                         )

        
        try:
          items = doc.find('div', 'paging')
        
          for item in items.findAll('a'):
              page = item.text.encode('utf-8') 
              if re.match('další', page, re.U):
                 yield PFolder(u'<Další strana>', 
                             call='PrimaProgramDirectory',
                             param={'path': self.BASE_URL + item['href']}
                         )
        except:
          self.debug('no paging')

    @plugin_call
    def play(self, path):
        """ Play video """
        url = path
        self.core.newProgress('Prima TV', u'Načítám video stream')
        self.core.updateProgress(30)
        self.debug('play url: '+repr(url))
        self.wget.request( url )
        body = self.wget.select_first('body')
        title = body.select_first('#player_detail h1') \
                or body.select_first('#detail_player h1') \
                or body.select_first('.col_main_b h1') \
                or body.select_first('h1')
        plot = body.select_first('#player_detail_popisek') \
                or body.select_first('.player_detail_text') \
                or body.select_first('#video_popisek')

        info = {}
        if plot and plot.text:
            info['plot'] = plot.text
        item = PItem(
                    label=title.text,
                    info=info,
                )
        player = body.select_first('#player')
        if not player:
            raise Exception("#player not found! - url: " + url)

        self.core.updateProgress(60)

        video_lq = RE_CDN_ID_LQ.search(unicode(player))
        video_hq = RE_CDN_ID_HQ.search(unicode(player))
        video_hd = RE_CDN_ID_HD.search(unicode(player))

        if (not video_lq) and (not video_hq) and (not video_hd):
           raise Exception("RE_CDN_ID not found!")
           
        stream_url = ''
        
        quality = int(self.core.getSetting('quality'))
        
        try:
          if int(quality) == 0:
             self.debug('quality = HD')
             stream_url = CDN_URL % int(video_hd.group(1))
        except:
             quality = 1
             self.debug('ID for HD video not found!')
             
                
        try:
          if int(quality) == 1:
             self.debug('quality = HQ')
             stream_url = CDN_URL % int(video_hq.group(1))
        except:
             quality = 2
             self.debug('ID for HQ video not found!')


        try:
          if int(quality) == 2:
             self.debug('quality = LQ')
             stream_url = CDN_URL % int(video_lq.group(1))
        except:
             self.debug('ID for LQ video not found!')

        self.core.updateProgress(90)

        if stream_url == '':
           raise Exception("For select quality video not found!")

        self.debug('streamURL: '+repr(stream_url) )

        self.core.play(stream_url, item)

        self.core.closeProgress()

