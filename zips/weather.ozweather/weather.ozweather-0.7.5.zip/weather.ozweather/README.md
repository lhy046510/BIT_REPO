Script for XBMC for Australian weather.  Available from XBMC master repository (i.e. don't install from here - just go to Addons -> Get Addons -> Weather -> OzWeather)

Uses BOM data and retrieves current conditions, 7 day forecast, and radar images.

Script works fine standalone for standard high quality Australian weather data, but you need to make skin changes for the best bit which is BOM radar support.  See wiki page for full details.

http://wiki.xbmc.org/index.php?title=Add-on:Oz_Weather

