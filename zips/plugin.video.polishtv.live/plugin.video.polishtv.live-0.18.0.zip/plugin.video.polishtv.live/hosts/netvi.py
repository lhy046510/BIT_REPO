# -*- coding: utf-8 -*-
import os, sys, re
import xbmcgui, xbmc, xbmcaddon, xbmcplugin

if sys.version_info >= (2,7): import json as _json
else: import simplejson as _json 

scriptID = 'plugin.video.polishtv.live'
scriptname = "Polish Live TV"
ptv = xbmcaddon.Addon(scriptID)

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append (os.path.join(BASE_RESOURCE_PATH, "lib"))
LOGOURL = 'http://sd-xbmc.org/repository/xbmc-addons/netvi.png'

import sdLog, sdSettings, sdParser, sdCommon, sdErrors, sdNavigation

log = sdLog.pLog()
dbg = sys.modules[ "__main__" ].dbg
dstpath = ptv.getSetting('default_dstpath')

SERVICE ='netvi'
COOKIEFILE = ptv.getAddonInfo('path') + os.path.sep + "cookies" + os.path.sep + SERVICE +".cookie"
API = 'https://api.netvi.tv'
STREAMFORMAT =1 #1-rtmp, 2-hls

username = ptv.getSetting('netvi_login')
password = ptv.getSetting('netvi_password')

class netvi:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.settings = sdSettings.TVSettings()
	self.parser = sdParser.Parser()
	self.exception = sdErrors.Exception()
	self.common = sdCommon.common()
	self.gui = sdNavigation.sdGUI()


    def login(self):
        self.common.checkDir(ptv.getAddonInfo('path') + os.path.sep + "cookies")
        query_data = {'url': API + '/user/login', 'use_host': False, 'use_cookie': True, 'load_cookie': False, 'save_cookie': True, 'cookiefile': COOKIEFILE, 'use_post': True, 'return_data': True}
        data = self.common.getURLRequestData(query_data, {'login' : username, 'password' : password, 'permanent' : 1})
        
        result = _json.loads(data)
        retVal = False
        notification = '(netvi.tv,blad logowania,20000)'
        if result['status'] == 'ok':
            retVal = True
            notification = '(netvi.tv,zalogowano,5000)'
        xbmc.executebuiltin("XBMC.Notification" + notification +'"')
        return retVal


    def getStations(self):
        query_data = {'url': API + '/channels/list/xbmc', 'use_host': False, 'use_cookie': True, 'load_cookie': True, 'save_cookie': False, 'cookiefile': COOKIEFILE, 'use_post': False, 'return_data': True}
        data = self.common.getURLRequestData(query_data)
        result = _json.loads(data)
        channels = result['channels']
        for i in range(len(channels)):
            if channels[i]['access_status'] != 'unsubscribed':
		params = {'service': SERVICE, 'name': 'vURL', 'title': channels[i]['name'], 'page': channels[i]['id'], 'icon': channels[i]['thumbnail']}
		self.gui.addDir(params)
	self.gui.endDir()

    def addRek(self):
        query_data = {'url': API + '/ad/urls', 'use_host': False, 'use_cookie': True, 'load_cookie': True, 'save_cookie': False, 'cookiefile': COOKIEFILE, 'use_post': False, 'return_data': True}
        data = self.common.getURLRequestData(query_data)
        result = _json.loads(data)
        #print result
        rek = result['urls']
        pl=xbmc.PlayList(1)
        pl.clear()
        if len(rek) > 0:
            for i in range(len(rek)):
                #print rek
                query_data = {'url': rek[i], 'use_host': False, 'use_cookie': True, 'load_cookie': True, 'save_cookie': False, 'cookiefile': COOKIEFILE, 'use_post': False, 'return_data': True}
                data = self.common.getURLRequestData(query_data)
                #print data
                match = re.compile('http://(.+?)mp4').findall(data)
                if len(match) > 0:
                    url = 'http://' + match[0] + 'mp4'
                    #print url
                    listitem = xbmcgui.ListItem( 'Netvi.tv - reklama', thumbnailImage=LOGOURL)
                    listitem.setInfo( type="Video", infoLabels={ "Title": 'Netvi.tv - reklama' } )
                    xbmc.PlayList(1).add(url, listitem)
        return pl

 
    def getVideoUrl(self, page):
        query_data = {'url': API + '/channels/get/' + page + '?format_id=' + str(STREAMFORMAT), 'use_host': False, 'use_cookie': True, 'load_cookie': True, 'save_cookie': False, 'cookiefile': COOKIEFILE, 'use_post': False, 'return_data': True}
        data = self.common.getURLRequestData(query_data)
        result = _json.loads(data)
        videoUrl =''
        if 'stream_channel' in result:
            manifest = result['stream_channel']['url_base']
            query_data = {'url': result['stream_channel']['url_base'], 'use_host': False, 'use_cookie': True, 'load_cookie': True, 'save_cookie': False, 'cookiefile': COOKIEFILE, 'use_post': False, 'return_data': True}
            data = self.common.getURLRequestData(query_data)
            match = re.compile('<baseURL>(.+?)</baseURL>').findall(data)
            match1 = re.compile('<media url="(.*?)" bitrate').findall(data)
            if len(match) > 0:
                videoUrl = match[0]+' app='+page+'/_definst_ swfUrl=https://watch.netvi.tv/javascripts/libs/flowplayer/flowplayer.commercial-3.2.11.swf pageUrl=https://watch.netvi.tv/ live=true conn=S:'+result['stream_channel']['url_params'][1]+' conn=S:'+result['stream_channel']['url_params'][2]+' playpath='+match1[0]
                return videoUrl
            else:
                d = xbmcgui.Dialog()
                d.ok('Blad odtwarzania', 'lub kanal niedostepny','w tym abonamencie')
                
    def handleService(self):
        params = self.parser.getParams()
        name = self.parser.getParam(params, "name")
	title = self.parser.getParam(params, "title")
	category = self.parser.getParam(params, "category")
	page = self.parser.getParam(params, "page")

	self.parser.debugParams(params, dbg)
	
	if name == None:
            self.login()
            self.getStations() 
        if name == 'vURL':
            xbmc.Player().play(self.addRek())
            while xbmc.Player().isPlaying() == True:
                xbmc.sleep
            xbmc.sleep(500)
            while xbmc.Player().isPlaying() == True:
                xbmc.sleep
            self.gui.LOAD_AND_PLAY_VIDEO(self.getVideoUrl(page), title)
