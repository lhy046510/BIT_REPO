# -*- coding: utf-8 -*-
import os, string, StringIO
import urllib, urllib2, re, sys
import xbmcaddon, xbmcgui
import xbmc, traceback

#ToDo
#    Wybór hostingu - przebudować
#    dodaj w serialach: ostatnio aktualizowane, typ: oryginał/napisy/lektor

scriptID = sys.modules[ "__main__" ].scriptID
scriptname   = sys.modules[ "__main__" ].scriptname
ptv = xbmcaddon.Addon(scriptID)

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )
COOKIEFILE = ptv.getAddonInfo('path') + os.path.sep + "cookies" + os.path.sep + "ekinotv.cookie"
BASE_IMAGE_PATH = 'http://sd-xbmc.org/repository/xbmc-addons/'
LOGOURL = BASE_IMAGE_PATH + "ekinotv.png"
THUMB_NEXT = BASE_IMAGE_PATH + "dalej.png"

import sdLog, sdSettings, sdParser, urlparser, sdCommon, sdNavigation, sdErrors, downloader, sdMeta

log = sdLog.pLog()

sortby = ptv.getSetting('ekinotv_sort')
sortorder = ptv.getSetting('ekinotv_sortorder')
quality = ptv.getSetting('ekinotv_quality')
username = ptv.getSetting('ekinotv_login')
password = ptv.getSetting('ekinotv_password')
dstpath = ptv.getSetting('default_dstpath')
dbg = sys.modules[ "__main__" ].dbg

HOST = 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.2.18) Gecko/20110621 Mandriva Linux/1.9.2.18-0.1mdv2010.2 (2010.2) Firefox/3.6.18'
SERVICE = 'ekinotv'
MAINURL = 'http://www.ekino.tv/'
MAINURLSE = 'http://www.ekino.tv/seriale-online.html'
MAINURLSR = 'http://www.ekino.tv/szukaj-wszystko,'
POPULAR = ',wszystkie,wszystkie,1900-2013,.html?sort_field=odslony&sort_method=desc'
MOVIE3DURL = 'http://www.ekino.tv/gorace-filmy.html?mode=3d'

if username=='' or password=='':
    pr = ''
else:
    pr = '?premium&player=1'

SERVICE_MENU_TABLE =  {
    1: "Filmy [wg. gatunków]",
    2: "Filmy [lektor]",
    3: "Filmy [napisy]",
    4: "Filmy [dubbing]",
    5: "Filmy [polskie]",
    6: "Filmy [najpopularniejsze]",
    7: "Seriale",
    8: "Wyszukaj",
    9: "Historia Wyszukiwania",
    10: "Filmy 3D",
}

class EkinoTV:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.settings = sdSettings.TVSettings()
	self.parser = sdParser.Parser()
	self.up = urlparser.urlparser()
	self.cm = sdCommon.common()
	self.history = sdCommon.history()
	self.exception = sdErrors.Exception()
	self.gui = sdNavigation.sdGUI()
	self.meta = sdMeta.sdMeta()

    def setTable(self):
	return SERVICE_MENU_TABLE

    def listsMainMenu(self, table):
        tabMenu = []
        for num, val in table.items():
            tabMenu.append(val)
        tabMenu.sort()
        for i in range(len(tabMenu)):
            params = {'service': SERVICE, 'name': 'main-menu', 'title': tabMenu[i], 'category': tabMenu[i], 'icon': LOGOURL}
            self.gui.addDir(params)
        self.gui.endDir()

    def listsCategoriesMenu(self,url):
	query_data = { 'url': url, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	r = re.compile('<ul class="videosCategories">(.+?)<span>Wersja</span>', re.DOTALL).findall(data)
	if len(r)>0:
	    r2 = re.compile('<a href="(.+?).html">(.+?)</a>').findall(r[0])
	    if len(r2)>0:
		for i in range(len(r2)):
		    params = {'service': SERVICE, 'name': 'category', 'title': r2[i][1], 'category': r2[i][0], 'icon': LOGOURL}
		    self.gui.addDir(params)
	self.gui.endDir(True)

    def getFilmTable(self, url, category, pager):
	query_data = { 'url': url, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	#match = re.compile('class.+?src="(.+?)" alt=.+?</div>.\n.+?class=.+?>.\n.+?<h2><a title=.+?href="(.+?)">(.+?)</a></h2>').findall(data)
	match = re.compile('<div class="of".+?>.+?<img class="poster" src="(.+?)".+?<h2><a title.+?href="(.+?)">(.+?)</a></h2>.+?<h3><a.+?>(.+?)/a></h3>.+?<a href=".+?year=(.+?)".+?<p>(.+?)</p>', re.DOTALL).findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		page = MAINURL + match[i][1] + pr
                if '3D' in category:
                    suffix = '?mode=3d'
                    if 'premium' in pr:
                       suffix = pr + '&mode=3d' 
                    page = MAINURL + match[i][1] + suffix  
                if dbg:
                    log.info('ekinotv - getFilmTable page: %s' % (str(page)))
		params = {'service': SERVICE, 'dstpath': dstpath, 'title': match[i][2], 'page': page, 'icon': MAINURL + match[i][0].replace('_small', ''), 'originaltitle': match[i][3][:-1], 'year': match[i][4], 'plot': match[i][5]}
		self.gui.playVideo(params)
	match = re.compile('<li class="active"><a href=".+?">.+?</a></li>.\n.+?<li>').findall(data)
	if len(match) > 0:
	    params = {'service': SERVICE, 'name':'category', 'category': category, 'title': 'Następna strona', 'page': str(int(pager) + 1), 'icon': THUMB_NEXT}
	    self.gui.addDir(params)
	self.gui.endDir(False, 'movies')

    def listsSerialsMenu(self,table):
	for i in range(len(table)):
	    params = {'service': SERVICE, 'name': 'serial','category': table[i], 'title': table[i], 'icon': LOGOURL}
	    self.gui.addDir(params)
	self.gui.endDir()

    def getSerialTable(self, url, category, pager):
	query_data = { 'url': url, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('class="poster" src="(.+?)" alt=.+?/><span class=".+"?">.+?</span></div>.\n.+?<div class=".+?">.\n.+?<h2><a href="(.+?).html">(.+?)</a></h2>.\n.+?<(?:h3><a.+?>(.+?)</a></h3>)?').findall(data)
	if len(match) > 0:
	    pDialog = self.gui.percentDialog()
	    pDialog.create('SD-XBMC ' + SERVICE, 'Ładowanie informacji o serialu...')
	    for i in range(len(match)):
		if pDialog.iscanceled(): break
		meta = self.meta.getShowMeta(match[i][2])
		if meta == {} and match[i][3] != "":
		    meta = self.meta.getShowMeta(match[i][3])
		pDialog.update(int(i * 100.0 / len(match)), 'Ładowanie informacji o serialu...', match[i][2])
		page = MAINURL + '/' + match[i][1]
		params = {'service': SERVICE, 'name': 'sezon', 'tvshowtitle': match[i][2], 'title': match[i][2], 'page': page, 'icon': MAINURL + match[i][0].replace('_small', '')}
		params.update(meta)
		self.gui.addDir(params)
	match = re.compile('<li class="active"><a href=".+?data-dodania,desc.html">.+?</a></li>.+?\n.+?<li>', re.DOTALL).findall(data)
	if len(match) > 0:
	    params = {'service': SERVICE, 'name':'serial', 'category': category, 'title': 'Następna strona', 'page': str(int(pager) + 1), 'icon': THUMB_NEXT}
	    self.gui.addDir(params)
	self.gui.endDir(False, 'tvshows', 'MediaInfo3')

    def getSezonTable(self, url, serial, icon, tvdbid):
	query_data = { 'url': url, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('<div class="h">Sezon (.+?)</div>').findall(data)
	if len(match) > 0:
	    pDialog = self.gui.percentDialog()
	    pDialog.create('SD-XBMC ' + SERVICE, 'Ładowanie informacji o sezonie...')
	    for i in range(len(match)):
		if pDialog.iscanceled(): break
		meta = self.meta.getSeasonMeta(tvdbid, int(match[i]))
		pDialog.update(int(i * 100.0 / len(match)), 'Ładowanie informacji o sezonie...', 'Sezon '+match[i])
		title = 'Sezon ' + match[i]
		params = {'service': SERVICE, 'name': 'episode', 'tvshowtitle': serial, 'season': match[i], 'title': title, 'page': url, 'icon': icon}
		params.update(meta)
		params.update({'count': tvdbid})
		self.gui.addDir(params)
	self.gui.endDir(True, 'tvshows', 'MediaInfo3')

    def getEpizodTable(self, url, serial, sezon, icon, tvdbid):
    	episodelist = self.meta.getEpisodesList(tvdbid, int(sezon))
	query_data = { 'url': url, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	r = re.compile('<div class="h">Sezon ' + sezon + '</div>(.+?)</ul>', re.DOTALL).findall(data)
	if len(r)>0:
	    r2 = re.compile('<a href="(.+?)epizod,(.+?).html">.*?\n(.+?)</a>').findall(r[0])
	    if len(r2)>0:
		for i in range(len(r2)):
		    episodeTitle = self.cm.html_entity_decode(self.cm.html_entity_decode(r2[i][2].replace('  ', '')))
		    title = '%s S%sE%s - %s' % (serial, sezon, r2[i][1], episodeTitle)
		    link = MAINURL + r2[i][0] + 'epizod,' + r2[i][1] + '.html' + pr
		    meta = self.meta.getEpisodeMeta(episodelist, r2[i][1])
		    params = {'service': SERVICE, 'dstpath': dstpath, 'episode': r2[i][1], 'tvshowtitle': serial, 'season': sezon, 'title': title, 'page': link, 'icon': icon}
		    params.update(meta)
		    self.gui.playVideo(params)
	self.gui.endDir(False, 'episodes', 'MediaInfo3')

    def getHostTable(self,url):
	linkVideo = ''
	query_data = { 'url': url, 'use_host': True, 'host': HOST, 'use_cookie': True, 'save_cookie': False, 'load_cookie': True, 'cookiefile': COOKIEFILE, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile("""url: '(.+?)'""").findall(data)
	if len(match) > 0:
	    linkVideo = match[0]
	    log.info("final link: " + linkVideo)
        else:
            linkVideo = None
	return linkVideo

    def getHostingTable(self,url):
	valTab = []
	videoID = ''
	query_data = { 'url': url, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	link = data.replace('<div class="s-quality_mid"></div>', '').replace('<div class="s-quality_low"></div>', '').replace('<div class="s-quality_high"></div>', '')
	match = re.compile('<li class.+?><a href="(.+)player(.+?)">(.+?)</a></li>').findall(link)
	if len(match) > 0:
	    for i in range(len(match)):
		links = MAINURL + match[i][0] + 'player' + match[i][1]
		valTab.append(self.cm.setLinkTable(links, match[i][2]))
	    valTab.sort(key = lambda x: x[0])
	    d = xbmcgui.Dialog()
	    item = d.select("Wybór hostingu", self.cm.getItemTitles(valTab))
	    print str(item)
	    if item != -1:
		videoID = str(valTab[item][0])
		log.info('mID: ' + videoID)
		return videoID
	else:
	    return False

    def getLinkTable(self,url):
	linkVideo = ''
	query_data = { 'url': url, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('style="display:none.+?><iframe src="(.+?)"', re.IGNORECASE).findall(data)
	if len(match) > 0:
	    linkVideo = match[0]
	    log.info("final link: " + linkVideo)
	return linkVideo

    def getStype(self):
	stype = ''
	wybierz = ['Filmy','Seriale']
	d = xbmcgui.Dialog()
	item = d.select("Co chcesz znaleść?", wybierz)
	if item == 0:
	    stype =  'filmy'
	elif item == 1:
	    stype = 'seriale'
	return stype

    def listsHistory(self, table, ser):
	for i in range(len(table)):
	    if table[i] <> '':
		params = {'service': SERVICE, 'name': 'history', 'category': ser, 'title': table[i],'icon': LOGOURL}
		if ser == 'seriale':
		    pDialog = self.gui.percentDialog()
		    pDialog.create('SD-XBMC ' + SERVICE, 'Ładowanie informacji o serialu...')
		    if pDialog.iscanceled(): break
		    meta = self.meta.getShowMeta(table[i])
		    pDialog.update(int(i * 100.0 / len(table)), 'Ładowanie informacji o serialu...', table[i])
		    params.update(meta)
		    self.gui.addDir(params)
		    self.gui.endDir(False, 'tvshows', 'MediaInfo3')
		else:
		    self.gui.addDir(params)
		    self.gui.endDir()

    def handleService(self):
	params = self.parser.getParams()
	name = self.parser.getParam(params, "name")
	title = self.parser.getParam(params, "title")
	category = self.parser.getParam(params, "category")
	page = self.parser.getParam(params, "page")
	icon = self.parser.getParam(params, "icon")
	link = self.parser.getParam(params, "url")
	service = self.parser.getParam(params, "service")
	action = self.parser.getParam(params, "action")
	path = self.parser.getParam(params, "path")
	sezon = self.parser.getParam(params, "season")
	epizod = self.parser.getParam(params, "episode")
	serial = self.parser.getParam(params, "tvshowtitle")
	tvdbid = self.parser.getParam(params, "count")

	self.parser.debugParams(params, dbg)

	if str(page)=='None' or page=='': page = '0'

	if sortby=='ocena':
	    sSort = '?sort_field=ocena&sort_method='
	if sortby=='popularnosc':
	    sSort = '?sort_field=odslony&sort_method='
	if sortby=='data dodania':
	    sSort = '?sort_field=data-dodania&sort_method='
	if sortby=='tytul':
	    sSort = '?sort_field=alfabetycznie&sort_method='
	if sortby=='data premiery':
	    sSort = '?sort_field=data-premiery&sort_method='

	if quality=='wszystkie':
	    sQua = 'wszystkie'
	if quality=='wysoka':
	    sQua = 'wysoka-jakosc'
	if quality=='srednia':
	    sQua = 'srednia-jakosc'
	if quality=='niska':
	    sQua = 'niska-jakosc'

	if sortorder=='malejaco':
	    sHow = 'desc'
	else:
	    sHow = 'asc'

    #MAIN MENU
	if name == None:
	    #logowanie
	    if username == '' or password == '': loginData = {}
	    else: loginData = { 'form_login_username': username, 'form_login_password': password, "form_login_rememberme": "1" }
	    self.cm.requestLoginData(MAINURL + "logowanie.html", 'href="premium.html">Premium', COOKIEFILE, loginData)
	    
	    self.listsMainMenu(SERVICE_MENU_TABLE)
    #GATUNKI
	elif category == self.setTable()[1]:
	    self.listsCategoriesMenu(MAINURL + 'kategorie.html')
    #LEKTOR
	elif category == self.setTable()[2]:
	    url = '%skategorie,%s,%s,%s,1900-2013,.html%s' % (MAINURL, page, 'lektor', sQua, sSort + sHow)
	    self.getFilmTable(url, category, page)
    #NAPISY
	elif category == self.setTable()[3]:
	    url = '%skategorie,%s,%s,%s,1900-2013,.html%s' % (MAINURL, page, 'napisy', sQua, sSort + sHow)
	    self.getFilmTable(url, category, page)
    #DUBBING
	elif category == self.setTable()[4]:
	    url = '%skategorie,%s,%s,%s,1900-2013,.html%s' % (MAINURL, page, 'dubbing', sQua, sSort + sHow)
	    self.getFilmTable(url, category, page)
    #POLSKIE
	elif category == self.setTable()[5]:
	    url = '%skategorie,%s,%s,%s,1900-2013,.html%s' % (MAINURL, page, 'polskie', sQua, sSort + sHow)
	    self.getFilmTable(url, category, page)
    #NAJPOPULARNIEJSZE
	elif category == self.setTable()[6]:
	    url = MAINURL + 'kategorie' + ',' + str(page) + POPULAR
	    self.getFilmTable(url, category, page)
    #SERIALE
	elif category == self.setTable()[7]:
	    self.listsSerialsMenu((self.cm.makeABCList()))
    #WYSZUKAJ
	elif category == self.setTable()[8]:
	    SERCH = self.getStype()
	    text = self.gui.searchInput(SERVICE + SERCH).replace(' ', '+')
	    if  SERCH == 'filmy':
		url = MAINURLSR + text + ',filmy,' + str(page) + '.html'
		self.getFilmTable(url, category, page)
	    else:
		url = MAINURLSR + text + ',seriale,' + str(page) + '.html'
		self.getSerialTable(url, category, page)
    #HISTORIA WYSZUKIWANIA
	elif category == self.setTable()[9]:
	    SER = self.getStype()
	    t = self.history.loadHistoryFile(SERVICE + SER)
	    self.listsHistory(t, SER)
    #FILMY w 3D
        elif category == self.setTable()[10]:
            self.getFilmTable(MOVIE3DURL, category, page)
	if name == 'history' and category == 'filmy':
	    url = MAINURLSR + title.replace(' ', '+') + ',filmy,' + str(page) + '.html'
	    self.getFilmTable(url, category, page)
	if name == 'history' and category == 'seriale':
	    url = MAINURLSR + title.replace(' ', '+') + ',seriale,' + str(page) + '.html'
	    self.getSerialTable(url, category, page)
    #LISTA TYTULOW
	if name == 'category':
	    url = MAINURL + category + ',' + str(page) + ',wszystkie,wszystkie,1900-2013,.html' + sSort + sHow
	    self.getFilmTable(url, category, page)
    #LISTA SERIALI
	if name == 'serial':
	    url = MAINURL + 'seriale-online,' + category.replace(' ','') + ',' + page + ',data-dodania,desc.html'
	    self.getSerialTable(url, category, page)

	if name == 'sezon':
	    url = page + '.html'
	    self.getSezonTable(url, serial, icon, tvdbid)

	if name == 'episode':
	    self.getEpizodTable(page, serial, sezon, icon, tvdbid)
    #ODTWÓRZ VIDEO
	if name == 'playSelectedVideo':
	    linkVideo = None
	    if username != '' and password != '':
		linkVideo = self.getHostTable(page)
                if dbg:
                    log.info('ekinotv - handleService()[playSelectedVideo] linkVideo: %s, page: %s' % (str(linkVideo), str(page)))
	    if linkVideo == None:
		videoID = self.getHostingTable(page)
                if dbg:
                    log.info('ekinotv - handleService()[playSelectedVideo] videoID: %s, page: %s' % (str(videoID), str(page)))
		if videoID != False:
		    linkVideo = self.up.getVideoLink(self.getLinkTable(videoID))
                    if dbg:
                        log.info('ekinotv - handleService()[playSelectedVideo][1] videoID: %s, page: %s' % (str(videoID), str(page)))
		else:
		    d = xbmcgui.Dialog()
		    d.ok(SERVICE + ' - przepraszamy', 'Ten materiał nie został jeszcze dodany', 'Zapraszamy w innym terminie.')
		    return False
	    self.gui.LOAD_AND_PLAY_VIDEO(linkVideo, title)
    #POBIERZ
	if action == 'download' and link != '':
	    if link.startswith('http://'):
		linkVideo = None
	    	if username != '' and password != '':
		    linkVideo = self.getHostTable(link)
		if linkVideo == None:
		    urlTempVideo = self.getHostingTable(link)
		    linkVideo = self.up.getVideoLink(self.getLinkTable(urlTempVideo))
		if linkVideo != False:
		    self.cm.checkDir(os.path.join(dstpath, SERVICE))
		    dwnl = downloader.Downloader()
		    dwnl.getFile({ 'title': title, 'url': linkVideo, 'path': path })
