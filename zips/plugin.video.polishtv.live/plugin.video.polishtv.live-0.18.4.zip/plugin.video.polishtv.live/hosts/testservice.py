# -*- coding: utf-8 -*-
import os, re, sys, traceback
import xbmcaddon, xbmcgui

if sys.version_info >= (2,7): import json as _json
else: import simplejson as _json

scriptID = sys.modules[ "__main__" ].scriptID
scriptname   = sys.modules[ "__main__" ].scriptname
ptv = xbmcaddon.Addon(scriptID)

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )
THUMB_NEXT = os.path.join(ptv.getAddonInfo('path'), "images/") + 'dalej.png'

import sdLog, sdSettings, sdParser, urlparser, sdCommon, sdNavigation, sdErrors, downloader

log = sdLog.pLog()
dstpath = ptv.getSetting('default_dstpath')
dbg = sys.modules[ "__main__" ].dbg

SERVICE = 'testservice'

class TestService:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.settings = sdSettings.TVSettings()
	self.parser = sdParser.Parser()
	self.cm = sdCommon.common()
	self.history = sdCommon.history()
	self.exception = sdErrors.Exception()
	self.gui = sdNavigation.sdGUI()
	self.up = urlparser.urlparser()

    def testUrlParser(self):
	query_data = { 'url': 'http://witczak.net.pl/sdxbmc', 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = []
	match = re.compile('src="(.+?)"').findall(data)
	return match

    def getHostingTable(self,lists):
	valTab = []
	if len(lists) > 0:
	    for i in range(len(lists)):
	    	hostingname = self.up.getHostName(lists[i])
		valTab.append(self.cm.setLinkTable(lists[i], hostingname))
		log.info(" - Znaleziono serwis "+hostingname+" z linkiem "+lists[i])
	    d = xbmcgui.Dialog()
	    item = d.select("Wybór hostingu", self.cm.getItemTitles(valTab))
	    if item != -1:
		return valTab[item]
	    else:
		exit()
	else:
	    d = xbmcgui.Dialog()
	    d.ok('Brak hostingu', SERVICE + ' - nie dodano jeszcze tego wideo.', 'Zapraszamy w innym terminie.')
	    exit()

    def handleService(self):
	params = self.parser.getParams()
	name = self.parser.getParam(params, "name")
	title = self.parser.getParam(params, "title")
	category = self.parser.getParam(params, "category")
	page = self.parser.getParam(params, "page")
	icon = self.parser.getParam(params, "icon")
	link = self.parser.getParam(params, "url")
	service = self.parser.getParam(params, "service")
	action = self.parser.getParam(params, "action")
	path = self.parser.getParam(params, "path")

	self.parser.debugParams(params, dbg)

    #MAIN MENU
	if name == None:
	    urls = self.testUrlParser()
	    log.info('urlparser Terser')
	    url = self.getHostingTable(urls)

	    linkVideo = self.up.getVideoLink(url[0])
	    self.gui.LOAD_AND_PLAY_VIDEO(linkVideo, "Test hostingu "+url[1])

