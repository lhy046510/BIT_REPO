# -*- coding: utf-8 -*-
import os, string, StringIO
import urllib, urllib2, re, sys
import xbmcaddon, xbmc, xbmcgui
import traceback

scriptID = sys.modules[ "__main__" ].scriptID
scriptname   = sys.modules[ "__main__" ].scriptname
ptv = xbmcaddon.Addon(scriptID)

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )
COOKIEFILE = ptv.getAddonInfo('path') + os.path.sep + "cookies" + os.path.sep + "scs.cookie"
LOGOURL = ptv.getAddonInfo('path') + os.path.sep + "images" + os.path.sep + "scseriale.png"

import sdLog, sdSettings, sdParser, urlparser, sdCommon, sdNavigation, sdErrors, downloader

log = sdLog.pLog()
dbg = sys.modules[ "__main__" ].dbg
dstpath = ptv.getSetting('default_dstpath')

username = ptv.getSetting('scs_login')
password = ptv.getSetting('scs_password')

SERVICE = 'scseriale'
mainUrl = 'http://scs.pl/'
logUrl = mainUrl + 'logowanie.html'
allUrl = mainUrl + 'seriale.html'
ostUrl = mainUrl + 'ostatnio_aktualizowane_seriale.html'
postUrl = mainUrl + 'getVideo.html'
srcUrl = mainUrl + 'serial,szukaj.html'
imageUrl = 'http://static.scs.pl/static/serials/'

HOST = 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.2.18) Gecko/20110621 Mandriva Linux/1.9.2.18-0.1mdv2010.2 (2010.2) Firefox/3.6.18'

MENU_TAB = {
    1: "Seriale wg. kategorii",
    2: "Seriale alfabetycznie",
    3: "Ostatnio aktualizowane seriale",
    4: "Wyszukaj",
    5: "Historia Wyszukiwania"
}

class SCSeriale:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.settings = sdSettings.TVSettings()
	self.parser = sdParser.Parser()
	self.cm = sdCommon.common()
	self.exception = sdErrors.Exception()
	self.history = sdCommon.history()
	self.up = urlparser.urlparser()
	self.gui = sdNavigation.sdGUI()

    def setTable(self):
	return MENU_TAB

    def listsMainMenu(self, table):
	for num, val in table.items():
	    params = {'service': SERVICE, 'name': 'main-menu','category': val, 'title': val, 'icon': LOGOURL}
	    self.gui.addDir(params)
	self.gui.endDir()

    def listsABCMenu(self, table):
	for i in range(len(table)):
	    params = {'service': SERVICE, 'name': 'abc-menu','category': table[i], 'title': table[i], 'icon': LOGOURL}
	    self.gui.addDir(params)
	self.gui.endDir()

    def listsCategoriesMenu(self):
	query_data = { 'url': allUrl, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('<h2> <a title="Seriale (.+?)" href="(.+?)"').findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		title = string.capwords(match[i][0])
		params = {'service': SERVICE, 'name': 'serial-cat', 'title': title, 'page': mainUrl + match[i][1], 'icon': LOGOURL}
		self.gui.addDir(params)
	self.gui.endDir()

    def getSerialsTable(self, letter):
	query_data = { 'url': allUrl, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile(' <a class="serial_green" href="serial,(.+?)">(.+?)</a><br/>').findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		addItem = False
		if letter == '0 - 9' and (ord(match[i][1][0]) < 65 or ord(match[i][1][0]) > 91): addItem = True
		if (letter == match[i][1][0].upper()): addItem = True
		if (addItem):
		    img = self.getImage(match[i][0])
		    params = {'service': SERVICE, 'name': 'serial-sezon', 'tvshowtitle': match[i][1],  'title': match[i][1], 'page': mainUrl + 'serial,' + match[i][0], 'icon': img}
		    self.gui.addDir(params)
	self.gui.endDir(True)

    def getImage(self,url):
	imageLink=imageUrl + url.replace('.html', '.jpg')
	return imageLink

    def showSerialTitlesCat(self, url):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('class="serial_green" href="serial,(.+?)">(.+?)</a><br/>').findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		img = self.getImage(match[i][0])
		params = {'service': SERVICE, 'name': 'serial-sezon', 'tvshowtitle': match[i][1],  'title': match[i][1], 'page': mainUrl + 'serial,' + match[i][0], 'icon': img}
		self.gui.addDir(params)
	self.gui.endDir(True)

    def showLastParts(self, url):
	query_data = { 'url': url, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('online">(.+?)</a></div></div><span class="newest_ep" id=".+?">Ostatnio dodany:<br/><a href="odcinek,(.+?),(.+?),(.+?),(.+?).html">').findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		img = self.getImage(match[i][1]) + '.jpg'
		link = mainUrl + 'odcinek,' + match[i][1] + ',' + match[i][2] + ',' + match[i][3] + ',' + match[i][4] + '.html'
		title = match[i][0] + ' - ' + match[i][4] + ' - ' + match[i][2].capitalize().replace('-', ' ')
		params = {'service': SERVICE, 'dstpath': dstpath, 'title': title, 'page': link, 'icon': img}
		self.gui.playVideo(params)
	self.gui.endDir()

    def showSerialSeazon(self, url, serial, img):
	query_data = { 'url': url, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('<meta itemprop="seasonNumber" content="(.+?)">').findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		params = {'service': SERVICE, 'name': 'serial-episode', 'tvshowtitle': serial, 'season': match[i],  'title': 'Sezon '+match[i], 'page': url, 'icon': img}
		self.gui.addDir(params)
	self.gui.endDir(True)

    def showSerialParts(self, url, serial, sezon, img):
	query_data = { 'url': url, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	r = re.compile('<meta itemprop="seasonNumber" content="' + sezon + '">(.+?)</ul></div>', re.DOTALL).findall(data)
	if len(r)>0:
	    r2 = re.compile('itemprop="episodeNumber">(.+?)<.+?class="aLink " href="(odcinek,.+?,.+?,.+?,.+?.html)"><span itemprop="name">(.+?)</span></a>').findall(r[0])
	    if len(r2)>0:
		for i in range(len(r2)):
		    title = '%s S%sE%s - %s' % (serial, sezon, r2[i][0], r2[i][2])
		    link = mainUrl + r2[i][1]
		    params = {'service': SERVICE, 'dstpath': dstpath, 'episode': r2[i][0], 'tvshowtitle': serial, 'season': sezon, 'title': title, 'page': link, 'icon': img}
		    self.gui.playVideo(params)
	self.gui.endDir()

    def getItemTitles(self, table):
	out = []
	for i in range(len(table)):
	    value = table[i]
	    out.append(value[1])
	return out

    def getVideoID(self, url):
	strTab = []
	valTab = []
	videoW = ''
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('class="switch_button_lang"><a href="(.+?)">(.+?)</a></div>').findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		strTab.append(mainUrl + match[i][0])
		strTab.append(match[i][1].capitalize())
		valTab.append(strTab)
		strTab = []
	    valTab.sort(key = lambda x: x[0])
	    d = xbmcgui.Dialog()
	    item = d.select("Wybierz wersję", self.getItemTitles(valTab))
	    print str(item)
	    if item != -1:
		videoW = str(valTab[item][0])
		log.info('W-ID: ' + videoW)
	    return videoW
	else:
	    return False

    def getVideoCopy(self, url):
	strTab = []
	valTab = []
	videoC = ''
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('"(.+?)";.+?"Brak informacji";').findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		strTab.append(match[i])
		strTab.append('Kopia nr. ' + str(i+1))
		valTab.append(strTab)
		strTab = []
	    d = xbmcgui.Dialog()
	    item = d.select("Wybierz kopię Premium", self.getItemTitles(valTab))
	    print str(item)
	    if item != -1:
		videoC = str(valTab[item][0])
		log.info('C-ID: ' + videoC)
	    return videoC
	else:
	    return False

    def parserPremium(self,post):
	linkVideo = ''
	query_data = { 'url': postUrl, 'use_host': False, 'use_cookie': True, 'save_cookie': False, 'load_cookie': True, 'cookiefile': COOKIEFILE, 'use_post': True, 'return_data': True }
	query_datafree = { 'url': postUrl, 'use_host': False, 'use_cookie': False, 'use_post': True, 'return_data': True }
	postdata = { 'f' : post }
	try:
	    data = self.cm.getURLRequestData(query_data, postdata)
	    datafree = self.cm.getURLRequestData(query_datafree, postdata)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile("url: '(.+?)',").findall(data)
	if len(match) > 0:
	    linkVideo = match[0]
	    log.info ('linkVideoPremium :' + linkVideo)
	    return linkVideo
	else:
	    match = re.compile("url: '(.+?)',").findall(datafree)
	    if len(match) > 0:
		d = xbmcgui.Dialog()
		d.ok('Przepraszamy', 'Twoje konto PREMIUM jest nieaktywne.', 'Sprawdz waznosc konta na stronie: scs.pl.', 'Wlaczam Player z limitem buforowaina.')
		linkVideo = match[0]
		log.info ('linkVideoFree :' + linkVideo)
		return linkVideo
	    else:
		return False

    def getVideoCopyFree(self, url):
	strTab = []
	valTab = []
	query_data = { 'url': url, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('"(.+?)";(.+?)"Brak informacji";').findall(data)
	if len(match)>0:
	    for i in range(len(match)):
		postdata = {'f': match[i][0]}
		query_data = {'url': postUrl, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': True, 'return_data': True }
		try:
		    data = self.cm.getURLRequestData(query_data, postdata)
		except Exception, exception:
		    traceback.print_exc()
		    self.exception.getError(str(exception))
		    exit()
		match2 = re.compile('data: "f=(.*?)",').findall(data)
		if len(match2)>0:
		    postdata = {'f': match2[0]}
		    query_data = {'url': postUrl, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': True, 'return_data': True }
		    try:
			data = self.cm.getURLRequestData(query_data, postdata)
		    except Exception, exception:
			traceback.print_exc()
			self.exception.getError(str(exception))
			exit()
		    match3 = re.compile('<iframe src="(.+?)".+?</iframe>').findall(data)
		    if len(match3)>0:
			log.info('test: ' + match3[0])
			strTab.append(match3[0])
			strTab.append(str(i+1) + '. ' + self.up.getHostName(match3[0], True))
			valTab.append(strTab)
			strTab = []
	d = xbmcgui.Dialog()
	item = d.select("Wybierz hosting", self.getItemTitles(valTab))
	print str(item)
	if item != -1:
	    videoC = str(valTab[item][0])
	    log.info('C-ID: ' + videoC)
	    return videoC
	else:
	    return False

    def listsSearch(self,tex):
	query_data = { 'url': srcUrl, 'use_host': True, 'host': HOST, 'use_cookie': False, 'use_post': True, 'return_data': True }
	postdata = { 'search': tex }
	try:
	    data = self.cm.getURLRequestData(query_data, postdata)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('<div class="img_box"><a href="(.+?)">.\n.+?<img src="(.+?)" alt="(.+?)" />').findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		img = match[i][1]
		params = {'service': SERVICE, 'name': 'serial-sezon', 'tvshowtitle': match[i][2],  'title': match[i][2], 'page': mainUrl + match[i][0], 'icon': img}
		self.gui.addDir(params)
	self.gui.endDir(True)

    def listsHistory(self, table):
	for i in range(len(table)):
	    if table[i] <> '':
		params = {'service': SERVICE, 'name': 'history', 'title': table[i],'icon': LOGOURL}
		self.gui.addDir(params)
	self.gui.endDir()

    def handleService(self):
	params = self.parser.getParams()
	name = self.parser.getParam(params, "name")
	title = self.parser.getParam(params, "title")
	category = self.parser.getParam(params, "category")
	page = self.parser.getParam(params, "page")
	icon = self.parser.getParam(params, "icon")
	link = self.parser.getParam(params, "url")
	service = self.parser.getParam(params, "service")
	action = self.parser.getParam(params, "action")
	path = self.parser.getParam(params, "path")
	sezon = self.parser.getParam(params, "season")
	epizod = self.parser.getParam(params, "episode")
	serial = self.parser.getParam(params, "tvshowtitle")

	self.parser.debugParams(params, dbg)

    #MAIN MENU
	if name == None:
	    self.listsMainMenu(MENU_TAB)
    #SERIALE WG. KATEGORII
	if category == self.setTable()[1]:
	    self.listsCategoriesMenu()
	
	if name == 'serial-cat':
	    self.showSerialTitlesCat(page)
    #SERIALE ALFABETYCZNIE
	if category == self.setTable()[2]:
	    self.listsABCMenu(self.cm.makeABCList())
	
	if name == 'abc-menu':
	    self.getSerialsTable(category)
	if name == 'serial-sezon':
	    self.showSerialSeazon(page, serial, icon)
	if name == 'serial-episode':
	    self.showSerialParts(page, serial, sezon, icon)
    #OSTATNIO AKTUALIZOWANE SERIALE
	if category == self.setTable()[3]:
	    self.showLastParts(ostUrl)
    #WYSZUKAJ
	if category == self.setTable()[4]:
	    text = self.gui.searchInput(SERVICE)
	    self.listsSearch(text)
    #HISTORIA WYSZUKIWANIA
	if category == self.setTable()[5]:
	    t = self.history.loadHistoryFile(SERVICE)
	    self.listsHistory(t)
	
	if name == 'history':
	    self.listsSearch(title)
    #ODTWÓRZ VIDEO
	if name == 'playSelectedVideo':
	    videoID = self.getVideoID(page)
	    if username=='' or password=='':
		if videoID != False:
		    linkVideo = self.up.getVideoLink(self.getVideoCopyFree(videoID))
		else:
		    d = xbmcgui.Dialog()
		    d.ok(SERVICE + ' - przepraszamy', 'Ten materiał nie został jeszcze dodany', 'Zapraszamy w innym terminie.')
		    return False
	    else:
                #logowanie
                if username == '' or password == '': loginData = {}
                else: loginData = { 'email': username, 'password': password }
                self.cm.requestLoginData(mainUrl + 'logowanie.html', 'href="wyloguj.html">[wyloguj]<', COOKIEFILE, loginData)
            
		linkVideo = self.parserPremium(self.getVideoCopy(videoID))
	    self.gui.LOAD_AND_PLAY_VIDEO(linkVideo, title)
    #POBIERZ
	if action == 'download' and link != '':
	    self.cm.checkDir(os.path.join(dstpath, SERVICE))
	    if link.startswith('http://'):
		if username=='' or password=='':
		    urlTempVideo = self.getVideoID(link)
		    linkVideo = self.up.getVideoLink(self.getVideoCopyFree(urlTempVideo))
		else:
		    linkVideo = self.parserPremium(self.getVideoCopy(self.getVideoID(link)))
		if linkVideo != False:
		    dwnl = downloader.Downloader()
		    dwnl.getFile({ 'title': title, 'url': linkVideo, 'path': path })
