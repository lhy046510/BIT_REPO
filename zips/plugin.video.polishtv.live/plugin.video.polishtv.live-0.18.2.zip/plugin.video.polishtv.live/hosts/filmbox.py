# -*- coding: utf-8 -*-
import os, sys
import xbmcaddon, traceback

if sys.version_info >= (2,7): import json as _json
else: import simplejson as _json 

scriptID = sys.modules[ "__main__" ].scriptID
scriptname   = sys.modules[ "__main__" ].scriptname
ptv = xbmcaddon.Addon(scriptID)

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )

import sdLog, sdSettings, sdParser, sdCommon, sdNavigation

log = sdLog.pLog()

SERVICE = 'filmbox'

API = 'http://www.filmboxliveapp.com/channel/channels_pl.json'
LOGO = 'http://www.filmboxliveapp.com/mobile/ios/pl/images/'
dbg = sys.modules[ "__main__" ].dbg

class filmbox:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.settings = sdSettings.TVSettings()
	self.parser = sdParser.Parser()
	self.cm = sdCommon.common()
	self.gui = sdNavigation.sdGUI()

    def getChannelTable(self, polishOnly = True):
	query_data = {'url': API, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True}
	data = self.cm.getURLRequestData(query_data)
	result = _json.loads(data)
	for channel in result['channels']:
	    title = channel['display_name'].encode('UTF-8')
	    icon = LOGO+channel['images'][0]['image']
	    params = {'service': SERVICE, 'title': title, 'page': channel['stream'], 'icon': icon}
	    self.gui.playVideo(params)
	self.gui.endDir()

    def handleService(self):
	params = self.parser.getParams()
	title = self.parser.getParam(params, "title")
	page = self.parser.getParam(params, "page")
	name = self.parser.getParam(params, "name")
	self.parser.debugParams(params, dbg)

	if name == None:
	    self.getChannelTable()
	else:
	    self.gui.LOAD_AND_PLAY_VIDEO(page, title)
