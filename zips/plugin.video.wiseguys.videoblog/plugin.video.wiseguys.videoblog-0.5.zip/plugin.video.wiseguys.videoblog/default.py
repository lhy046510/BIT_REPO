# -*- coding: utf-8 -*-
import xbmcplugin
import xbmcgui
import sys
import urllib, urllib2
import re

def parseSite(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	match=re.compile('<h1 class="major_post_headline">(.+?)</h1></div>\n.+?\n.+?\n.+?\n.+?\n.+?\n.+?\n.+?\n.+?\n.+?\'file=(.+?)&image=(.+?)\'').findall(link) 
	for title,url,pic in match:
		title=title.replace("&nbsp;","")
		title=title.replace("&auml;","ä")
		title=title.replace("&ouml;","ö")
		title=title.replace("&uuml;","ü")
		title=title.replace("&szlig;","ß")
		li = xbmcgui.ListItem(title,iconImage="DefaultFolder.png", thumbnailImage=pic)
		li.setInfo( type="Video", infoLabels={ "Title": title } )
		li.setProperty('IsPlayable', 'true')
		xbmcplugin.addDirectoryItem(handle=thisPlugin, url=url, listitem=li, isFolder=False)


thisPlugin = int(sys.argv[1])

dlgProgress=xbmcgui.DialogProgress()

url='http://wiseguys.de/video'

req = urllib2.Request(url)
req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
response = urllib2.urlopen(req)
link=response.read()
response.close()
count=re.compile('Seite 1 von (.+?) Seiten').findall(link) 

dlgProgress.create("Wise Guys Videoblog")

i=0
while i<int(count[0]) and not dlgProgress.iscanceled():
	url='http://wiseguys.de/video/P'+str(i)+'0'
	i=i+1
	intPercent=100/int(count[0])*i
	dlgProgress.update(intPercent,"Parse Seite "+str(i)+" von "+count[0],url)
	parseSite(url)

xbmcplugin.endOfDirectory(thisPlugin)
