# -*- coding: utf-8 -*-
import os, string
import urllib, re, sys
import xbmcaddon, traceback
import xml.etree.ElementTree as ET

scriptID = sys.modules[ "__main__" ].scriptID
ptv = xbmcaddon.Addon(scriptID)

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )
LOGOURL = ptv.getAddonInfo('path') + os.path.sep + "images" + os.path.sep + "rmf.png"
THUMB_NEXT = os.path.join(ptv.getAddonInfo('path'), "images/") + 'dalej.png'

import sdLog, sdParser, sdCommon, sdNavigation, sdErrors

log = sdLog.pLog()

dbg = sys.modules[ "__main__" ].dbg
dstpath = ptv.getSetting('default_dstpath')

SERVICE = 'rmf'
MAINURL = 'http://rmfon.pl'
RMFON = MAINURL+"/mobilev3/stations/RMFONANDROID/null-"

SERVICE_MENU_TABLE = {
	1:"RMF ON",
	2:"Podcasty",
	3:"Poplista",
#	4:"Co było grane?"
}

class RMF:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.parser = sdParser.Parser()
	self.cm = sdCommon.common()
	self.history = sdCommon.history()
	self.exception = sdErrors.Exception()
	self.gui = sdNavigation.sdGUI()

    def setTable(self):
	return SERVICE_MENU_TABLE

    def listsMainMenu(self, table):
	for num, val in table.items():
	    params = {'service': SERVICE, 'name': 'main-menu','category': val, 'title': val, 'icon': LOGOURL}
	    self.gui.addDir(params)
	self.gui.endDir()

    def listsCategoryMenu(self, url):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	params = {'service': SERVICE, 'category': 'all', 'name': 'rmfonset', 'title': '-Wszystkie kategorie', 'icon': LOGOURL}
	self.gui.addDir(params)
	r = re.compile('<category .+? name="(.+?)" .+? stations="(.+?)">').findall(data)
	if len(r)>0:
	    for i in range(len(r)):
		params = {'service': SERVICE, 'category': r[i][1], 'name': 'rmfonset', 'title': string.capwords(self.cm.html_entity_decode(r[i][0])), 'icon': LOGOURL}
		self.gui.addDir(params)
	self.gui.endDir(True)

    def listsRmfOnRadio(self, url, category):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	r = re.compile('<station id="(.+?)" name="(.+?)" .+? stream_aac="(.+?)" stream_mp3="(.+?)"/>').findall(data)
	if len(r)>0:
	    if category <> 'all':
		r2 = []
		category = category.split(',')
		for i in range(len(r)):
		    if r[i][0] in category:
			r2.append(r[i])
	    else:
		r2 = r
	    if len(r2)>0:
		for i in range(len(r2)):
		    params = {'service': SERVICE, 'dstpath': dstpath, 'title': string.capwords(self.cm.html_entity_decode(r2[i][1])), 'page': r2[i][3], 'icon': LOGOURL}
		    self.gui.playAudio(params)
	self.gui.endDir(True)

    def listPodcastCat(self, url):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	r = re.compile('<link>(.+?)</link>\n.+?<category>(.+?)</category>\n.+?<enclosure url="(.+?)"').findall(data)
	log.info('TEST2 '+str(r))
	if len(r)>0:
	    for i in range(len(r)):
		params = {'service': SERVICE, 'category': r[i][0], 'name': 'rmfpodcast', 'title': string.capwords(self.cm.html_entity_decode(r[i][1])), 'icon': r[i][2]}
		self.gui.addDir(params)
	self.gui.endDir(True)

    def listPodcast(self, url, icon):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	r = re.compile('<title>(?:<!.CDATA.)?(.+?)(?:..>)?</title>.+?<enclosure url="(.+?)"', re.DOTALL).findall(data)
	if len(r)>0:
	    for i in range(len(r)):
		params = {'service': SERVICE, 'dstpath': dstpath, 'title': string.capwords(self.cm.html_entity_decode(r[i][0])), 'page': r[i][1], 'icon': icon}
		self.gui.playAudio(params)
	self.gui.endDir()

    def listPoplista(self, url):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	r = re.compile('<pozycja( nr=".+?">|>).+?<wykonawca><!.CDATA.(.+?)..></wykonawca><tytul><!.CDATA.(.+?)..></tytul><hook>(.+?)</hook>.*?<foto>(.+?)</foto>').findall(data)
	if len(r)>0:
	    for i in range(len(r)):
		if r[i][0] == '>':
		    prefix = 'Propozycja '
		else:
		    prefix = 'Pozycja ' + r[i][0][5:-2] + ' '
		name = prefix + r[i][1] + ' - ' + r[i][2]
		params = {'service': SERVICE, 'dstpath': dstpath, 'title': self.cm.html_entity_decode(name), 'page': r[i][3], 'icon': r[i][4]}
		self.gui.playAudio(params)
	self.gui.endDir()

    def handleService(self):
	params = self.parser.getParams()
	name = self.parser.getParam(params, "name")
	title = self.parser.getParam(params, "title")
	category = self.parser.getParam(params, "category")
	page = self.parser.getParam(params, "page")
	icon = self.parser.getParam(params, "icon")
	link = self.parser.getParam(params, "url")
	service = self.parser.getParam(params, "service")
	action = self.parser.getParam(params, "action")
	path = self.parser.getParam(params, "path")

	self.parser.debugParams(params, dbg)

	#MAIN MENU
	if name == None:
	    self.listsMainMenu(SERVICE_MENU_TABLE)
	#RMF ON
	if category == self.setTable()[1]:
	    self.listsCategoryMenu(RMFON)
	if name == 'rmfonset':
	    self.listsRmfOnRadio(RMFON, category)
	#PODCASTY
	if category == self.setTable()[2]:
	    self.listPodcastCat("http://txt.rmf.pl/rmf_fm/app/stream.xml")
	if name == 'rmfpodcast':
	    self.listPodcast(category, icon)
	#POPLISTA
	if category == self.setTable()[3]:
	    self.listPoplista("http://www.rmf.fm/au/poplista/notowanie.xml?did=null-&token=eba2aa3b647e58eb4a8ba48d37cf0354dd2a5d30")
	#CO BYŁO GRANE
#	if category == self.setTable()[4]:
#	http://www.rmf.fm/muzyka/megaplayer/ajax.php?hour=13
	#ODTWÓRZ AUDIO
	if name == 'playSelectedAudio':
	    self.gui.LOAD_AND_PLAY_AUDIO(page, title)