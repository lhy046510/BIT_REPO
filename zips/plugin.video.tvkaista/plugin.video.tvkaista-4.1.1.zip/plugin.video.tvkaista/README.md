plugin.video.tvkaista
=====================

http://xbmc.org plugin for http://www.tvkaista.fi service

Author has no relations to the tvkaista service, he is just a happy customer.

Previously developed at http://code.google.com/p/tvkaistaforxbmc/ and http://code.google.com/p/tvkaistaforxbmcv2/
