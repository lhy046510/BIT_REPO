#!/usr/bin/env python
# -*- coding: UTF-8 -*-

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,xbmcvfs
import os,base64
# -*- coding: iso-8859-9 -*-

__settings__ = xbmcaddon.Addon(id='plugin.image.HappyFeets.Karikatur')
__language__ = __settings__.getLocalizedString
home = __settings__.getAddonInfo('path')
folders = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(folders)
import xbmctools
l_check=xbmctools.inside()
if l_check:
        pass
else:
        xbmctools.hata()
        sys.exit()


#!/usr/bin/python
# -*- coding: utf-8 -*-
# Copyright (c) 2013
# Writer (c) 2013, xbmcTR Team by HappyFeets
# Turkiye, E-mail: androidmkersco@gmail.com

addon_id = 'plugin.image.HappyFeets.Karikatur'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
artfolder = '/resources/icons/'

urll='aHR0cDovL2thcmlrYXR1cm1lcmtlemkuY29tL2thdGVnb3JpL2thcmlrYXR1cmxlci0y'

def CATEGORIES():
        url2='aHR0cDovL3hibWN0ci50di8='
        link=get_url(base64.b64decode(url2))
        match=re.compile('ir>>(.*?)<<be').findall(link)
        for web1 in match:
                print web1+''

        link=get_url(base64.b64decode(urll))
        match=re.compile('<img src="(.*?)" alt=".*?" width="229">\n').findall(link)
        for a in match:
                        thumbnail=a
                        thumbnail = urllib.unquote(thumbnail)
                        addLink('[B]' + 'XbmcTR' + '[/B]',thumbnail,thumbnail)                
        xbmc.executebuiltin("Container.SetViewMode(500)")
        page=re.compile('<a class="next page-numbers" href="(.*?)"').findall(link)
        for url in page:
            name='Sonraki Sayfa '
            url=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')
            addDir('[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]',url,2,'')

def devam(url):
        link = get_url(url)
        match=re.compile('<img src="(.*?)" alt=".*?" width="229">\n').findall(link)
        for a in match:
                        thumbnail=a
                        thumbnail = urllib.unquote(thumbnail)
                        addLink('[B]' + 'pick me' + '[/B]',thumbnail,thumbnail)                
        xbmc.executebuiltin("Container.SetViewMode(500)")
        page=re.compile('<a class="next page-numbers" href="(.*?)"').findall(link)
        for url in page:
            name='Sonraki Sayfa '
            url=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')
            addDir('[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]',url,2,'')

################################################################################​############################################

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultImage.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', addonfolder + artfolder + 'fanart.jpg')
        liz.setInfo( type='image', infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', addonfolder + artfolder + 'fanart.jpg')
        liz.setInfo( type="Video", infoLabels={ "Title": name })
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
                      
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        CATEGORIES()

elif mode==2:
        devam(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
