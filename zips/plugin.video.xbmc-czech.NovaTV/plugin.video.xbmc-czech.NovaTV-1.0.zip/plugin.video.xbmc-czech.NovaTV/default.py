# -*- encoding: utf-8 -*- 
"""
 Plugin for accessing videos on http://archiv.nova.cz/home/simulcast
"""

import sys
from lib.xbmcPluginInterface import *

# plugin constants 
__plugin__ = "NovaTV"
__author__ = "Miroslav Vit"
__version__ = "1.0"


def run():
    from novatvPlugin import NovatvPlugin
    iface = XBMCPluginInterface("plugin.video.xbmc-czech.NovaTV")
    plugin = NovatvPlugin( iface )
    plugin.call( *sys.argv )


if __name__ == '__main__':
    run()

