plugin.video.viewster================


XBMC Addon for viewster website

Version 1.0.5 feed change - m3u8 support
Version 1.0.4 added "all languages" support
Version 1.0.3 added language support
version 1.0.2 added higher res video support
version 1.0.1 initial release

