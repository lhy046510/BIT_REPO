oo000 = [ 'base64' ]
ii = map ( __import__ , oo000 )
ii
if 75 - 75: IIIiiiiiIii / oooOOOOO % II1I1iiiiii
def IiI1I1 ( InputString ) :
 OoO000 = ord ( InputString )
 return OoO000
 if 42 - 42: oO - oo / IiI1i11I + IiiIIiiI11 + O00o0o0000o0o
def iIi ( InputString ) :
 OoO000 = chr ( InputString )
 return OoO000
 if 40 - 40: oO . oOo0oooo00o . o0oooOoO0 . oo
def I11iii ( InputString ) :
 OoO000 = len ( InputString )
 return OoO000
 if 54 - 54: IiiIIiiI11 + IiiIIiiI11 % O00O0O0O0 % IiI1i11I / ooo0OO . IiiIIiiI11
def o0oO0o00oo ( InputString , Base ) :
 OoO000 = int ( InputString , Base )
 return OoO000
 if 32 - 32: o0oooOoO0 * II1I1iiiiii % oO % IiiIII111ii . IiIi1Iii1I1
def o0OOOOO00o0O0 ( message , code ) :
 o0o0OOO0o0 = "" ; ooOOOo0oo0O0 = 0
 o0 = ii [ 0 ] . b64decode ( message )
 list = [ I11II1i for I11II1i in o0 if I11II1i != '\n' ]
 IIIIIooooooO0oo = [ I11II1i for I11II1i in code if I11II1i != '\n' ]
 for IIiiiiiiIi1I1 in range ( 0 , I11iii ( list ) , 16 ) :
  for iI111iI in range ( 0 , 8 ) :
   if ooOOOo0oo0O0 + o0oO0o00oo ( IIIIIooooooO0oo [ iI111iI ] , 16 ) <= I11iii ( list ) :
    o0o0OOO0o0 = o0o0OOO0o0 + iIi ( IiI1I1 ( list [ ooOOOo0oo0O0 + o0oO0o00oo ( IIIIIooooooO0oo [ iI111iI ] , 16 ) ] ) - o0oO0o00oo ( IIIIIooooooO0oo [ iI111iI + 8 ] , 16 ) )
  ooOOOo0oo0O0 = ooOOOo0oo0O0 + 16
 return o0o0OOO0o0 . rstrip ( ' ' )
 if 13 - 13: IiIi1Iii1I1 + oOo0oooo00o - o0OO00 + O00O0O0O0 . i1iIIi1 + O00o0o0000o0o
def Ii ( message , index ) :
 if index == 1 :
  oo0O0oOOO00oO = "ba98763223b38343"
 elif index == 2 :
  oo0O0oOOO00oO = "d37e194800000000"
 elif index == 3 :
  oo0O0oOOO00oO = "38a7629b43303002"
 elif index == 4 :
  oo0O0oOOO00oO = "38d762ce433833b2"
 o0o0OOO0o0 = o0OOOOO00o0O0 ( message , oo0O0oOOO00oO )
 return o0o0OOO0o0
 if 61 - 61: oo * IiiIIiiI11 / o0OO00 . IiI1i11I . oOo0oooo00o
 if 60 - 60: oooOOOOO / oooOOOOO
