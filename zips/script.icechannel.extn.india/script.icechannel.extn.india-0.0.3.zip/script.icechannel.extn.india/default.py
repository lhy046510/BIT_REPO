# default.py
addon_id="script.icechannel.extn.india"
addon_name="XunityTalk.com iStream extensions for India"
