import time
import datetime
import cookielib
import os

import mediaitem
import contextmenu
import chn_class

from config import Config
from regexer import Regexer
from helpers import subtitlehelper
# from helpers import datehelper
from helpers.jsonhelper import JsonHelper

from logger import Logger
from streams.m3u8 import M3u8
from urihandler import UriHandler
from addonsettings import AddonSettings
from helpers.datehelper import DateHelper


class Channel(chn_class.Channel):
    """
    main class from which all channels inherit
    """

    def __init__(self, channelInfo):
        """Initialisation of the class.

        Arguments:
        channelInfo: ChannelInfo - The channel info object to base this channel on.

        All class variables should be instantiated here and this method should not
        be overridden by any derived classes.

        """

        chn_class.Channel.__init__(self, channelInfo)

        # ============== Actual channel setup STARTS here and should be overwritten from derived classes ===============
        self.noImage = "nosimage.png"

        # set context menu items
        self.contextMenuItems.append(contextmenu.ContextMenuItem("Download item", "CtMnDownload", itemTypes='video'))

        # setup the urls
        if self.channelCode == "uzgjson":
            self.baseUrl = "http://apps-api.uitzendinggemist.nl"
            self.mainListUri = "%s/series.json" % (self.baseUrl,)
            self.noImage = "nosimage.png"
        else:
            raise NotImplementedError("Code %s is not implemented" % (self.channelCode,))

        # setup the main parsing data
        self.episodeItemRegex = None
        self.episodeItemJson = ()
        self.videoItemRegex = None

        # we need 2 regexes, one for search results and one for normal results
        self.videoItemJsonNormal = ("episodes",)
        self.videoItemJsonSearch = ()
        self.videoItemJson = self.videoItemJsonNormal

        self.folderItemRegex = None
        self.pageNavigationRegex = None

        # needs to be here because it will be too late in the script version
        self.__IgnoreCookieLaw()

        # ===============================================================================================================
        # non standard items
        # self.md5Encoder = encodinghelper.EncodingHelper()
        # self.environmentController = envcontroller.EnvController()

        # Set self.nonMobilePageSize to 0 to disable mobile pages
        self.nonMobilePageSize = 50
        self.nonMobileMaxPageSize = 100
        self.nonMobileVideoItemRegex = 'src="(?<Image>[^"]+)" />\W*</a></div>\W*</div>\W*<div[^>]*>\W*' \
                                       '<a href="(?<Url>[^"]+\/(?<WhatsOnId>[^/"]+))"[^>]*><h4>(?<Title>[^<]+)' \
                                       '<[\W\w]{0,200}?<h5>\w+ (?<Day>\d+) (?<Month>\w+) (?<Year>\d+) ' \
                                       '(?<Hours>\d+):(?<Minutes>\d+)[^>]+</h5>\W*' \
                                       '<p[^>]+>(?<Description>[^<]*)'.replace('(?<', '(?P<')

        self.baseUrlLive = "http://www.npo.nl"
        self.videoItemRegexLive = ('<a href="/(live)/([^/"]+)"[^>]*>[\w\W]{0,300}?<div[^>]+'
                                   'style="background-image: url\(&#x27;([^)]+)&#x27;\)"[^>]*></div>',
                                   "<option value=\"(http://[^\"]+)\"[^>]+>([^<]+)</option>")
        self.folderItemRegexLive = '<a href="/(radio)/([^/"]+)"[^>]+><img[^>]+src="([^"]+)"'

        # ====================================== Actual channel setup STOPS here =======================================
        return

    def ParseMainList(self, returnData=False):
        """Parses the mainlist of the channel and returns a list of MediaItems

        This method creates a list of MediaItems that represent all the different
        programs that are available in the online source. The list is used to fill
        the ProgWindow.

        Keyword parameters:
        returnData : [opt] boolean - If set to true, it will return the retrieved
                                     data as well

        Returns a list of MediaItems that were retrieved.

        """

        # first do the basic stuff
        items = chn_class.Channel.ParseMainList(self, returnData=returnData)

        search = mediaitem.MediaItem("\a.: Zoeken :.", "searchSite")
        search.complete = True
        search.icon = self.icon
        search.thumb = self.noImage
        search.SetDate(2200, 1, 1, text="")
        items.append(search)

        extra = mediaitem.MediaItem("\a.: Populair :.", "%s/episodes/popular.json" % (self.baseUrl,))
        extra.complete = True
        extra.icon = self.icon
        extra.thumb = self.noImage
        extra.SetDate(2200, 1, 1, text="")
        items.append(extra)

        extra = mediaitem.MediaItem("\a.: Tips :.", "%s/tips.json" % (self.baseUrl,))
        extra.complete = True
        extra.icon = self.icon
        extra.thumb = self.noImage
        extra.SetDate(2200, 1, 1, text="")
        items.append(extra)

        extra = mediaitem.MediaItem("\a.: Recent :.", "%s/broadcasts/recent.json" % (self.baseUrl,))
        extra.complete = True
        extra.icon = self.icon
        extra.thumb = self.noImage
        extra.SetDate(2200, 1, 1, text="")
        items.append(extra)

        extra = mediaitem.MediaItem("\a.: Live Radio :.", "%s/radio" % (self.baseUrlLive,))
        extra.complete = True
        extra.icon = self.icon
        extra.thumb = self.noImage
        extra.SetDate(2200, 1, 1, text="")
        items.append(extra)

        extra = mediaitem.MediaItem("\a.: Live TV :.", "%s/live" % (self.baseUrlLive,))
        extra.complete = True
        extra.icon = self.icon
        extra.thumb = self.noImage
        extra.SetDate(2200, 1, 1, text="")
        items.append(extra)

        today = datetime.datetime.now()
        days = ["Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag", "Zondag"]
        for i in range(0, 7, 1):
            airDate = today - datetime.timedelta(i)
            Logger.Trace("Adding item for: %s", airDate)

            # Determine a nice display date
            day = days[airDate.weekday()]
            if i == 0:
                day = "Vandaag"
            elif i == 1:
                day = "Gisteren"
            elif i == 2:
                day = "Eergisteren"
            title = ".: %04d-%02d-%02d - %s :." % (airDate.year, airDate.month, airDate.day, day)

            url = "http://www.npo.nl/zoeken?utf8=%%E2%%9C%%93&sort_date=%02d-%02d-%04d&page=1" % \
                  (airDate.day, airDate.month, airDate.year)
            extra = mediaitem.MediaItem(title, url)
            extra.complete = True
            extra.icon = self.icon
            extra.thumb = self.noImage
            extra.httpHeaders["X-Requested-With"] = "XMLHttpRequest"
            extra.SetDate(airDate.year, airDate.month, airDate.day, text="")
            items.append(extra)

        return items

    def CreateEpisodeItem(self, resultSet):
        """Creates a new MediaItem for an episode

        Arguments:
        resultSet : list[string] - the resultSet of the self.episodeItemRegex

        Returns:
        A new MediaItem of type 'folder'

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        """

        episodeId = resultSet['nebo_id']
        # if we should not use the mobile listing and we have a non-mobile ID)
        if 'mid' in resultSet and self.nonMobilePageSize > 0:
            nonMobileId = resultSet['mid']
            url = "http://www.npo.nl/series/%s/search?media_type=broadcast&start_date=&end_date=&start=0&rows=%s" \
                  % (nonMobileId, self.nonMobilePageSize)
        else:
            url = "%s/series/%s.json" % (self.baseUrl, episodeId)

        name = resultSet['name']
        description = resultSet.get('description', '')
        thumbUrl = resultSet['image']

        item = mediaitem.MediaItem(name, url)
        item.type = 'folder'
        item.icon = self.icon
        item.complete = True
        item.description = description

        if thumbUrl:
            item.thumb = thumbUrl
        else:
            item.thumb = self.noImage

        return item

    # noinspection PyAttributeOutsideInit
    def PreProcessFolderList(self, data):
        """Performs pre-process actions for data processing/

        Arguments:
        data : string - the retrieve data that was loaded for the current item and URL.

        Returns:
        A tuple of the data and a list of MediaItems that were generated.


        Accepts an data from the ProcessFolderList method, BEFORE the items are
        processed. Allows setting of parameters (like title etc) for the channel.
        Inside this method the <data> could be changed and additional items can
        be created.

        The return values should always be instantiated in at least ("", []).

        """

        Logger.Info("Performing Pre-Processing")
        items = []

        Logger.Debug("Switching based on: %s", self.parentItem.url)
        if "/radio" in self.parentItem.url or "/live" in self.parentItem.url:
            Logger.Info("Processing Live items")

            if "/radio/" in self.parentItem.url:
                # we should always add the parent as radio item
                parent = self.parentItem
                Logger.Debug("Adding main radio item to sub item list: %s", parent)
                item = mediaitem.MediaItem("%s (Hoofd kanaal)" % (parent.name,), parent.url)
                item.icon = parent.icon
                item.thumb = parent.thumb
                item.type = 'video'
                item.complete = False
                items.append(item)

            elif self.parentItem.url.endswith("/live"):
                # let's add the 3FM live stream
                parent = self.parentItem
                Logger.Debug("Adding 3fm live video item to sub item list: %s", parent)
                item = mediaitem.MediaItem("3FM Live",
                                           "http://ida.omroep.nl/aapi/?stream=http://livestreams.omroep.nl/live/npo/visualradio/3fm/3fm.isml/3fm.m3u8")
                item.icon = parent.icon
                item.thumb = "http://www.3fm.nl/data/thumb/abc_media_image/113000/113453/w210.1b764.jpg"
                item.type = 'video'
                item.complete = False
                items.append(item)

            # set the correct regexes and methods for live streams
            self.videoItemRegex = self.videoItemRegexLive
            self.CreateVideoItem = self.CreateVideoItemLive

            self.folderItemRegex = self.folderItemRegexLive
            self.CreateFolderItem = self.CreateFolderItemLive

            self.UpdateVideoItem = self.UpdateVideoItemLive

        elif not self.__IsMobileUrl(self.parentItem.url):
            Logger.Info("Processing Non Mobile UZG items")
            self.videoItemRegex = self.nonMobileVideoItemRegex
            self.folderItemRegex = "<div class=\Wsearch-results\W (?:data-num-found=\W(?<Total>\d+)\W " \
                                   "data-rows=\W(?<PageSize>\d+)\W data-start=\W(?<CurrentStart>\d+)\W|" \
                                   "data-page=\W(?<Page>\d+)\W)".replace("(?<", "(?P<")
            self.CreateVideoItem = self.CreateVideoItemNonMobile
        else:
            Logger.Info("Processing UZG items")
            self.videoItemRegex = None
            self.folderItemRegex = None

            if "active_episodes_count" in data:
                self.videoItemJson = self.videoItemJsonNormal
            else:
                self.videoItemJson = self.videoItemJsonSearch

        Logger.Debug("Pre-Processing finished")
        return data, items

    def CreateFolderItem(self, resultSet):
        """Creates a MediaItem of type 'folder' using the resultSet from the regex.

        Arguments:
        resultSet : tuple(strig) - the resultSet of the self.folderItemRegex

        Returns:
        A new MediaItem of type 'folder'

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        """

        # Used for paging in the episode listings

        if "Page" in resultSet and resultSet["Page"]:
            # page from date search result
            title = "\a.: Meer programma's :."
            page = int(resultSet["Page"])
            url = self.parentItem.url.replace("page=%s" % (page, ), "page=%s" % (page + 1, ))

            item = mediaitem.MediaItem(title, url)
            item.description = "Meer items ophalen."
            item.thumb = self.parentItem.thumb
            item.icon = self.parentItem.icon
            item.type = 'folder'
            item.fanart = self.parentItem.fanart
            item.httpHeaders["X-Requested-With"] = "XMLHttpRequest"
            item.complete = True
            return item
        else:
            # page from episode list
            totalSize = int(resultSet["Total"])
            currentPage = int(resultSet["CurrentStart"])
            currentPageSize = int(resultSet["PageSize"])
            nextPage = currentPage + currentPageSize
            if nextPage >= totalSize:
                Logger.Debug("Not adding next page item. All items displayed (Total=%s vs Current=%s)",
                             totalSize, nextPage)
                return None
            else:
                pageSize = self.nonMobileMaxPageSize
                Logger.Debug("Adding next page item starting at %s and with %s items (Total=%s)",
                             nextPage, pageSize, totalSize)

                url = self.parentItem.url
                url = url.replace("start=%s" % (currentPage,), "start=%s" % (nextPage,))
                url = url.replace("rows=%s" % (currentPageSize,), "rows=%s" % (pageSize, ))

                pageItem = mediaitem.MediaItem("\a.: Meer afleveringen :.", url)
                pageItem.thumb = self.parentItem.thumb
                pageItem.complete = True
                pageItem.SetDate(2200, 1, 1, text="")
                return pageItem

    def CreateVideoItem(self, resultSet):
        """Creates a MediaItem of type 'video' using the resultSet from the regex.

        Arguments:
        resultSet : tuple (string) - the resultSet of the self.videoItemRegex

        Returns:
        A new MediaItem of type 'video' or 'audio' (despite the method's name)

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        If the item is completely processed an no further data needs to be fetched
        the self.complete property should be set to True. If not set to True, the
        self.UpdateVideoItem method is called if the item is focussed or selected
        for playback.

        """
        Logger.Trace(resultSet)

        # in some case some properties are at the root and some at the subnode
        # get the root items here
        posix = resultSet.get('starts_at', None)
        name = resultSet.get('name', None)
        description = resultSet.get('description', '')
        image = resultSet.get('image', None)

        # the tips has an extra 'episodes' key
        if 'episode' in resultSet:
            Logger.Debug("Found subnode: episodes")
            # set to episode node
            data = resultSet['episode']
            Logger.Trace(data)
            titleExtra = resultSet.get('title', '')
        else:
            titleExtra = None
            data = resultSet

        posix = data.get('broadcasted_at', posix)
        broadcasted = datetime.datetime.fromtimestamp(posix)

        if not name:
            Logger.Debug("Trying alternative ways to get the title")
            name = data.get('series', {'name': self.parentItem.name})['name']

        name.strip("")
        if titleExtra:
            name = "%s - %s" % (name, titleExtra)

        # url = data['video']['m3u8']

        videoId = data.get('whatson_id', None)
        item = mediaitem.MediaItem(name, videoId)
        item.icon = self.icon
        item.type = 'video'
        item.complete = False
        item.description = description

        images = data.get('stills', None)
        if images:
            # there were images in the stills
            item.thumb = images[-1]['url']
        elif image:
            # no stills, or empty, check for image
            item.thumb = image

        item.SetDate(broadcasted.year, broadcasted.month, broadcasted.day, broadcasted.hour, broadcasted.minute,
                     broadcasted.second)

        return item

    def UpdateVideoItem(self, item):
        """Updates an existing MediaItem with more data.

        Arguments:
        item : MediaItem - the MediaItem that needs to be updated

        Returns:
        The original item with more data added to it's properties.

        Used to update none complete MediaItems (self.complete = False). This
        could include opening the item's URL to fetch more data and then process that
        data or retrieve it's real media-URL.

        The method should at least:
        * cache the thumbnail to disk (use self.noImage if no thumb is available).
        * set at least one MediaItemPart with a single MediaStream.
        * set self.complete = True.

        if the returned item does not have a MediaItemPart then the self.complete flag
        will automatically be set back to False.

        """

        if "/radio/" in item.url or "/live/" in item.url:
            Logger.Info("Updating Live item: %s", item.url)
            return self.UpdateVideoItemLive(item)

        whatson_id = item.url
        return self.__UpdateVideoItem(item, whatson_id)

    def CreateVideoItemNonMobile(self, resultSet):
        """Creates a MediaItem of type 'video' using the resultSet from the regex.

        Arguments:
        resultSet : tuple (string) - the resultSet of the self.videoItemRegex

        Returns:
        A new MediaItem of type 'video' or 'audio' (despite the method's name)

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        If the item is completely processed an no further data needs to be fetched
        the self.complete property should be set to True. If not set to True, the
        self.UpdateVideoItem method is called if the item is focussed or selected
        for playback.

        """
        Logger.Trace(resultSet)

        name = resultSet["Title"].strip()
        videoId = resultSet["WhatsOnId"]
        description = resultSet["Description"]

        item = mediaitem.MediaItem(name, videoId)
        item.icon = self.icon
        item.type = 'video'
        item.complete = False
        item.description = description
        item.thumb = resultSet["Image"].replace("s174/c174x98", "s348/c348x196")

        year = resultSet["Year"]
        month = resultSet["Month"]
        month = DateHelper.GetMonthFromName(month, "nl")
        day = resultSet["Day"]
        hour = resultSet["Hours"]
        minute = resultSet["Minutes"]
        item.SetDate(year, month, day, hour, minute, 0)
        return item

    def CreateFolderItemLive(self, resultSet):
        """Creates a MediaItem of type 'folder' using the resultSet from the regex.

        Arguments:
        resultSet : tuple(strig) - the resultSet of the self.folderItemRegex

        Returns:
        A new MediaItem of type 'folder'

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        """

        if not self.parentItem.url.endswith("/radio"):
            # in case of radio, just display the folders on the main url
            return None

        resultSet = list(resultSet)
        resultSet.insert(0, 0)
        folderItem = self.CreateVideoItemLive(resultSet)
        folderItem.type = 'folder'
        return folderItem

    def CreateVideoItemLive(self, resultSet):
        """Creates a MediaItem of type 'video' using the resultSet from the regex.

        Arguments:
        resultSet : tuple (string) - the resultSet of the self.videoItemRegex

        Returns:
        A new MediaItem of type 'video' or 'audio' (despite the method's name)

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        If the item is completely processed an no further data needs to be fetched
        the self.complete property should be set to True. If not set to True, the
        self.UpdateVideoItem method is called if the item is focussed or selected
        for playback.

        """

        Logger.Trace("Content = %s", resultSet)

        if resultSet[0] == 0:
            resultSet = resultSet[1:]
            # first regex matched -> video channel
            name = resultSet[1]
            name = name.replace("-", " ").capitalize()

            item = mediaitem.MediaItem(name, "%s/%s/%s" % (self.baseUrlLive, resultSet[0], resultSet[1]), type="video")

            if resultSet[2].startswith("http"):
                item.thumb = resultSet[2].replace("regular_", "").replace("larger_", "")
            elif resultSet[2].startswith("//"):
                item.thumb = "http:%s" % (resultSet[2].replace("regular_", "").replace("larger_", ""),)
            else:
                item.thumb = "%s%s" % (self.baseUrlLive, resultSet[2].replace("regular_", "").replace("larger_", ""))
        else:
            # radio item hit
            if self.parentItem.url.endswith("/radio"):
                # don't show playback items on main radio page
                return None

            resultSet = resultSet[1:]
            item = mediaitem.MediaItem(resultSet[1], resultSet[0], type="video")
            item.thumb = self.parentItem.thumb

        item.icon = self.icon
        item.complete = False
        return item

    def UpdateVideoItemLive(self, item):
        """Updates an existing MediaItem with more data.

        Arguments:
        item : MediaItem - the MediaItem that needs to be updated

        Returns:
        The original item with more data added to it's properties.

        Used to update none complete MediaItems (self.complete = False). This
        could include opening the item's URL to fetch more data and then process that
        data or retrieve it's real media-URL.

        The method should at least:
        * cache the thumbnail to disk (use self.noImage if no thumb is available).
        * set at least one MediaItemPart with a single MediaStream.
        * set self.complete = True.

        if the returned item does not have a MediaItemPart then the self.complete flag
        will automatically be set back to False.

        """

        Logger.Debug('Starting UpdateVideoItem: %s', item.name)

        item.MediaItemParts = []
        part = item.CreateNewEmptyMediaPart()

        if item.url.startswith("http://ida.omroep.nl/aapi/"):
            # we already have the m3u8
            actualStreamData = UriHandler.Open(item.url, proxy=self.proxy, referer=self.baseUrlLive)
            self.__AppendM3u8ToPart(part, actualStreamData)
        else:
            # we need to determine radio or live tv
            Logger.Debug("Fetching live stream data")
            htmlData = UriHandler.Open(item.url, proxy=self.proxy)

            mp3Urls = Regexer.DoRegex("""data-streams='{"url":"([^"]+)","codec":"[^"]+"}'""", htmlData)
            if len(mp3Urls) > 0:
                Logger.Debug("Found MP3 URL")
                part.AppendMediaStream(mp3Urls[0], 192)
            else:
                jsonUrls = Regexer.DoRegex('<div class="video-player-container"[^>]+data-prid="([^"]+)"', htmlData)
                jsonUrl = None
                for url in jsonUrls:
                    jsonUrl = "http://e.omroep.nl/metadata/aflevering/%s" % (url,)

                jsonData = UriHandler.Open(jsonUrl, proxy=self.proxy)
                json = JsonHelper(jsonData, Logger.Instance())

                for stream in json.GetValue("streams"):
                    if stream['type'] == "hls":
                        url = stream['url']

                        # http://ida.omroep.nl/aapi/?type=jsonp&stream=http://livestreams.omroep.nl/live/npo/thematv/journaal24/journaal24.isml/journaal24.m3u8
                        Logger.Debug("Opening IDA server for actual URL retrieval")
                        actualStreamData = UriHandler.Open("http://ida.omroep.nl/aapi/?stream=%s" % (url,),
                                                           proxy=self.proxy, referer=self.baseUrlLive)
                        self.__AppendM3u8ToPart(part, actualStreamData)

                thumbs = json.GetValue('images')
                if thumbs:
                    item.thumb = thumbs[-1]['url']

        item.complete = True
        # Logger.Trace(item)
        return item

    def GetDefaultCachePath(self):
        """ returns the default cache path for this channel"""

        # set the UZG path
        if AddonSettings.GetUzgCacheDuration() > 0:
            cachPath = AddonSettings.GetUzgCachePath()
            if cachPath:
                Logger.Trace("UZG Cache path resolved to: %s", cachPath)
                return cachPath

        cachePath = chn_class.Channel.GetDefaultCachePath(self)
        Logger.Trace("UZG Cache path resolved chn_class default: %s", cachePath)
        return cachePath

    # noinspection PyUnusedLocal
    def SearchSite(self, url=None):  # @UnusedVariable
        """Creates an list of items by searching the site

        Returns:
        A list of MediaItems that should be displayed.

        This method is called when the URL of an item is "searchSite". The channel
        calling this should implement the search functionality. This could also include
        showing of an input keyboard and following actions.

        """
        url = "%s/episodes/search/%s.json" % (self.baseUrl, "%s")
        return chn_class.Channel.SearchSite(self, url)

    def CtMnDownload(self, item):
        """ downloads a video item and returns the updated one
        """
        #noinspection PyUnusedLocal
        item = self.DownloadVideoItem(item)

    def __AppendM3u8ToPart(self, part, idaData):
        actualStreamJson = JsonHelper(idaData, Logger.Instance())
        m3u8Url = actualStreamJson.GetValue('stream')

        # now we have the m3u8 URL, but it will do a HTML 302 redirect
        (headData, m3u8Url) = UriHandler.Header(m3u8Url, proxy=self.proxy)  # : @UnusedVariables

        for s, b in M3u8.GetStreamsFromM3u8(m3u8Url, self.proxy):
            part.AppendMediaStream(s, b)

    def __UpdateVideoItem(self, item, episodeId):
        """Updates an existing MediaItem with more data.

        Arguments:
        item      : MediaItem - the MediaItem that needs to be updated
        episodeId : String    - The episodeId, e.g.: VARA_xxxxxx

        Returns:
        The original item with more data added to it's properties.

        Used to update none complete MediaItems (self.complete = False). This
        could include opening the item's URL to fetch more data and then process that
        data or retrieve it's real media-URL.

        The method should at least:
        * cache the thumbnail to disk (use self.noImage if no thumb is available).
        * set at least one MediaItemPart with a single MediaStream.
        * set self.complete = True.

        if the returned item does not have a MediaItemPart then the self.complete flag
        will automatically be set back to False.

        """

        Logger.Trace("Using Generic UpdateVideoItem method")

        # get the subtitle
        subTitleUrl = "http://e.omroep.nl/tt888/%s" % (episodeId,)
        subTitlePath = subtitlehelper.SubtitleHelper.DownloadSubtitle(subTitleUrl, episodeId + ".srt", format='srt',
                                                                      proxy=self.proxy)

        # we need an hash code
        hashCode = self.__GetHashCode(item)

        metaUrl = "http://e.omroep.nl/metadata/aflevering/%s" % (episodeId,)
        metaData = UriHandler.Open(metaUrl, proxy=self.proxy)
        metaJson = JsonHelper(metaData)

        item.MediaItemParts = []
        part = item.CreateNewEmptyMediaPart()
        part.Subtitle = subTitlePath

        streams = []
        directStreamVideos = AddonSettings.GetUzgCacheDuration() == 0
        streamSource = [
            "http://ida.omroep.nl/odi/?prid=%s&puboptions=h264_bb,h264_sb,h264_std&adaptive=no&part=1&token=%s" % (
                episodeId, hashCode,)]
        if directStreamVideos:
            # first look for adaptive streams
            Logger.Debug("UZG is configured to streams, so also check for the adaptive streams")
            streamSource.insert(0,
                                "http://ida.omroep.nl/odi/?prid=%s&puboptions=adaptive&adaptive=yes&part=1&token=%s" % (
                                    episodeId, hashCode,))
        else:
            Logger.Debug("UZG is configured to download. Not going to fetch the adaptive streams")

        # get the standard streams:
        for streamSourceUrl in streamSource:
            streamUrlData = UriHandler.Open(streamSourceUrl, proxy=self.proxy, noCache=True)
            streamJson = JsonHelper(streamUrlData)
            for url in streamJson.GetValue('streams'):
                Logger.Trace("Going to look for streams in: %s", url)
                streams.append(url)

        # should we cache before playback
        if not directStreamVideos:
            part.CanStream = False

        for url in streams:
            data = UriHandler.Open(url, proxy=self.proxy)

            # either do m3u8 or hls
            if "m3u8" in url.lower():
                Logger.Trace("Processing M3U8 Json: %s", url)
                jsonData = JsonHelper(UriHandler.Open(url, proxy=self.proxy))
                m3u8url = jsonData.GetValue("url")
                if m3u8url is None:
                    Logger.Warning("Could not find stream in: %s", m3u8url)
                    continue
                Logger.Trace("Processing M3U8 Streams: %s", m3u8url)

                for s, b in M3u8.GetStreamsFromM3u8(m3u8url, self.proxy):
                    item.complete = True
                    part.AppendMediaStream(s, b)

                # if we found an adaptive m3u8, we take that one as it's better
                Logger.Info("Found M3u8 streams and using those. Stop looking further for non-adaptive ones.")
                break
            else:
                Logger.Trace("Processing HLS: %s", url)
                if "h264_bb" in url:
                    bitrate = 500
                elif "h264_sb" in url:
                    bitrate = 220
                elif "h264_std" in url:
                    bitrate = 1000
                else:
                    bitrate = None

                actualJson = JsonHelper(data)
                protocol = actualJson.GetValue('protocol')
                if protocol:
                    url = "%s://%s%s" % (protocol, actualJson.GetValue('server'), actualJson.GetValue('path'))
                    part.AppendMediaStream(url, bitrate=bitrate)
                else:
                    Logger.Warning("Found UZG Stream without a protocol. Probably a expired page.")

        # now we need to get extra info from the data
        item.description = metaJson.GetValue("info")
        item.title = metaJson.GetValue('aflevering_titel')
        station = metaJson.GetValue('streamSense', 'station')

        if station.startswith('nederland_1'):
            item.icon = self.GetImageLocation("1icon.png")
        elif station.startswith('nederland_2'):
            item.icon = self.GetImageLocation("2icon.png")
        elif station.startswith('nederland_3'):
            item.icon = self.GetImageLocation("3icon.png")
        Logger.Trace("Icon for station %s = %s", station, item.icon)

        # <image size="380x285" ratio="4:3">http://u.omroep.nl/n/a/2010-12/380x285_boerzoektvrouw_yvon.png</image>
        thumbUrls = metaJson.GetValue('images')  # , {"size": "380x285"}, {"ratio":"4:3"})
        Logger.Trace(thumbUrls)
        if thumbUrls:
            thumbUrl = thumbUrls[-1]['url']
        else:
            thumbUrl = self.noImage

        if not "http" in thumbUrl:
            thumbUrl = "http://u.omroep.nl/n/a/%s" % (thumbUrl,)

        item.thumb = thumbUrl
        Logger.Trace(thumbUrl)

        item.complete = True
        return item

    def __GetHashCode(self, item):
        tokenUrl = "http://ida.omroep.nl/npoplayer/i.js"
        tokenExpired = True
        tokenFile = "uzg-i.js"
        tokenPath = os.path.join(Config.cacheDir, tokenFile)

        # determine valid token
        if os.path.exists(tokenPath):
            mTime = os.path.getmtime(tokenPath)
            timeDiff = time.time() - mTime
            maxTime = 30 * 60  # if older than 15 minutes, 30 also seems to work.
            Logger.Debug("Found token '%s' which is %s seconds old (maxAge=%ss)", tokenFile, timeDiff, maxTime)
            if timeDiff > maxTime:
                Logger.Debug("Token expired.")
                tokenExpired = True
            elif timeDiff < 0:
                Logger.Debug("Token modified time is in the future. Ignoring token.")
                tokenExpired = True
            else:
                tokenExpired = False
        else:
            Logger.Debug("No Token Found.")

        if tokenExpired:
            Logger.Debug("Fetching a Token.")
            tokenData = UriHandler.Open(tokenUrl, proxy=self.proxy, noCache=True)
            tokenHandle = file(tokenPath, 'w')
            tokenHandle.write(tokenData)
            tokenHandle.close()
            Logger.Debug("Token saved for future use.")
        else:
            Logger.Debug("Reusing an existing Token.")
            # noinspection PyArgumentEqualDefault
            tokenHandle = file(tokenPath, 'r')
            tokenData = tokenHandle.read()
            tokenHandle.close()

        # perhaps we should random it?
        token = Regexer.DoRegex('npoplayer.token = "([^"]+)', tokenData)[-1]
        Logger.Info("Found NOS token for %s: %s", item, token)
        return token

    def __IsMobileUrl(self, url):
        return "apps-api.uitzendinggemist.nl" in url

    def __GetThumbUrl(self, thumbnails):
        """ fetches the thumburl from an coded string

        Arguments:
        thumbnails  : string - a list of thumbnails in the format:
                               &quot;<URL>&quot;,&quot;<URL>&quote;

        returns the URL of single thumb

        """

        # thumb splitting
        if len(thumbnails) > 0:
            thumbnails = thumbnails.split(';')
            # Logger.Trace(thumbnails)
            thumbUrl = thumbnails[1].replace('140x79', '280x158').replace('60x34', '280x158').replace("&quot", "")
            # Logger.Trace(thumbUrl)
        else:
            thumbUrl = ""

        return thumbUrl

    def __IgnoreCookieLaw(self):
        """ Accepts the cookies from UZG in order to have the site available """

        Logger.Info("Setting the Cookie-Consent cookie for www.uitzendinggemist.nl")

        # the rfc2109 parameters is not valid in Python 2.4 (Xbox), so we ommit it.
        c = cookielib.Cookie(version=0, name='site_cookie_consent', value='yes', port=None, port_specified=False,
                             domain='.www.uitzendinggemist.nl', domain_specified=True, domain_initial_dot=False,
                             path='/', path_specified=True, secure=False, expires=2327431273, discard=False,
                             comment=None, comment_url=None, rest={'HttpOnly': None})  # , rfc2109=False)
        UriHandler.Instance().cookieJar.set_cookie(c)

        # a second cookie seems to be required
        c = cookielib.Cookie(version=0, name='npo_cc', value='tmp', port=None, port_specified=False,
                             domain='.www.uitzendinggemist.nl', domain_specified=True, domain_initial_dot=False,
                             path='/', path_specified=True, secure=False, expires=2327431273, discard=False,
                             comment=None, comment_url=None, rest={'HttpOnly': None})  # , rfc2109=False)
        UriHandler.Instance().cookieJar.set_cookie(c)

        # the rfc2109 parameters is not valid in Python 2.4 (Xbox), so we ommit it.
        c = cookielib.Cookie(version=0, name='site_cookie_consent', value='yes', port=None, port_specified=False,
                             domain='.www.npo.nl', domain_specified=True, domain_initial_dot=False, path='/',
                             path_specified=True, secure=False, expires=2327431273, discard=False, comment=None,
                             comment_url=None, rest={'HttpOnly': None})  # , rfc2109=False)
        UriHandler.Instance().cookieJar.set_cookie(c)

        # Set-Cookie: npo_cc=30; path=/; domain=www.npo.nl; expires=Tue, 09-Aug-2044 21:55:39 GMT
        c = cookielib.Cookie(version=0, name='npo_cc', value='30', port=None, port_specified=False,
                             domain='.www.npo.nl', domain_specified=True, domain_initial_dot=False, path='/',
                             path_specified=True, secure=False, expires=2327431273, discard=False, comment=None,
                             comment_url=None, rest={'HttpOnly': None})  # , rfc2109=False)
        UriHandler.Instance().cookieJar.set_cookie(c)

        # http://pilot.odcontent.omroep.nl/codem/h264/1/nps/rest/2013/NPS_1220255/NPS_1220255.ism/NPS_1220255.m3u8
        # balancer://sapi2cluster=balancer.sapi2a

        # c = cookielib.Cookie(version=0, name='balancer://sapi2cluster', value='balancer.sapi2a', port=None, port_specified=False, domain='.pilot.odcontent.omroep.nl', domain_specified=True, domain_initial_dot=False, path='/', path_specified=True, secure=False, expires=2327431273, discard=False, comment=None, comment_url=None, rest={'HttpOnly': None})  # , rfc2109=False)
        # UriHandler.Instance().cookieJar.set_cookie(c)
        # c = cookielib.Cookie(version=0, name='balancer://sapi1cluster', value='balancer.sapi1a', port=None, port_specified=False, domain='.pilot.odcontent.omroep.nl', domain_specified=True, domain_initial_dot=False, path='/', path_specified=True, secure=False, expires=2327431273, discard=False, comment=None, comment_url=None, rest={'HttpOnly': None})  # , rfc2109=False)
        # UriHandler.Instance().cookieJar.set_cookie(c)
        return
