import mediaitem
import contextmenu
import chn_class

from regexer import Regexer
from logger import Logger
from urihandler import UriHandler
from helpers.jsonhelper import JsonHelper
from helpers.encodinghelper import EncodingHelper
from encrypter import Encrypter


class Channel(chn_class.Channel):

    def __init__(self, channelInfo):
        """Initialisation of the class.

        Arguments:
        channelInfo: ChannelInfo - The channel info object to base this channel on.

        All class variables should be instantiated here and this method should not
        be overridden by any derived classes.

        """

        chn_class.Channel.__init__(self, channelInfo)

        # ============== Actual channel setup STARTS here and should be overwritten from derived classes ===============
        self.noImage = "123image.png"

        # set context menu items
        self.contextMenuItems.append(contextmenu.ContextMenuItem("Download Item", "CtMnDownloadItem", itemTypes="video"))

        # configure login stuff
        self.passWord = ""
        self.userName = ""
        self.logonUrl = ""
        self.requiresLogon = False

        # setup the urls
        self.mainListUri = "http://www.123video.nl/"
        self.baseUrl = "http://www.123video.nl/"

        # setup the main parsing data
        self.episodeItemRegex = '<a[^>]+href="/(video/[^"]+)" title="([^"]+)"'
        self.videoItemRegex = '<a onFocus="this.blur\(\);" href="/playvideos.asp\?MovieID=(\d+)[^"]*" title="([^"]+)"[^>]+>\W*<img src="([^"]+)"[^>]+></a>[\w\W]{0,800}?Geplaatst:[^-]*(\d+)-(\d+)-(\d+)'
        self.pageNavigationRegex = '<a href="(/video.asp\?Page=)(\d+)([^"]+)" title="Ga naar pagina'
        self.pageNavigationRegexIndex = 1

        #===============================================================================================================
        # non standard items
        self.ipVideoServer = "85.17.191.49"

        #===============================================================================================================
        # Test cases:

        # ====================================== Actual channel setup STOPS here =======================================
        return

    def CreateEpisodeItem(self, resultSet):
        """
        Accepts an arraylist of results. It returns an item.
        """

        item = mediaitem.MediaItem(resultSet[1], "%s%s" % (self.baseUrl, resultSet[0]))
        item.thumb = self.noImage
        return item

    def PreProcessFolderList(self, data):
        """Performs pre-process actions for data processing/

        Arguments:
        data : string - the retrieve data that was loaded for the current item and URL.

        Returns:
        A tuple of the data and a list of MediaItems that were generated.


        Accepts an data from the ProcessFolderList method, BEFORE the items are
        processed. Allows setting of parameters (like title etc) for the channel.
        Inside this method the <data> could be changed and additional items can
        be created.

        The return values should always be instantiated in at least ("", []).

        """

        items = []
        # first part of the data to prevent double pages
        data = Regexer.DoRegex('<div class="resultBox">([\w\W]+)', data)[0]

        Logger.Debug("Pre-Processing finished")
        return data, items

    def CreateFolderItem(self, resultSet):
        """Creates a MediaItem of type 'folder' using the resultSet from the regex.

        Arguments:
        resultSet : tuple(strig) - the resultSet of the self.folderItemRegex

        Returns:
        A new MediaItem of type 'folder'

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        """

        item = mediaitem.MediaItem("Pagina %02i" % int(resultSet[2]), "%s%s%s" % (self.mainListUri, resultSet[0], resultSet[1]))
        item.description = item.name
        item.type = 'folder'
        item.thumb = self.noImage
        item.complete = True
        return item

    def CreateVideoItem(self, resultSet):
        """Creates a MediaItem of type 'video' using the resultSet from the regex.

        Arguments:
        resultSet : tuple (string) - the resultSet of the self.videoItemRegex

        Returns:
        A new MediaItem of type 'video' or 'audio' (despite the method's name)

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        If the item is completely processed an no further data needs to be fetched
        the self.complete property should be set to True. If not set to True, the
        self.UpdateVideoItem method is called if the item is focussed or selected
        for playback.

        """

        Logger.Trace('starting FormatVideoItem for %s', self.channelName)

        item = mediaitem.MediaItem(resultSet[1].title(), resultSet[0])
        item.icon = self.icon
        item.type = 'video'

        item.SetDate(resultSet[5], resultSet[4], resultSet[3])
        item.description = item.name
        item.thumb = resultSet[2]
        item.complete = False

        return item

    def UpdateVideoItem(self, item):
        """
        Accepts an item. It returns an updated item. Usually retrieves the MediaURL
        and the Thumb! It should return a completed item.
        """
        Logger.Debug('starting UpdateVideoItem for %s (%s)', item.name, self.channelName)

        movieId = int(item.url)
        Logger.Trace(movieId)

        # we need to encrypt stuff to get this to work
        enc = Encrypter(movieId)
        jsonInput = self.__GetJson(movieId, enc.publicKey, enc.salt)
        Logger.Trace(jsonInput)
        postData = enc.EncryptWithKey(jsonInput)

        # now send this out
        result = UriHandler.Open("http://www.123video.nl/initialize_player_v4.aspx",
                                 proxy=self.proxy,
                                 params=postData,
                                 additionalHeaders={'123videoPlayer': enc.publicKey})
        jsonOutput = enc.DecryptWithKey(result)
        Logger.Trace(jsonOutput)

        # and create the actual video url
        jsonData = JsonHelper(jsonOutput)
        hashes = jsonData.GetValue('Hashes')
        locations = jsonData.GetValue('Locations')
        videoData = (locations[0], enc.publicKey, EncodingHelper.EncodeMD5(hashes[0], False), int(movieId / 1000), movieId, enc.EncryptWithKey('{"Salt": "%s"}' % (enc.salt,), enc.publicKey))
        mediaurl = "http://%s/%s/%s/%s/%s.flv?%s" % videoData

        if mediaurl != "":
            item.AppendSingleStream(mediaurl)

        item.complete = True
        item.downloadable = True

        Logger.Trace("Finished updating videoitem: %s", item)
        return item

    def __GetJson(self, movieId, publicKey, salt):
        """ Take from the 123video.swf

        Random:String(Math.floor(Math.random()*1.0E10)),
        MovieID:TopLevel.Variables.MovieID,
        MemberID:Number(TopLevel.getParameter("MemberID",0)),
        Password:String(TopLevel.getParameter("Password","")),
        PublicKey:TopLevel.Variables.PublicKey,
        IsEmbedded:TopLevel.Variables.isEmbedded,
        EmbedUrl:TopLevel.Domain.embedUrl,
        AdWanted:(TopLevel.Variables.isEmbedded)||(Boolean(Number(TopLevel.getParameter("RequestAd","1")))),
        ExternalInterfaceAvailable:ExternalInterface.available,
        Salt:TopLevel.Variables.Salt

        """

        json = dict()
        json['Random'] = "31415926"
        json['MovieID'] = movieId
        json['MemberID'] = 0
        json['Password'] = ""
        json['PublicKey'] = publicKey
        json['IsEmbedded'] = False
        json['EmbedUrl'] = ""
        json['AdWanted'] = False
        json['ExternalInterfaceAvailable'] = False
        json['Salt'] = salt
        return str(json).replace("False", "false").replace("True", "true").replace("'", '"')

    #==============================================================================
    # ContextMenu functions
    #==============================================================================
    def CtMnUpdateItem(self, item):
        self.UpdateVideoItem(item)

    def CtMnDownloadItem(self, item):
        item = self.DownloadVideoItem(item)
        return item
