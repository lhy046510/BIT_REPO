service.subtitles.torec
==================

XBMC Torec subtitle service for Gotham