#! /usr/bin/env python
# coding=utf-8
from xbmcswift2 import Plugin, xbmcgui, xbmc, xbmcaddon
import urllib2
import json
import time
from urllib import unquote_plus, quote_plus
#from BeautifulSoup import BeautifulSoup


plugin = Plugin()
API_HOST = 'http://tv1.hdpfans.com:8088/'


@plugin.route('/bt/<btih>/')
def play_btih(btih):
    params = get_params()
    name = params.get('name', '')
    print '*' * 30, btih, name
    mvfiles = get_bt_list(btih)
    print mvfiles
    if not mvfiles:
        return

    index = 0
    if len(mvfiles) > 1:
        dialog = xbmcgui.Dialog()
        index = dialog.select(u'选择视频文件', [x['name'] for x in mvfiles])

    if index >= 0:
        node = mvfiles[index]
        # soup = BeautifulSoup(xunleiNewAPI(node['gcid'], node['cid']))
        # print soup.find("command")
        # if soup.find("command").get("message") == "ok":
        #     urls = iter_playable_bt_urls_with_newXUNLEI(soup)
        # else:
        urls = iter_playable_bt_urls(
            btih, node['gcid'], node['index'], node['name'])
        try_and_play(urls, name or node['name'], node['gcid'], node['cid'])


@plugin.route('/ed2k/<ed2k_url>/')
def play_ed2k(ed2k_url):
    params = get_params()
    name = params.get('name', '')
    print '*' * 30, ed2k_url

    urls = iter_playable_ed2k_urls(ed2k_url)
    try_and_play(urls, name)


def get_params():
    return dict((k, v[0]) for k, v in plugin.request.args.items())


def try_and_play(urls, name, gcid=None, cid=None):
    listitem = xbmcgui.ListItem(name)
    listitem.setInfo(type="Video", infoLabels={'Title': name})
    listitem.setProperty('mimetype', 'vdeo/mp4')

    sublist = None
    t_start = time.time()
    if gcid and cid:
        try:
            sub_api_url = 'http://i.vod.xunlei.com/subtitle/list?gcid=%s&cid=%s&userid=1&t=%s' % (
                gcid, cid, int(1000 * time.time()))
            r = json.loads(urllib2.urlopen(sub_api_url).read())
            sublist = [s['surl'] for s in r['sublist']]

        except:
            pass

    xbmc.sleep(max(0, 2000 - int(time.time() - t_start)))

    for url in urls:
        try:
            player = Player()
            player.play(url, listitem, sublist=sublist)

            break
        except:
            print 'error: ' + url
            # xbmc.sleep(2000)
            continue
    else:
        plugin.notify('没有找到可用的视频资源', '', delay=2000)


def iter_playable_ed2k_urls(ed2k_url, prefer='flv', order=['flv', 'm3u8']):
    if prefer in order:
        order.remove(prefer)
    order.insert(0, prefer)

    for video_type in order:
        if video_type == 'flv':
            url = '{0}api/u/{1}/flv'.format(
                API_HOST, quote_plus(quote_plus(ed2k_url, '')))
            print url
            r = json.loads(urllib2.urlopen(url).read())
            for m in reversed(r.get('flvs', [])):
                yield m['vod_url']
        elif video_type == 'm3u8':
            url = '{0}api/u/{1}/m3u8'.format(
                API_HOST, quote_plus(quote_plus(ed2k_url, '')))
            r = json.loads(urllib2.urlopen(url).read())
            for m in reversed(r.get('m3u8s', [])):
                yield m['vod_url']


def iter_playable_bt_urls(btih, gcid, index, name,
                          prefer='flv', order=['flv', 'mp4', 'm3u8']):
    if prefer in order:
        order.remove(prefer)
    order.insert(0, prefer)

    for video_type in order:
        if video_type == 'flv':
            print index, btih
            url = '{0}api/bt/{1}/{2}/flv'.format(API_HOST, btih, index)
            r = json.loads(urllib2.urlopen(url).read())
            for m in reversed(r.get('flvs', [])):
                yield m['vod_url']
        elif video_type == 'mp4':
            url = '{0}api/bt/{1}/{2}/mp4'.format(API_HOST, btih, index)
            r = json.loads(urllib2.urlopen(url).read())
            for m in reversed(r.get('mp4s', [])):
                yield m['vod_url']
        elif video_type == 'm3u8':
            url = '{0}api/bt/{1}/{2}/m3u8'.format(API_HOST, btih, index)
            r = json.loads(urllib2.urlopen(url).read())
            for m in reversed(r.get('m3u8s', [])):
                yield m['vod_url']
        elif video_type == 'raw':
            yield 'http://roybinux.duapp.com/{0}/{1}?userid=1'.format(
                btih, quote_plus(name))


def iter_playable_bt_urls_with_newXUNLEI(
        soup, prefer='high_url',
        order=['high_url', 'middle_url', "normal_url"]):
    if prefer in order:
        order.remove(prefer)
    order.insert(0, prefer)

    playurl = soup.find("play_url")
    mp4url = soup.find("mp4_url")

    if playurl and mp4url:
        for url_type in order:
            if playurl.get(url_type) and playurl[url_type] != "":
                yield playurl[url_type]

            if mp4url.get(url_type) and mp4url[url_type] != "":
                yield mp4url[url_type]


def get_bt_list(btih):
    url = 'http://i.vod.xunlei.com/req_subBT/info_hash/%s/req_num/2000/req_offset/0/' % btih.upper()  # noqa
    r = json.loads(unquote_plus(urllib2.urlopen(url).read()))
    return r['resp']['subfile_list']


def xunleiNewAPI(gcid, cid):
    __addon__ = xbmcaddon.Addon(id='script.thunder.player')
    Setting_uid = __addon__.getSetting('thunder_uid')
    if Setting_uid == "":
        Setting_uid = "133612081"
        dialog = xbmcgui.Dialog()
        if dialog.yesno(u"检测到您还没有输入迅雷uid", u"输入迅雷uid可以获取更快的连接速度，是否输入uid？", "登录迅雷看看点“我的主页”，地址栏最后的那个数字就是uid", "该用户需要登陆过迅雷离线apk"):  # noqa
            uid = dialog.numeric(0, "输入迅雷用户uid（纯数字）")
            if uid != "" and uid != "0":
                Setting_uid = uid
                __addon__.setSetting('thunder_uid', uid)
            else:
                dialog.yesno(u"提示", u"没有输入任何uid，将用公共账号（不稳定）进行连接")
        else:
            if dialog.yesno(u"不再弹出此提示", u"选“是”将一直使用公共账号（不稳定）并且不会再弹出此提示", "选“否”本次播放使用公共账号，您的账号可以在下次播放时重新输入"):  # noqa
                __addon__.setSetting('thunder_uid', "133612081")
    postXML = '<?xml version="1.0" encoding="utf-8"?>\
            <LixianProtocol Version="1.0">\
            <Command id="getplayurl_req">\
            <user id="{0}" name="" newno="0" vip_level="5" net="0" ip="1694542016" key="" from="2"/>\
            <content gcid="{1}" cid="{2}" dev_width="720" dev_hight="1280" section_type="0" filesize="1" max_fpfile_num="10" video_type="7" />\
            </Command>\
            </LixianProtocol>'.format(Setting_uid, gcid, cid)
    f = urllib2.urlopen(
        url='http://pad.i.vod.xunlei.com/',
            data=postXML
    )
    resultString = f.read()
    print resultString
    return resultString


class Player(xbmc.Player):

    def play(self, item='', listitem=None, windowed=False, sublist=None):
        self._sublist = sublist

        super(Player, self).play(item, listitem, windowed)

        self._start_time = time.time()
        while True:
            # print self._start_time, time.time()
            if self._stopped or time.time() - self._start_time > 30:
                if self._totalTime == 999999:
                    raise PlaybackFailed(
                        'XBMC silently failed to start playback')
                break

            xbmc.sleep(500)
        # print 'play end'

    def __init__(self):
        self._stopped = False
        self._totalTime = 999999

        xbmc.Player.__init__(self, xbmc.PLAYER_CORE_AUTO)

    def onPlayBackStarted(self):
        self._totalTime = self.getTotalTime()
        self._start_time = time.time()

        sublist = self._sublist
        if sublist:
            for surl in sublist:
                # print '$'*50, surl
                self.setSubtitles(surl)
            self.setSubtitleStream(0)
            # self.showSubtitles(False)

    def onPlayBackStopped(self):
        self._stopped = True

    def onPlayBackEnded(self):
        self.onPlayBackStopped()


class PlaybackFailed(Exception):

    '''Raised to indicate that xbmc silently failed to play the stream'''


if __name__ == '__main__':
    plugin.run()
