# -*- encoding: utf-8 -*- 
""" API for accessing www.stv.sk streams/videos """

__all__ = ["STVPlugin"]

from basePlugin import *
import urllib
import re

RE_DATE         = re.compile(r'(\d{1,2}\.\d{1,2}\.\d{4})')
RE_QUERY_STRING = re.compile(r'(\?.*)?$')
RE_PLAYLISTFILE = re.compile(r"'flashvars','playlistfile=([^\"'&]*)")


class STVPlugin(BasePlugin):
    LOGPREFIX = "[STV plugin] "
    BASE_URL = "http://www.stv.sk"

    @plugin_folder
    def root(self):
        """ videoarchiv - list programs """
        self.wget.request(self.BASE_URL + '/online/archiv/')
        for e in self.wget.select('ul.arch-list li a'):
            if not e['href'].startswith('#'):
                yield PFolder(label=e.text, call='relacia',
                            param={'path': e['href']} )


    @plugin_folder
    def relacia(self, path):
        """ relacia - list periods """
        url = self.BASE_URL + path + '?list-all=1'
        self.wget.request(url)
        relacie_ul = self.wget.select_first('.play-r ul.arch-playlist')

        current_date = None
        li_items = relacie_ul.select('li')
        # check for error
        if len(li_items) == 1 and li_items[0]['class'] == 'err':
            self.core.okDialog('STV plugin error', li_items[0].text)
            return

        for li in li_items:
            if 'arch-date' in li['class']:
                current_date = li.text
            else:
                a_tag = li.select_first('a')
                b_tag = li.select_first('b')

                # add date
                datestr = current_date
                if not datestr:
                    m = RE_DATE.search( str(li) )
                    if m:
                        datestr = m.group(1)

                assert a_tag['href'].startswith('?')
                play_url = RE_QUERY_STRING.sub('', url) + a_tag['href']

                label = "%s - %s" % (datestr, b_tag.text)
                info = {'date': datestr }

                yield PItem(label=label, call='play',
                            param={'url': play_url}, info=info )

    @plugin_call
    def play(self, url):
        """ play video call """
        self.wget.request(url)

        m = RE_PLAYLISTFILE.search(self.wget.content)
        if not m:
            raise Exception("RE_PLAYLISTFILE not found in: " + url)

        playlist_url = urllib.unquote( m.group(1) )

        # get and parse playlist XML (rtmp stream)
        self.debug('playlist_url: ' + repr(playlist_url))
        self.wget.request( playlist_url )

        location_tag = self.wget.select_first('location')
        if not location_tag:
            raise Exception("location not found in XML playlist on url: " + playlist_url)

        streamer_tag = self.wget.select_first('meta[rel=streamer]')
        if not streamer_tag:
            raise Exception("streamer not found in XML playlist on url: " + playlist_url)

        play_url = "%s playpath=mp4:%s" % (streamer_tag.text, location_tag.text)
        self.debug('Playing url: ' + play_url)
        self.core.play(play_url)
        
