# -*- encoding: utf-8 -*- 

import unittest
from cztraileryPlugin import *
from testPluginInterface import *
import re
import os
import random


class TestCZTraileryPlugin(unittest.TestCase):
    
    def setUp(self):
        self.iface = TestPluginInterface()
        self.tmpfile = '/tmp/cztrailery-test-%x' % random.getrandbits(64)
        self.iface.PATH = { 'special://userdata/cztrailery-subtitles.srt': self.tmpfile }
        self.plugin = CZTraileryPlugin(self.iface)


    def tearDown(self):
        if os.path.exists(self.tmpfile):
            os.unlink( self.tmpfile )


    def test_root(self):
        self.plugin.call()
        self.assertEqual( len(self.iface.ITEMS), 4 )

        self.assertEqual(self.iface.ITEMS[0].label, u'Nová videa')
        self.assertEqual(self.iface.ITEMS[0].call, 'list')
        self.assertEqual(self.iface.ITEMS[0].param, {})
        self.assertTrue(self.iface.ITEMS[0].isFolder)

        self.assertEqual(self.iface.ITEMS[1].label, u'Právě v kinech')
        self.assertEqual(self.iface.ITEMS[1].call, 'list')
        self.assertEqual(self.iface.ITEMS[1].param, {'path': '/category/kino/'})
        self.assertTrue(self.iface.ITEMS[1].isFolder)

        self.assertEqual(self.iface.ITEMS[2].label, u'Kategorie')
        self.assertEqual(self.iface.ITEMS[2].call, 'categories')
        self.assertEqual(self.iface.ITEMS[2].param, {})
        self.assertTrue(self.iface.ITEMS[2].isFolder)

        self.assertEqual(self.iface.ITEMS[3].label, u'Podle abecedy')
        self.assertEqual(self.iface.ITEMS[3].call, 'alphabet')
        self.assertEqual(self.iface.ITEMS[3].param, {})
        self.assertTrue(self.iface.ITEMS[3].isFolder)

        #self.assertEqual(self.iface.ITEMS[4].label, u'Hledat')
        #self.assertEqual(self.iface.ITEMS[4].call, 'search')
        #self.assertEqual(self.iface.ITEMS[4].param, {})
        #self.assertTrue(self.iface.ITEMS[4].isFolder)


    def test_categories(self):
        self.plugin.call('categories')
        self.assertTrue( len(self.iface.ITEMS) > 10 )

        self.assertTrue( self.iface.ITEMS[0].isFolder )
        self.assertTrue( re.match(r'^\S+ - \d+ \S', self.iface.ITEMS[0].label) )
        self.assertEqual( self.iface.ITEMS[0].call, 'list' )
        self.assertTrue( re.match(r'^/tag/\w+', self.iface.ITEMS[0].param['path']) )


    def test_alphabet(self):
        self.plugin.call('alphabet')
        self.assertTrue( len(self.iface.ITEMS) > 50 )

        self.assertTrue( self.iface.ITEMS[0].isFolder )
        self.assertTrue( self.iface.ITEMS[0].label )
        self.assertEqual( self.iface.ITEMS[0].call, 'play' )
        self.assertTrue( re.match(r'^/video/', 
                                    self.iface.ITEMS[0].param['path']) )


    def test_list(self):
        self.plugin.call('list')
        self.assertTrue( len(self.iface.ITEMS) > 3 )

        self.assertTrue( not self.iface.ITEMS[0].isFolder )
        self.assertTrue( self.iface.ITEMS[0].label )
        self.assertEqual( self.iface.ITEMS[0].call, 'play' )
        self.assertTrue( re.match(r'^/video/', 
                                    self.iface.ITEMS[0].param['path']) )


    def test_list_kino(self):
        self.plugin.call('list', path='/category/kino/')
        self.assertTrue( len(self.iface.ITEMS) > 3 )

        self.assertTrue( not self.iface.ITEMS[0].isFolder )
        self.assertTrue( self.iface.ITEMS[0].label )
        self.assertEqual( self.iface.ITEMS[0].call, 'play' )
        self.assertTrue( re.match(r'^/video/', 
                                    self.iface.ITEMS[0].param['path']) )



    def test_relative_path(self):
        self.assertEqual( 
                self.plugin.relative_path('http://google.com/aaa/bbb?y=33'),
                'http://google.com/aaa/bbb?y=33')
        self.assertEqual(
                self.plugin.relative_path('http://wwW.cztraILERY.cz/tstX/K?a=3'),
                '/tstX/K?a=3')
        self.assertEqual( 
                self.plugin.relative_path('www.youtube.com/aaa/bbb?y=33'),
                'www.youtube.com/aaa/bbb?y=33')


    def test_get_item(self):
        item = self.plugin.get_info('/video/andele-a-demoni/')

        self.assertEqual( item.label, u'Andělé a démoni' )
        self.assertEqual( item.label2, 'Angels & Demons' )
        self.assertEqual( item.call, 'play' )
        self.assertEqual( item.param, {'path': '/video/andele-a-demoni/'} )
        self.assertEqual( item.isFolder, False )

        self.assertEqual( item.info.keys(), 
                            ['genre', 'director', 'plotoutline', 'studio', 'cast'] )
        
        self.assertEqual( item.info['genre'], u'Krimi/Mysteriózní/Thriller' )
        self.assertEqual( item.info['director'], u'Ron Howard' )
        self.assertEqual( item.info['cast'],
                            [u'Tom Hanks', u'Ayelet Zurer', u'Ewan McGregor', 
                                u'Stellan Skarsgård', u'Carmen Argenziano'] )
        self.assertEqual( item.info['studio'], u'Columbia Pictures' )

        self.assertTrue( "\n\n" in item.info['plotoutline'] )
        outline = re.sub('[\xa0\s]+', ' ', item.info['plotoutline'])
        self.assertEqual( outline[:20], u"A máme tady filmové " )
        self.assertEqual( outline[-25:], u" nebezpečí ale i poznání." )


    def test_download_subtitles(self):
        url = 'http://stor.cztrailery.cz/subt/09/legion.srt'
        self.assertTrue( not os.path.exists(self.tmpfile) )
        self.plugin.download_subtitles(url)
        self.assertTrue( os.path.exists(self.tmpfile) )

        f = open( self.tmpfile, 'r' )
        content = f.read()
        f.close()

        self.assertTrue( re.search('Dokonce ani jako polda z L.A.', content) )


# TODO: test this variant
#    def test_play_xmlconf(self):
#        self.plugin.call('play', path='/video/splice/')
#
#        self.assertTrue(re.search(r"play video url on path: '/video/splice/'",
#                            self.iface.LOG[0]))
#        self.assertTrue(re.search(r"streamURL: u?'http://.*youtube.com/videoplayback.*",
#                            self.iface.LOG[1]))
#        self.assertTrue(re.search(r"subtitlesURL: u?'http://.*cztrailery.cz/.*splice\.srt'",
#                            self.iface.LOG[2]))
#        self.assertTrue(re.search(r"Downloading u?'http://.*' to '" + self.tmpfile + "'",
#                            self.iface.LOG[3]))
#
#        self.assertEqual(self.iface.LOG[4][0], 'play')
#        self.assertTrue(re.match(r'http://.*youtube.com/videoplayback', self.iface.LOG[4][1]))
#        item = self.iface.LOG[4][2]
#        self.assertEqual( item.label, 'Splice' )
#        self.assertEqual( item.info['genre'], u'Sci-fi / Drama / Thriller')
#        self.assertEqual( item.info['director'], u'Vincenzo Natali')
#        self.assertTrue( re.search(u'Obsah k tomuto filmu zde najdete co nevidět',
#                            item.info['plotoutline'] ))
#        self.assertEqual( item.info['studio'], u'Warner Bros Pictures')
#        self.assertEqual( item.info['cast'], [u'Adrien Brody', u'Sarah Polley', u'Delphine Chaneac'])
#        self.assertTrue( re.match('http://.*cztrailery.cz/.*/splice.jpg', item.iconURL))
#        self.assertEqual( item.type, 'video' )
#        self.assertEqual( self.iface.LOG[4][3], self.tmpfile )


    def test_play_swfplayer(self):
        self.plugin.call('play', path='/video/999/')

        self.assertTrue(re.search(r"play video url on path: '/video/999/'",
                            self.iface.LOG[0]))
        self.assertTrue(re.search(r"streamURL: u?'http://\S+\.flv'",
                            self.iface.LOG[1]))
        self.assertTrue(re.search(r"subtitlesURL: u?'http://.*cztrailery.cz/.*9\.99\.srt'",
                            self.iface.LOG[2]))
        self.assertTrue(re.search(r"Downloading u?'http://.*\.srt' to '" + self.tmpfile + "'",
                            self.iface.LOG[3]))

        self.assertEqual(self.iface.LOG[4][0], 'play')
        self.assertTrue(re.match(r'http://.*\.flv', self.iface.LOG[4][1]))
        item = self.iface.LOG[4][2]
        self.assertEqual( item.label, '$ 9.99' )
        self.assertEqual( item.info['genre'], u'Animovaný')
        self.assertEqual( item.info['director'], u'Tatia Rosenthal')
        self.assertTrue( re.search(u'9.99 je celovečeřní animovaný film, který nabízí',
                            item.info['plotoutline'] ))
        self.assertEqual( item.info['studio'], u'Regent Releasing')
        self.assertEqual( item.info['cast'], [u'Geoffrey Rush', u'Anthony LaPaglia',
                                                u'Samuel Johnson'])
        self.assertTrue( re.match('http://.*cztrailery.cz/.*9\.99\.jpg', item.iconURL))
        self.assertEqual( item.type, 'video' )
        self.assertEqual( self.iface.LOG[4][3], self.tmpfile )


    def test_play_youtube(self):
        self.plugin.call('play', path='/video/3-sezony-v-pekle/')

        self.assertTrue(re.search(r"play video url on path: '/video/3-sezony-v-pekle/'",
                            self.iface.LOG[0]))
        self.assertEqual(self.iface.LOG[1],
            r"execute u'XBMC.RunPlugin(addon://plugin.video.youtube?action=play_video&videoid=pAl7qsW_ciU)'")


    def test_play_njoy(self):
        self.plugin.call('play', path='/video/avatar/')

        self.assertTrue(re.search(r"play video url on path: '/video/avatar/'",
                            self.iface.LOG[0]))
        self.assertTrue(re.search(r"streamURL: u?'http://.*n-joy.cz/.*\.flv'",
                            self.iface.LOG[1]))
        self.assertTrue(re.search(r"subtitlesURL: None",
                            self.iface.LOG[2]))

        self.assertEqual(self.iface.LOG[3][0], 'play')
        self.assertTrue(re.match(r'http://.*\.flv', self.iface.LOG[3][1]))
        item = self.iface.LOG[3][2]
        self.assertEqual( item.label, u'Avatar' )
        self.assertEqual( item.label2, u'Avatar' )
        self.assertEqual( item.info['genre'], u'Akční / Dobrodružný / Sci-fi')
        self.assertEqual( item.info['director'], u'James Cameron')
        self.assertTrue( re.search(u'film Jamese Camerona je založen na využití 3D efektů',
                            item.info['plotoutline'] ))
        self.assertEqual( item.info['studio'], u'20th Century Fox')
        self.assertEqual( item.info['cast'], [u'Sam Worthington', u'Zoe Saldana',
                                                u'Sigourney Weaver'])
        self.assertTrue( re.match('http://.*cztrailery.cz/.*/avatar\.jpg', item.iconURL))
        self.assertEqual( item.type, 'video' )


    def test_play_sevenload(self):
        self.plugin.call('play', path='/video/planeta-51/')

        self.assertTrue(re.search(r"play video url on path: '/video/planeta-51/'",
                            self.iface.LOG[0]))
        self.assertTrue(re.search(r"streamURL: u?'http://.*sevenload.(com|net)/.*\.mp4'",
                            self.iface.LOG[1]))
        self.assertTrue(re.search(r"subtitlesURL: None",
                            self.iface.LOG[2]))

        self.assertEqual(self.iface.LOG[3][0], 'play')
        self.assertTrue(re.match(r'http://.*\.mp4', self.iface.LOG[3][1]))
        item = self.iface.LOG[3][2]
        self.assertEqual( item.label, u'Planeta 51' )
        self.assertEqual( item.label2, u'Planet 51' )
        self.assertEqual( item.info['genre'], u'Animovaný/Dobrodružný/Fantasy/Komedie')
        self.assertEqual( item.info['director'], u'Jorge Blanco, Marcos Martínez, Javier Abad')
        self.assertTrue( re.search(u'Planeta 51 je animovaná dobrodružná komedie',
                            item.info['plotoutline'] ))
        self.assertEqual( item.info['studio'], u'New Line Cinema')
        self.assertEqual( item.info['cast'], [u'Dwayne "The Rock" Johnson', u'Jessica Biel',
                                                u'Justin Long'])
        self.assertTrue( re.match('http://.*cztrailery.cz/.*/planet51\.jpg', item.iconURL))
        self.assertEqual( item.type, 'video' )


    def test_play_zideo(self):
        self.plugin.call('play', path='/video/spread/')

        self.assertTrue(re.search(r"play video url on path: '/video/spread/'",
                            self.iface.LOG[0]))
        self.assertTrue(re.search(r"streamURL: u?'http://.*cztrailery.cz/trailery/samec.mp4'",
                            self.iface.LOG[1]))
        self.assertTrue(re.search(r"subtitlesURL: u?'http://.*cztrailery.cz/.*/spread\.srt'",
                            self.iface.LOG[2]))
        self.assertTrue(re.search(r"Downloading u?'http://.*\.srt' to '" + self.tmpfile + "'",
                            self.iface.LOG[3]))

        self.assertEqual(self.iface.LOG[4][0], 'play')
        self.assertTrue(re.match(r'http://.*\.mp4', self.iface.LOG[4][1]))
        item = self.iface.LOG[4][2]
        self.assertEqual( item.label, 'Samec' )
        self.assertEqual( item.label2, 'Spread' )
        self.assertEqual( item.info['genre'], u'Komedie')
        self.assertEqual( item.info['director'], u'David Mackenzie')
        self.assertTrue( re.search(u'Spread je svěží, sexuálně laděnou komedií.',
                            item.info['plotoutline'] ))
        self.assertEqual( item.info['studio'], u'Anchor Bay')
        self.assertEqual( item.info['cast'], [u'Ashton Kutcher', u'Anne Heche', u'Margarita Levieva'])
        self.assertTrue( re.match('http://.*cztrailery.cz/.*/spread\.jpg', item.iconURL))
        self.assertEqual( item.type, 'video' )
        self.assertEqual( self.iface.LOG[4][3], self.tmpfile )



if __name__ == '__main__':
    unittest.main()


