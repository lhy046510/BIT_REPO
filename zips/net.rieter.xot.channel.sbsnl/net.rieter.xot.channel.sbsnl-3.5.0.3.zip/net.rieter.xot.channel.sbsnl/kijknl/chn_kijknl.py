import mediaitem
import chn_class

from regexer import Regexer
from streams.brightcove import BrightCove
from helpers.htmlhelper import HtmlHelper

from logger import Logger
from urihandler import UriHandler


class Channel(chn_class.Channel):
    """
    main class from which all channels inherit
    """

    def __init__(self, channelInfo):
        """Initialisation of the class.

        Arguments:
        channelInfo: ChannelInfo - The channel info object to base this channel on.

        All class variables should be instantiated here and this method should not
        be overridden by any derived classes.

        """

        chn_class.Channel.__init__(self, channelInfo)

        # ============== Actual channel setup STARTS here and should be overwritten from derived classes ===============
        # setup the urls
        self.baseUrl = "http://www.kijk.nl"
        if self.channelCode == 'veronica':
            self.noImage = "veronicaimage.png"
            self.mainListUri = "http://www.kijk.nl/veronicatv/zender"

        elif self.channelCode == 'sbs':
            self.noImage = "sbs6image.png"
            self.mainListUri = "http://www.kijk.nl/sbs6/zender"

        elif self.channelCode == 'net5':
            self.noImage = "net5image.png"
            self.mainListUri = "http://www.kijk.nl/net5/zender"

        # setup the main parsing data
        self.episodeItemRegex = '<li><a[^>]*href="/(video/[^"]+)"[^>]*>([^<]+)</a></li>'
        self.folderItemRegex = '<div class="load-more-bar"><a href="#([^"]+)" data-next-page="([^"]+)" data-format="([^"]+)" data-season="([^"]+)" data-station="([^"]+)">'
        self.videoItemRegex = '<div[^>]*class="block preview"[^>]*>([\w\W]{0,2000}?)<!--%/.block-->'
        self.mediaUrlRegex = '<object id=@"myExperience[\w\W]+?playerKey@" value=@"([^@]+)[\w\W]{0,1000}?videoPlayer@" value=@"(\d+)@"'.replace("@", "\\\\")

        #===============================================================================================================
        # non standard items

        #===============================================================================================================
        # Test cases:
        #  Piets Weer: no clips
        #  Wegmisbruikers: episodes and clips and both pages
        #  Utopia: no clips

        # ====================================== Actual channel setup STOPS here =======================================
        return

    def PreProcessFolderList(self, data):
        """Performs pre-process actions for data processing/

        Arguments:
        data : string - the retrieve data that was loaded for the current item and URL.

        Returns:
        A tuple of the data and a list of MediaItems that were generated.


        Accepts an data from the ProcessFolderList method, BEFORE the items are
        processed. Allows setting of parameters (like title etc) for the channel.
        Inside this method the <data> could be changed and additional items can
        be created.

        The return values should always be instantiated in at least ("", []).

        """

        Logger.Info("Performing Pre-Processing")
        items = []

        start = data.find("<!-- episodes - start -->")
        clipstart = data.find("<!-- clips - start -->")
        if start < 0 and clipstart < 0:
            # it was an ajax call, use 0
            Logger.Debug("Ajax call found")
            resultData = data
        else:
            resultData = ""
            start = 0
            end = 0
            # do the episodes
            while start >= 0:
                # find an episode section
                start = data.find("<!-- episodes - start -->", end)
                end = data.find("<!-- episodes - end -->", start)
                if start < 0 or end < 0:
                    Logger.Info("No Episodes found in data")
                    break
                Logger.Debug("Found Episode part from %s to %s", start, end)
                resultData += data[start:end]

            # then the clips
            start = 0
            end = 0
            while start >= 0:
                start = data.find("<!-- clips - start -->", end)
                end = data.find("<!-- clips - end -->", start)
                if start < 0 or end < 0:
                    Logger.Info("No Clips found.")
                    break
                Logger.Debug("Found Clips part from %s to %s. Getting 'more' part", start, end)
                resultData += data[start:end]

                # start = data.find("<!-- load more - start -->", end)
                # end = data.find("<!-- load more - end -->", end)
                # if start > 0 and end > 0:
                #     Logger.Debug("More section found for clips.")
                #     resultData += data[start:end]
            # Logger.Trace(resultData)

        Logger.Debug("Pre-Processing finished")
        return resultData, items

    def CreateEpisodeItem(self, resultSet):
        """Creates a new MediaItem for an episode

        Arguments:
        resultSet : list[string] - the resultSet of the self.episodeItemRegex

        Returns:
        A new MediaItem of type 'folder'

        This method creates a new MediaItem from the Regular Expression
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        """

        Logger.Trace(resultSet)

        # if "utopia" in resultSet[1].lower():
        #     return Noneif "utopia" in resultSet[1].lower():
        #     return None

        if not "http://" in resultSet[0]:
            url = "%s/%s" % (self.baseUrl, resultSet[0])
        else:
            url = resultSet[0]
        item = mediaitem.MediaItem(resultSet[1], url)
        # item.thumb = urlparse.urljoin(self.baseUrl, resultSet['thumb'])
        item.complete = True

        return item

    def CreateFolderItem(self, resultSet):
        """Creates a MediaItem of type 'folder' using the resultSet from the regex.

        Arguments:
        resultSet : tuple(strig) - the resultSet of the self.folderItemRegex

        Returns:
        A new MediaItem of type 'folder'

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        """

        Logger.Trace(resultSet)

        # http://www.kijk.nl/ajax/qw/moreepisodes?format=wegmisbruikers&page=1&season=0&station=sbs6
        url = "http://www.kijk.nl/ajax/qw/%s?page=%s&format=%s&season=%s&station=%s" % resultSet
        Logger.Trace(url)

        if "clips" in resultSet[0]:
            title = "Meer clips"
        else:
            title = "Meer afleveringen"

        item = mediaitem.MediaItem(title, url)
        item.thumb = self.noImage
        item.icon = self.icon
        item.type = 'folder'
        item.complete = True
        return item

    def CreateVideoItem(self, resultSet):
        """Creates a MediaItem of type 'video' using the resultSet from the regex.

        Arguments:
        resultSet : tuple (string) - the resultSet of the self.videoItemRegex

        Returns:
        A new MediaItem of type 'video' or 'audio' (despite the method's name)

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        If the item is completely processed an no further data needs to be fetched
        the self.complete property should be set to True. If not set to True, the
        self.UpdateVideoItem method is called if the item is focussed or selected
        for playback.

        """

        # Logger.Trace(resultSet)

        html = HtmlHelper(resultSet)
        image = html.GetTagAttribute("img", {"alt": None}, {"src": None}, firstOnly=False)[0]

        image = image[1]
        if not "http://" in image:
            image = "%s%s" % (self.baseUrl, image)
        Logger.Trace(image)

        title = html.GetTagContent("h4", firstOnly=True)
        Logger.Trace(title)
        subTitle = html.GetTagContent("p", firstOnly=True)
        if subTitle:
            title = "%s - %s" % (title, subTitle)

        url = html.GetTagAttribute("a", {"href": None}, firstOnly=True)
        if not "http://" in url:
            url = "%s%s" % (self.baseUrl, url)
        Logger.Trace(url)

        item = mediaitem.MediaItem(title, url)
        item.type = 'video'
        item.description = subTitle
        item.thumb = image
        item.icon = self.icon

        if not '<time datetime="">' in resultSet[1]:
            dt = html.GetTagAttribute("time", {"datetime": None})
            Logger.Trace(dt)
            year = dt[0:4]
            month = dt[5:7]
            day = dt[8:10]
            hour = dt[11:13]
            minute = dt[14:16]
            seconds = dt[17:19]
            Logger.Trace((dt, year, month, day, hour, minute, seconds))
            item.SetDate(year, month, day, hour, minute, seconds)

        item.complete = False
        return item

    def UpdateVideoItem(self, item):
        """Updates an existing MediaItem with more data.

        Arguments:
        item : MediaItem - the MediaItem that needs to be updated

        Returns:
        The original item with more data added to it's properties.

        Used to update none complete MediaItems (self.complete = False). This
        could include opening the item's URL to fetch more data and then process that
        data or retrieve it's real media-URL.

        The method should at least:
        * cache the thumbnail to disk (use self.noImage if no thumb is available).
        * set at least one MediaItemPart with a single MediaStream.
        * set self.complete = True.

        if the returned item does not have a MediaItemPart then the self.complete flag
        will automatically be set back to False.

        """

        Logger.Debug('Starting UpdateVideoItem for %s (%s)', item.name, self.channelName)

        videoId = item.url[item.url.rfind("/") + 1:]

        url = "http://embed.kijk.nl/?width=868&height=491&video=%s" % (videoId,)
        referer = "http://www.kijk.nl/video/%s" % (videoId,)

        # now the mediaurl is derived. First we try WMV
        data = UriHandler.Open(url, proxy=self.proxy, referer=referer)
        Logger.Trace(self.mediaUrlRegex)
        objectData = Regexer.DoRegex(self.mediaUrlRegex, data)[0]
        Logger.Trace(objectData)

        # seed = "61773bc7479ab4e69a5214f17fd4afd21fe1987a"
        # seed = "0a2b91ec0fdb48c5dd5239d3e796d6f543974c33"
        seed = "0b0234fa8e2435244cdb1603d224bb8a129de5c1"
        amfHelper = BrightCove(Logger.Instance(), objectData[0], objectData[1], url, seed)  # , proxy=ProxyInfo("localhost", 8888)
        item.description = amfHelper.GetDescription()

        part = item.CreateNewEmptyMediaPart()
        for stream, bitrate in amfHelper.GetStreamInfo():
            part.AppendMediaStream(stream.replace("&mp4:", ""), bitrate)

        item.complete = True
        return item
