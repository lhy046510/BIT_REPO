﻿# coding:UTF-8
import mediaitem
import contextmenu
import chn_class
from helpers.datehelper import DateHelper
from logger import Logger
from urihandler import UriHandler
from regexer import Regexer


class Channel(chn_class.Channel):
    """
    main class from which all channels inherit
    """

    def __init__(self, channelInfo):
        """Initialisation of the class.

        Arguments:
        channelInfo: ChannelInfo - The channel info object to base this channel on.

        All class variables should be instantiated here and this method should not
        be overridden by any derived classes.

        """

        chn_class.Channel.__init__(self, channelInfo)

        # ============== Actual channel setup STARTS here and should be overwritten from derived classes ===============
        self.noImage = "patheimage.png"

        # set context menu items
        self.contextMenuItems.append(contextmenu.ContextMenuItem("Download Item", "CtMnDownloadItem", itemTypes="video"))

        # setup the urls
        self.mainListUri = "http://www.pathe.nl/bioscoopagenda"
        self.baseUrl = "http://www.pathe.nl"

        # setup the main parsing data
        self.episodeItemRegex = '<li><a href="(/bioscoopagenda[^"]+)">([^<\n]+)</a></li>'
        self.folderItemRegex = '<a href="(/bioscoopagenda/[^/]+/[^/]+)" rel="nofollow">([^>]+)</a>'
        self.videoItemRegex = '<img src="([^"]+)"[^>]+>\W*</a>\W*<div class="heading">\W*<h3><a href="([^"]+)">([^<]+)(?:\W*<img[^>]+>)?\W*</a>\W*</h3>\W*</div>\W*<p>([^<]+)</p>[\w\W]{0,200}?<table id="schedule([\w\W]{0,2000}?)</table>'
        self.mediaUrlRegex = 'writeMoviePlayer\(\W+"(http[^"]+)'
        self.pageNavigationRegex = '(/web/Uitzending-gemist-5/TV-1/Programmas/Programma.htm\?p=Debuzz&amp;pagenr=)(\d+)[^>]+><span>'
        self.pageNavigationRegexIndex = 1

        # ====================================== Actual channel setup STOPS here =======================================
        return

    def CreateEpisodeItem(self, resultSet):
        """
        Accepts an arraylist of results. It returns an item. 
        """

        item = mediaitem.MediaItem(resultSet[1], "%s%s" % (self.baseUrl, resultSet[0]))
        item.icon = self.icon
        item.thumb = self.noImage
        item.complete = True
        return item
    
    def CreateFolderItem(self, resultSet):
        """Creates a MediaItem of type 'folder' using the resultSet from the regex.
        
        Arguments:
        resultSet : tuple(strig) - the resultSet of the self.folderItemRegex
        
        Returns:
        A new MediaItem of type 'folder'
        
        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes 
        and are specific to the channel.
         
        """

        Logger.Trace(resultSet)

        if self.parentItem.url.endswith(str(DateHelper.ThisYear())):
            return None

        url = "%s%s" % (self.baseUrl, resultSet[0])
        name = resultSet[1]
        
        if name == "Ma":
            name = "Maandag"
        elif name == "Di":
            name = "Dinsdag"
        elif name == "Wo":
            name = "Woensdag"
        elif name == "Do":
            name = "Donderdag"
        elif name == "Vr":
            name = "Vrijdag"
        elif name == "Za":
            name = "Zaterdag"
        elif name == "Zo":
            name = "Zondag"
        
        item = mediaitem.MediaItem(name, url)
        item.thumb = self.noImage
        item.icon = self.icon

        date = DateHelper.GetDateForNextDay(name, ["Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag", "Zondag"], "Morgen")
        item.SetDate(date.year, date.month, date.day)
        
        item.complete = True
        return item
    
    def CreateVideoItem(self, resultSet):
        """Creates a MediaItem of type 'video' using the resultSet from the regex.
        
        Arguments:
        resultSet : tuple (string) - the resultSet of the self.videoItemRegex
        
        Returns:
        A new MediaItem of type 'video' or 'audio' (despite the method's name)
        
        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes 
        and are specific to the channel.
        
        If the item is completely processed an no further data needs to be fetched
        the self.complete property should be set to True. If not set to True, the
        self.UpdateVideoItem method is called if the item is focussed or selected
        for playback.
         
        """

        Logger.Trace(resultSet)
        
        thumbUrl = "%s%s" % (self.baseUrl, resultSet[0])
        thumbUrl = thumbUrl.replace("/thumb/75x100", "")
        url = "%s%s" % (self.baseUrl, resultSet[1])
        name = resultSet[2]
                
        item = mediaitem.MediaItem(name, url)
        item.thumb = thumbUrl
        item.icon = self.icon
        item.type = 'video'
        
        # more description stuff
        description = "%s\n\n" % (resultSet[3],)
        
        timeTable = resultSet[4]
        timeTableRegex = '<th><a href="[^>]+>([^<]+)</a></th>\W*<td>([\w\W]{0,2000}?)</td>'
        for timeTableEntry in Regexer.DoRegex(timeTableRegex, timeTable):
            Logger.Trace(timeTableEntry)
            bios = timeTableEntry[0]
            description = "%s%s: " % (description, bios)
            times = timeTableEntry[1]
            timeRegex = '<a[^>]+>(\d+:\d+)(?:<strong[^>]+>([^<]+)<)?'
            for time in Regexer.DoRegex(timeRegex, times):
                Logger.Trace(time)
                description = "%s %s %s, " % (description, time[0], time[1])

            description = description.strip(', ')
            description = "%s\n" % (description, )

        item.description = description.strip()
        
        item.complete = False        
        return item
    
    def UpdateVideoItem(self, item):
        """
        Accepts an item. It returns an updated item. Usually retrieves the MediaURL 
        and the Thumb! It should return a completed item. 
        """
        Logger.Debug('Starting UpdateVideoItem for %s (%s)', item.name, self.channelName)
        
        data = UriHandler.Open(item.url, proxy=self.proxy)
        videos = Regexer.DoRegex(self.mediaUrlRegex, data)
        
        for video in videos:
            Logger.Trace(video)
            item.AppendSingleStream(video)
        
        item.complete = True
        return item
    
    def CtMnDownloadItem(self, item):
        item = self.DownloadVideoItem(item)
        return item