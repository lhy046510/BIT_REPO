# coding:UTF-8
import string

import mediaitem
import chn_class

from regexer import Regexer
from helpers import subtitlehelper
from helpers import htmlentityhelper
from helpers.jsonhelper import JsonHelper
from helpers.htmlentityhelper import HtmlEntityHelper

from logger import Logger
from streams.m3u8 import M3u8
from urihandler import UriHandler


class Channel(chn_class.Channel):

    def __init__(self, channelInfo):
        """Initialisation of the class.

        Arguments:
        channelInfo: ChannelInfo - The channel info object to base this channel on.

        All class variables should be instantiated here and this method should not
        be overridden by any derived classes.

        """

        chn_class.Channel.__init__(self, channelInfo)

        # ============== Actual channel setup STARTS here and should be overwritten from derived classes ===============
        self.noImage = "tv4image.png"

        # setup the urls
        self.mainListUri = "http://api.tv4play.se/video/tv4play/tablet/program_formats/list.json?premium_filter=all&compact=true&sorttype=alpha&"
        self.baseUrl = "http://www.tv4play.se"
        self.swfUrl = "http://www.tv4play.se/flash/tv4playflashlets.swf"

        # setup the main parsing data
        self.episodeItemRegex = ',"id"[\w\W]{0,2000}?"text":"[^}]+'
        self.videoItemRegex = ',"largeimage"[\w\W]{0,2000}?"vmanprogid":"[^}]+'
        self.folderItemRegex = '(<h2[^<]*><span>([^<]+)</span></h2>[\w\W]{0,20000}?</section>)'

        #===============================================================================================================
        # non standard items

        #===============================================================================================================
        # Test cases:
        #   Batman - WideVine
        #   Antikdeckarna - Clips

        # ====================================== Actual channel setup STOPS here =======================================
        return

    def CreateEpisodeItem(self, resultSet):
        """Creates a new MediaItem for an episode

        Arguments:
        resultSet : list[string] - the resultSet of the self.episodeItemRegex

        Returns:
        A new MediaItem of type 'folder'

        This method creates a new MediaItem from the Regular Expression
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        """

        # http://api.tv4play.se/video/tv4play/tablet/programs/search.json?livepublished=false&video_types=programs&categoryids=1.2729892&sorttype=date&start=0

        json = JsonHelper(resultSet)

        title = json.GetNamedValue("name")
        description = json.GetNamedValue("text")

        programId = json.GetNamedValue("id")
        programId = HtmlEntityHelper.UrlEncode(programId)
        url = "http://api.tv4play.se/video/tv4play/tablet/programs/search.json?livepublished=false&video_types=programs&sorttype=date&start=0&rows=1000&categoryids=%s" % (programId,)

        item = mediaitem.MediaItem(title, url)
        item.description = description
        item.icon = self.icon

        return item

    def PreProcessFolderList(self, data):
        """Performs pre-process actions for data processing/

        Arguments:
        data : string - the retrieve data that was loaded for the current item and URL.

        Returns:
        A tuple of the data and a list of MediaItems that were generated.


        Accepts an data from the ProcessFolderList method, BEFORE the items are
        processed. Allows setting of parameters (like title etc) for the channel.
        Inside this method the <data> could be changed and additional items can
        be created.

        The return values should always be instantiated in at least ("", []).

        """

        Logger.Info("Performing Pre-Processing")
        items = []

        # Add a klip folder
        if "clips" not in self.parentItem.url:
            # get the category ID
            catStart = self.parentItem.url.rfind("categoryids=")
            catId = self.parentItem.url[catStart + 12:]
            Logger.Debug("Currently doing CatId: '%s'", catId)

            # only add clipse if this is not already a clip folder.
            url = "http://api.tv4play.se/video/tv4play/tablet/programs/search.json?" \
                  "video_types=clips&categoryids=%s&sorttype=date&start=0&rows=1000" % (catId,)
            clips = mediaitem.MediaItem("Klipp", url)
            clips.icon = self.icon
            clips.thumb = self.noImage
            clips.complete = True
            items.append(clips)

        # always add a "More" button
#        nextPage = int(self.parentItem.url[startStart+7:]) + 10
#        url = "%s%s" % (self.parentItem.url[:startStart+7], nextPage)
#        more = mediaitem.MediaItem("More", url)
#        more.icon = self.icon
#        more.thumb = self.noImage
#        more.complete = True
#        items.append(more)

        Logger.Debug("Pre-Processing finished")
        return data, items

    def CreateVideoItem(self, resultSet):
        """Creates a MediaItem of type 'video' using the resultSet from the regex.

        Arguments:
        resultSet : tuple (string) - the resultSet of the self.videoItemRegex

        Returns:
        A new MediaItem of type 'video' or 'audio' (despite the method's name)

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        If the item is completely processed an no further data needs to be fetched
        the self.complete property should be set to True. If not set to True, the
        self.UpdateVideoItem method is called if the item is focussed or selected
        for playback.

        """

        Logger.Trace('starting FormatVideoItem for %s', self.channelName)
        # Logger.Debug("Content = %s", resultSet)

        json = JsonHelper(resultSet)

        # the vmanProgramId (like 1019976) leads to http://anytime.tv4.se/webtv/metafileFlash.smil?p=1019976&bw=1000&emulate=true&sl=true
        programId = json.GetNamedValue("vmanprogid")
        # Logger.Debug("ProgId = %s", programId)

        # let's use the mobile streams, as they are still m3u8.
        # url = "http://premium.tv4play.se/api/web/asset/%s/play" % (programId,)
        # url = "http://premium.tv4play.se/api/mobil/asset/%s/play?protocol=hls&videoFormat=MP4+WVM+SMI&" % (programId,)
        # url = "http://premium.tv4play.se/api/mobil/asset/%s/play" % (programId,)
        url = "http://prima.tv4play.se/api/web/asset/%s/play?protocol=hls" % (programId,)
        name = json.GetNamedValue("name")

        item = mediaitem.MediaItem(name, url)
        item.description = json.GetNamedValue("lead")

        date = json.GetNamedValue("publishdate")
        year = date[0:4]
        month = date[4:6]
        day = date[6:8]
        hour = date[8:10]
        minute = date[10:12]
        item.SetDate(year, month, day, hour, minute, 00)

        thumbUrl = json.GetNamedValue("originalimage")
        item.thumb = thumbUrl

        premium = json.GetNamedValue("premium") == "true"
        authorization = json.GetNamedValue("requires_authorization") == "true"
        # premium = '"premium":true' in resultSet
        # authorization = '"requires_authorization":true' in resultSet
        if premium or authorization:
            item.name = "%s [Premium-innehåll]" % (item.name,)

        item.type = "video"
        item.complete = False
        item.icon = self.icon
        return item

    def CreateFolderItem(self, resultSet):
        """Creates a MediaItem of type 'folder' using the resultSet from the regex.

        Arguments:
        resultSet : tuple(strig) - the resultSet of the self.folderItemRegex

        Returns:
        A new MediaItem of type 'folder'

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        """

        folderResults = Regexer.DoRegex('<a href="/search\?(categoryids=\d+.\d{7}&[^"]+)"[^<]*>Visa fler', resultSet[0])
        if len(folderResults) == 0:
            return None
        else:
            queryString = folderResults[0]

        # http://www.tv4play.se/search?categoryids=1.1854778&amp;order=desc&amp;rows=8&amp;sorttype=date&amp;start=<value>

        # http://www.tv4play.se/search?partial=true&rows=5&keyword=&sorttype=date&order=desc&video_types=programs&categoryids=1.1820998&start=5
        # /search?categoryids=1.1820998&amp;keyword=&amp;order=desc&amp;rows=5&amp;sorttype=date&amp;video_types=programs

        # url = "%s/search?partial=true&rows=%s&%s" % (self.baseUrl, 200, htmlentityhelper.HtmlEntityHelper.StripAmp(resultSet[2]))
        # keyword=&sorttype=date&order=desc&video_types=programs&categoryids=%s&start=0" % (self.baseUrl, 200, resultSet[2])

        url = "%s/search?partial=true&%s&start=0&rows=%s" % (self.baseUrl, htmlentityhelper.HtmlEntityHelper.StripAmp(queryString), 200)
        name = resultSet[1]

        item = mediaitem.MediaItem(name, url)
        item.thumb = self.noImage
        item.type = 'folder'
        item.complete = True
        return item

    def UpdateVideoItem(self, item):
        """Updates an existing MediaItem with more data.

        Arguments:
        item : MediaItem - the MediaItem that needs to be updated

        Returns:
        The original item with more data added to it's properties.

        Used to update none complete MediaItems (self.complete = False). This
        could include opening the item's URL to fetch more data and then process that
        data or retrieve it's real media-URL.

        The method should at least:
        * cache the thumbnail to disk (use self.noImage if no thumb is available).
        * set at least one MediaItemPart with a single MediaStream.
        * set self.complete = True.

        if the returned item does not have a MediaItemPart then the self.complete flag
        will automatically be set back to False.

        """

        Logger.Debug('Starting UpdateVideoItem for %s (%s)', item.name, self.channelName)

        # noinspection PyStatementEffect
        """
                C:\temp\rtmpdump-2.3>rtmpdump.exe -z -o test.flv -n "cp70051.edgefcs.net" -a "tv
                4ondemand" -y "mp4:/mp4root/2010-06-02/pid2780626_1019976_T3MP48_.mp4?token=c3Rh
                cnRfdGltZT0yMDEwMDcyNjE2NDYyNiZlbmRfdGltZT0yMDEwMDcyNjE2NDgyNiZkaWdlc3Q9ZjFjN2U1
                NTRiY2U5ODMxMDMwYWQxZWEwNzNhZmUxNjI=" -l 2

                C:\temp\rtmpdump-2.3>rtmpdump.exe -z -o test.flv -r rtmpe://cp70051.edgefcs.net/
                tv4ondemand/mp4root/2010-06-02/pid2780626_1019976_T3MP48_.mp4?token=c3RhcnRfdGlt
                ZT0yMDEwMDcyNjE2NDYyNiZlbmRfdGltZT0yMDEwMDcyNjE2NDgyNiZkaWdlc3Q9ZjFjN2U1NTRiY2U5
                ODMxMDMwYWQxZWEwNzNhZmUxNjI=
                """

        # retrieve the mediaurl
        data = UriHandler.Open(item.url, proxy=self.proxy)

        urlRegex = "<bitrate>(\d+)</bitrate>\W+<mediaFormat>([^<]+)</mediaFormat>\W+(?:<scheme>([^<]+)</scheme>\W+<server>([^<]+)</server>\W+){0,1}<base>([^<]+)</base>\W+<url>([^<]+)</url>"
        # urlRegex = "<bitrate>(\d+)</bitrate>\W+<mediaFormat>([^<]+)</mediaFormat>\W+<scheme>([^<]+)</scheme>\W+<server>([^<]+)</server>\W+<base>([^<]+)</base>\W+<url>([^<]+)</url>"

        item.MediaItemParts = []
        part = item.CreateNewEmptyMediaPart()

        for result in Regexer.DoRegex(urlRegex, data):
            Logger.Trace(result)

            if "smi" in result[1]:
                subTitleUrl = result[5]
                part.Subtitle = subtitlehelper.SubtitleHelper.DownloadSubtitle(subTitleUrl, proxy=self.proxy)
            else:
                if "rtmp" in result[-1]:
                    Logger.Trace("RTMP Stream found")
                    bitrate = result[0]
                    # get the actual path
                    pos = string.find(result[5], '/')
                    path = result[5][pos:]

                    url = "%s%s" % (result[4], path)
                    url = self.GetVerifiableVideoUrl(url)
                    part.AppendMediaStream(url, bitrate)

                elif result[-1].endswith("master.m3u8"):
                    Logger.Trace("M3U8 Stream found")
                    for s, b in M3u8.GetStreamsFromM3u8(result[-1], self.proxy):
                        part.AppendMediaStream(s, b)

                else:
                    Logger.Trace("Other Stream found")
                    bitrate = result[0]
                    url = result[5]
                    part.AppendMediaStream(url, bitrate)

                item.complete = True

        return item
