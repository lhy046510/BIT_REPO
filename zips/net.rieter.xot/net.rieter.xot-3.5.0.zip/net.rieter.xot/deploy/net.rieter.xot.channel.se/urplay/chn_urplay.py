# coding:UTF-8
import urlparse

import mediaitem
import chn_class

from regexer import Regexer
from helpers import subtitlehelper
from logger import Logger
from urihandler import UriHandler
from helpers.jsonhelper import JsonHelper


class Channel(chn_class.Channel):

    def __init__(self, channelInfo):
        """Initialisation of the class.

        Arguments:
        channelInfo: ChannelInfo - The channel info object to base this channel on.

        All class variables should be instantiated here and this method should not
        be overridden by any derived classes.

        """

        chn_class.Channel.__init__(self, channelInfo)

        # ============== Actual channel setup STARTS here and should be overwritten from derived classes ===============
        self.noImage = "urplayimage.png"

        # setup the urls
        self.mainListUri = "http://urplay.se/A-O"
        self.baseUrl = "http://urplay.se"
        self.swfUrl = "http://urplay.se/design/ur/javascript/jwplayer/jwplayer-5.10.swf"


        # setup the main parsing data
        self.episodeItemRegex = '<a[^>]+href="(/Produkter[^"]+)">([^<]+)<span class="product-type \w+">([^<]+)'
        self.videoItemRegex = '<section class="([^"]+)">\W+<a[^>]+title="[^"]+" href="(/Produkter/[^"]+)">[\W\w]{0,200}' \
                              '<img[^>]+src="([^"]+)[\W\w]{0,1000}?<h1>([^<]+)</h1>[\w\W+]{0,500}?' \
                              '<p class="ellipsis-lastline">([^<]+)</p>(?:[\w\W]{0,500}?' \
                              '<time datetime="(\d+)-(\d+)-(\d+)T(\d+):(\d+):(\d+))'
        self.mediaUrlRegex = "urPlayer.init\(([^<]+)\);"
        self.pageNavigationRegex = '<a href="([^"]+page=)(\d+)([^"]+relatedpage=1[^"]+)" title="[^"]+" [^>]+>\d+</a>'
        self.pageNavigationRegexIndex = 1

        #===============================================================================================================
        # non standard items
        self.categoryName = ""
        self.currentUrlPart = ""
        self.currentPageUrlPart = ""

        #===============================================================================================================
        # Test cases:
        #   Anaconda Auf Deutch : RTMP, Subtitles
        #   Kunskapsdokumentar: folders, pages

        # ====================================== Actual channel setup STOPS here =======================================
        return

    def CreateEpisodeItem(self, resultSet):
        """Creates a new MediaItem for an episode

        Arguments:
        resultSet : list[string] - the resultSet of the self.episodeItemRegex

        Returns:
        A new MediaItem of type 'folder'

        This method creates a new MediaItem from the Regular Expression
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        """

        title = "%s (%s)" % (resultSet[1].strip(), resultSet[2])
        item = mediaitem.MediaItem(title, urlparse.urljoin(self.baseUrl, resultSet[0]))
        item.thumb = self.noImage
        item.icon = self.icon
        return item

    def CreateVideoItem(self, resultSet):
        """Creates a MediaItem of type 'video' using the resultSet from the regex.

        Arguments:
        resultSet : tuple (string) - the resultSet of the self.videoItemRegex

        Returns:
        A new MediaItem of type 'video' or 'audio' (despite the method's name)

        This method creates a new MediaItem from the Regular Expression or Json
        results <resultSet>. The method should be implemented by derived classes
        and are specific to the channel.

        If the item is completely processed an no further data needs to be fetched
        the self.complete property should be set to True. If not set to True, the
        self.UpdateVideoItem method is called if the item is focussed or selected
        for playback.

        """

        # Logger.Trace(resultSet)

        itemType = resultSet[0]
        url = "%s%s" % (self.baseUrl, resultSet[1])
        thumbUrl = resultSet[2].replace("_t", "_l")
        title = resultSet[3]
        description = resultSet[4]

        if "radio" in itemType:
            title = "%s (Audio Only)" % (title,)
            mediaType = "audio"
        else:
            mediaType = "video"

        item = mediaitem.MediaItem(title, url)
        item.description = description
        item.thumb = thumbUrl
        item.type = mediaType
        item.icon = self.icon

        if resultSet[5]:
            item.SetDate(resultSet[5], resultSet[6], resultSet[7],
                         resultSet[8], resultSet[9], resultSet[10])

        item.complete = False
        return item

    def UpdateVideoItem(self, item):
        """Updates an existing MediaItem with more data.

        Arguments:
        item : MediaItem - the MediaItem that needs to be updated

        Returns:
        The original item with more data added to it's properties.

        Used to update none complete MediaItems (self.complete = False). This
        could include opening the item's URL to fetch more data and then process that
        data or retrieve it's real media-URL.

        The method should at least:
        * cache the thumbnail to disk (use self.noImage if no thumb is available).
        * set at least one MediaItemPart with a single MediaStream.
        * set self.complete = True.

        if the returned item does not have a MediaItemPart then the self.complete flag
        will automatically be set back to False.

        """

        Logger.Debug('Starting UpdateVideoItem for %s (%s)', item.name, self.channelName)

        # noinspection PyStatementEffect
        """
        <script type="text/javascript">/* <![CDATA[ */ var movieFlashVars = "
        image=http://assets.ur.se/id/147834/images/1_l.jpg
        file=/147000-147999/147834-20.mp4
        plugins=http://urplay.se/jwplayer/plugins/gapro-1.swf,http://urplay.se/jwplayer/plugins/sharing-2.swf,http://urplay.se/jwplayer/plugins/captions/captions.swf
        sharing.link=http://urplay.se/147834
        gapro.accountid=UA-12814852-8
        captions.margin=40
        captions.fontsize=11
        captions.back=false
        captions.file=http://undertexter.ur.se/147000-147999/147834-19.tt
        streamer=rtmp://streaming.ur.se/ondemand
        autostart=False"; var htmlVideoElementSource = "http://streaming.ur.se/ondemand/mp4:147834-23.mp4/playlist.m3u8?location=SE"; /* //]]> */ </script>

        """

        # get the server IP
        # data = UriHandler.Open("http://130.242.59.74/loadbalancer.json?callback=jQuery", proxy=self.proxy)
        # json = JsonHelper(data, Logger.Instance())
        # ip = json.GetValue("redirect")
        # Logger.Trace(ip)

        data = UriHandler.Open(item.url, proxy=self.proxy)
        streams = Regexer.DoRegex(self.mediaUrlRegex, data)
        jsonData = streams[0]
        json = JsonHelper(jsonData)
        Logger.Trace(json.GetJsonData())

        item.MediaItemParts = []
        part = item.CreateNewEmptyMediaPart()

        streams = {"file_flash": 900,
                   "file_mobile": 750,
                   "file_hd": 2000,
                   "file_html5": 850,
                   "file_html5_hd": 2400}

        proxy = json.GetValue("streaming_config", "streamer", "redirect")
        Logger.Trace("Found RTMP Proxy: %s", proxy)
        rtmpApplication = json.GetValue("streaming_config", "rtmp", "application")
        Logger.Trace("Found RTMP Application: %s", rtmpApplication)

        for streamType in streams:
            #onlySweden = False
            bitrate = streams[streamType]
            streamUrl = json.GetValue(streamType)
            if not streamUrl:
                Logger.Debug("%s was not found as stream.", streamType)
                continue

            if streamUrl.startswith("se/") or ":se/" in streamUrl:  # or json.GetValue("only_in_sweden"): -> will be in the future
                onlySweden = True
                Logger.Warning("Streams are only available in Sweden: onlySweden=%s", onlySweden)
                # No need to replace the se/ part. Just log.
                # streamUrl = streamUrl.replace("se/", "", 1)

            if "_definst_" in streamUrl:
                url = "rtmp://%s/%s" % (proxy, streamUrl)
            else:
                url = "rtmp://%s/%s/_definst_/mp4:%s" % (proxy, rtmpApplication, streamUrl)

            url = self.GetVerifiableVideoUrl(url)
            part.AppendMediaStream(url.strip("/"), bitrate)

        captions = json.GetValue("subtitles")
        captionLabels = json.GetValue("subtitle_labels")
        Logger.Trace(captions)
        if not captions == "":
            # we need to handle multiple subtitles
            captions = captions.split(",")
            captionLabels = captionLabels.split(",")
            Logger.Debug("Found subtitle languages: %s", captionLabels)
            swedishIndex = 0
            if captionLabels.count("Svenska") > 0:
                swedishIndex = captionLabels.index("Svenska")
            Logger.Debug("Selected subtitle language: %s", captionLabels[swedishIndex])
            caption = captions[swedishIndex]

            fileName = caption[caption.rindex("/") + 1:] + ".srt"
            subtitle = subtitlehelper.SubtitleHelper.DownloadSubtitle(caption, fileName, "ttml", proxy=self.proxy)
        else:
            subtitle = None
        part.Subtitle = subtitle

        item.complete = True
        return item
