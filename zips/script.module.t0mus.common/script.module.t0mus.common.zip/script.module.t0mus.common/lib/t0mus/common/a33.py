#!/usr/bin/python
# -*- coding: utf-8 -*-

#######################################
#                                     #
# script.module.t0mus.common for xbmc #
# author: t0mus                       #
#                                     #
#######################################

"""Url extractor for a33 host."""


def extract_urls(soup):
    """Return list of urls."""

    urls = []
    try:
        for cat in soup.find('div', attrs={'id': 'footer'
                             }).findAll('script'):
            content = cat.string
            if content != None:
                clips = content.split('clip:')
                first = True
                for clip in clips:
                    if not first:
                        urls.append(clip.split("url: '")[1].split("'"
                                    )[0])
                    first = False
    except AttributeError:
        pass
    return urls


