#       Copyright (C) 2012 
#       Written on behalf of TVCatchup
#       by Chris Grove (tvc@killergerbils.co.uk)
#       and Sean Poyser (seanpoyser@gmail.com)
#

import xbmc
import xbmcgui
import xbmcaddon
import os
import time
from datetime import datetime

import buggalo

import source

from notification import Notification
from source       import Program
from source       import Channel
from sqlite3      import dbapi2 as sqlite3

KEY_NAV_BACK = 92
KEY_ESC_ID   = 10
KEY_ESC_CODE = 61467

ACTION_BACK          = 92
ACTION_PARENT_DIR    = 9
ACTION_PREVIOUS_MENU = 10
ACTION_I             = 11

ADDON = xbmcaddon.Addon(id = 'script.tvcatchup')

THEME = ADDON.getSetting('skin')

xmlfile = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')), 'resources', 'skins',  'Default', '720p', THEME + '-script-tvcatchup-info.xml')
if not os.path.exists(xmlfile):
    PREFIX = ""
else:
    PREFIX = THEME + '-'

class InfoWindow(xbmcgui.WindowXMLDialog):
    C_INFO_CANCEL = 4201
    C_INFO_PROGRAM_NAME = 4202
    C_INFO_PROGRAM_DESC = 4203
    C_INFO_CAST_LABEL = 4204
    C_INFO_CAST_LIST = 4205
    C_INFO_STARRATE = 4206
    C_INFO_STARTS = 4207
    C_INFO_SYNOPSIS = 4208
    C_INFO_ENDS = 4209
    C_INFO_GENRE = 4210
    C_INFO_RUNNINGTIME = 4212
    C_INFO_PREMIERE = 4213
    C_INFO_BLACKNWHITE = 4214
    C_INFO_DEAFSIGNED = 4215
    C_INFO_FILM = 4216
    C_INFO_NEWSERIES = 4217
    C_INFO_REPEAT = 4218
    C_INFO_SUBTITLES = 4219
    C_INFO_WIDESCREEN = 4220
    C_INFO_CHANNELLOGO = 4221
    C_INFO_EPISODE = 4223
    C_INFO_YEAR = 4224

    def __new__(cls, programID):
        return super(InfoWindow, cls).__new__(cls, PREFIX + 'script-tvcatchup-info.xml', ADDON.getAddonInfo('path'))
        
    def __init__(self, programID):
        super(InfoWindow, self).__init__()
        self.buttonClicked = None
        self.programID     = programID

        ADDON       = xbmcaddon.Addon(id = 'script.tvcatchup')
        path        = xbmc.translatePath(ADDON.getAddonInfo('profile'))    
        KEY         = 'xmltv'
        SOURCE_DB   = 'guide1.db'       
        self.notify = Notification()   

        ATV2       = xbmc.getCondVisibility("System.Platform.ATV2") == 1
        IOS        = xbmc.getCondVisibility("System.Platform.IOS")  == 1
        self.touch = IOS and not ATV2      

        if ADDON.getSetting('force_touch') == 'true':
            self.touch = True

        self.conn             = sqlite3.connect(os.path.join(path, SOURCE_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False)
        self.conn.row_factory = sqlite3.Row 
        
    def onInit(self):
        try:
            c = self.conn.cursor()
            c.execute('SELECT * FROM programs WHERE id=? LIMIT 1', [self.programID])
            row = c.fetchone()
            c.close()
            if row:
                channelID   = row["channel"]
                title       = row["title"]
                startDate   = row["startDate"]
                endDate     = row["endDate"]
                description = row["description"]
                episode     = row["episode"]
                subtitle    = row["subtitle"]
                year        = row["year"]
                director    = row["director"]
                cast        = row["cast"]
                premiere    = row["premiere"]   == 1
                film        = row["film"]       == 1
                repeat      = row["repeat"]     == 1
                subtitles   = row["subtitles"]  == 1
                widescreen  = row["widescreen"] == 1
                newSeries   = row["newSeries"]  == 1
                deaf        = row["deaf"]       == 1
                baw         = row["baw"]        == 1
                genre       = row["genre"]

            channel      = Channel(channelID, '')
            program      = Program(self.programID, channel, title, startDate, endDate, description, episode, genre)
            notification = self.notify.isNotificationRequiredForProgram(program)

            cancelControl = self.getControl(self.C_INFO_CANCEL)
            programName   = self.getControl(self.C_INFO_PROGRAM_NAME)
            programDesc   = self.getControl(self.C_INFO_PROGRAM_DESC)
            castLabel     = self.getControl(self.C_INFO_CAST_LABEL)
            castList      = self.getControl(self.C_INFO_CAST_LIST)
            starRating    = self.getControl(self.C_INFO_STARRATE)
            startStarts   = self.getControl(self.C_INFO_STARTS)
            Synopsis      = self.getControl(self.C_INFO_SYNOPSIS)
            endEnded      = self.getControl(self.C_INFO_ENDS)
            Genre         = self.getControl(self.C_INFO_GENRE)
            runningTime   = self.getControl(self.C_INFO_RUNNINGTIME)
            Premiere      = self.getControl(self.C_INFO_PREMIERE)
            BlackandWhite = self.getControl(self.C_INFO_BLACKNWHITE)
            DeafandSigned = self.getControl(self.C_INFO_DEAFSIGNED)
            Film          = self.getControl(self.C_INFO_FILM)
            NewSeries     = self.getControl(self.C_INFO_NEWSERIES)
            Repeat        = self.getControl(self.C_INFO_REPEAT)
            Subtitles     = self.getControl(self.C_INFO_SUBTITLES)
            Widescreen    = self.getControl(self.C_INFO_WIDESCREEN)
            ChannelLogo   = self.getControl(self.C_INFO_CHANNELLOGO)
            Episode       = self.getControl(self.C_INFO_EPISODE)
            Year          = self.getControl(self.C_INFO_YEAR)
                   
            programName.setLabel('[B]%s[/B]' % title)

            if description =='':
                Synopsis.setLabel('No Synopsis Available')
            else:
                programDesc.setText(description)

            if cast == '[]':
                castLabel.setLabel('Cast not Available')
            else:
                castList.setText(cast.replace("['","").replace("', '","\n").replace("']","").replace(', "',"\n").replace('"','').replace("'\n","\n").replace(", '","\n"))


            strStart = self.getHM(startDate)
            strEnd   = self.getHM(endDate)

            if self.isOnNow(program):
                startStarts.setLabel('Started At: %s' % strStart)
            else:
                startStarts.setLabel('Starts At: %s' % strStart)

            if self.alreadyAired(program):
                startStarts.setLabel('Started At: %s' % strStart)
                endEnded.setLabel('Ended At: %s' % strEnd)
            else:
                endEnded.setLabel('Ends At: %s' % strEnd)
            
            Genre.setLabel('Genre: %s' % genre)                       

            SeriesEpisode = episode.split(',')
            if len(episode) > 0:
                if SeriesEpisode[0] <> "(''":
                    season = SeriesEpisode[0].replace("'","").replace("(","")
                    season = int(season)+1
                    eps     = SeriesEpisode[1].replace("'","").split('/')                    
                    try:
                        epNum   = int(eps[0]) + 1
                        epTotal = int(eps[1])
                        Episode.setLabel('Season: %s Episode: %s of %s' % (str(season), str(epNum), str(epTotal)))
                    except:
                        Episode.setLabel('Season: %s' % str(season))
                    if year <> "":
                        Year.setLabel('Year: %s' % year)            
                else:
                    Episode.setLabel('Episode: %s' % SeriesEpisode[1].replace("'","").replace("/"," of "))
                    if year <> "":
                        Year.setLabel('Year: %s' % year)
            else:
                if year <> "":
                    Episode.setLabel('Year: %s' % year)
            
            StartTime = self.getWhen(startDate.encode('utf-8', 'replace'))
            EndTime   = self.getWhen(endDate.encode('utf-8', 'replace'))
            duration  = int(EndTime - StartTime) / 60
            runningTime.setLabel('Running Time: %s Minutes' % str(duration))
            
            if premiere == 1:
                Premiere.setColorDiffuse('FFFFFFFF')
            if film == 1:
                Film.setColorDiffuse('FFFFFFFF')
            if repeat == 1:
                Repeat.setColorDiffuse('FFFFFFFF')
            if subtitles == 1:
                Subtitles.setColorDiffuse('FFFFFFFF')
            if widescreen == 1:
                Widescreen.setColorDiffuse('FFFFFFFF')
            if newSeries == 1:
                NewSeries.setColorDiffuse('FFFFFFFF')
            if deaf == 1:
                DeafandSigned.setColorDiffuse('FFFFFFFF')
            if baw == 1:
                BlackandWhite.setColorDiffuse('FFFFFFFF')
            ChannelLogo.setImage(program.channel.logo)


            #rating ='4'
            #if rating == '1':
            #    starRating.setImage('onestar.png')
            #    starRating.setWidth(32)
            #elif rating == '2':
            #    starRating.setImage('twostar.png')
            #    starRating.setWidth(64)
            #elif rating == '3':
            #    starRating.setImage('threestar.png')
            #    starRating.setWidth(96)
            #elif rating == '4':
            #    starRating.setImage('fourstar.png')
            #    starRating.setWidth(128)

        except Exception:
            buggalo.onExceptionRaised()


    def getHM(self, when):
        when = when.split(' ')[1].split(':')
        return when[0] + ':' + when[1]


    def getWhen(self, when):
        dt = when.split(' ')
        d  = dt[0]
        t  = dt[1]
        ds = d.split('-')
        ts = t.split(':')
        return time.mktime((int(ds[0]), int(ds[1]) ,int(ds[2]), int(ts[0]), int(ts[1]), int(ts[2]), 0, 0, 0))


    def isOnNow(self, program):
        now   = datetime.today()
        start = program.startDate
        end   = program.endDate

        return now >= start and now < end

    def alreadyAired(self, program):
        now   = datetime.today()
        start = program.startDate
        end   = program.endDate

        return now >= start and now > end

    def setControlText(self, controlId, text):
        control = self.getControl(controlId)
        if control:
            control.setText(text)

    def onAction(self, action):
        try:
            if action.getId() in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, KEY_NAV_BACK, ACTION_BACK, KEY_ESC_ID, ACTION_I]:
                self.close()
                return
        except Exception:
            buggalo.onExceptionRaised()

    def onClick(self, controlId):
        try:            
            self.buttonClicked = controlId
            self.close()
        except Exception:
            buggalo.onExceptionRaised()

    def onFocus(self, controlId):
        pass    
   

#if __name__ == '__main__':
#    infowindow = InfoWindow()
#    infowindow.doModal()     
#    del infowindow
