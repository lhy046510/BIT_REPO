#       Copyright (C) 2012 
#       Written on behalf of TVCatchup
#       by Chris Grove (tvc@killergerbils.co.uk)
#       and Sean Poyser (seanpoyser@gmail.com)
#

import xbmc
import xbmcgui
import xbmcaddon
import TVC

from threading import Timer 
from source import Channel

from player import TVCPlayer
import os

KEY_ESC_ID   = 10
KEY_ESC_CODE = 61467

ACTION_0 = 58
ACTION_1 = 59
ACTION_2 = 60
ACTION_3 = 61
ACTION_4 = 61
ACTION_5 = 63
ACTION_6 = 64
ACTION_7 = 65
ACTION_8 = 66
ACTION_9 = 67

#ACTION_LEFT  = 1
#ACTION_RIGHT = 2
ACTION_UP        = 3
ACTION_DOWN      = 4
ACTION_PAGE_UP   = 5
ACTION_PAGE_DOWN = 6

ACTION_BACK  = 92
ACTION_STOP  = 122

ACTION_X          = 13
ACTION_PARENT_DIR = 9

ACTION_PLAY   = 79
ACTION_SELECT = 7

ADDON = xbmcaddon.Addon(id = 'script.tvcatchup')
THEME = ADDON.getSetting('skin')

xmlfile = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')), 'resources', 'skins',  'Default', '720p', THEME + '-script-tvcatchup-channel.xml')
if not os.path.exists(xmlfile):
    PREFIX = ''
else:
    PREFIX = THEME + '-'

class ChannelChanger(xbmcgui.WindowXMLDialog):
    C_CHANNEL = 6000
    C_TITLE   = 6001
    C_LOGO    = 6002

    def __new__(cls, channel):
        return super(ChannelChanger, cls).__new__(cls, PREFIX + 'script-tvcatchup-channel.xml', xbmcaddon.Addon(id = 'script.tvcatchup').getAddonInfo('path'))

    def __init__(self, channel):
        super(ChannelChanger, self).__init__()

        self.channel    = channel
        self.closeTimer = None
        self.list       = None


    def close(self):         
        if self.closeTimer != None:
            self.closeTimer.cancel()
            #del self.closeTimer

        self.setChannel('')             

        xbmcgui.WindowXMLDialog.close(self) 


    def resetCloseTimer(self):
        if self.closeTimer != None:
            self.closeTimer.cancel()
            
        self.closeTimer = Timer(30, self.onCloseTimer)
        self.closeTimer.start()


    def onCloseTimer(self):
        if self.closeTimer == None:
            return

        self.close()


    def setChannel(self, text):
        channel = self.getControl(self.C_CHANNEL)
        if channel:
            channel.setLabel(text)

        id = self.getID(text)

        title = self.getControl(self.C_TITLE)
        if title:
            if id > -1:
                name = TVC.GetChannelTitle(str(id))
                title.setLabel(name)
            else:
                title.setLabel('')

        logo = self.getControl(self.C_LOGO)
        if logo:
            if id > -1:
                path = os.path.join(self.logoPath, 'channel_' + str(id) + '.png')
                logo.setVisible(True)
                logo.setImage(path)
            else:
                logo.setVisible(False)


    def playChannel(self, channel):
        id = self.getID(channel)
        if id > -1:
            id   = str(id)
            name = TVC.GetChannelTitle(id)
            TVCPlayer().playStream(Channel(id, name), True) 
            self.close()  
            return

        #not found    


    def getID(self, channel):
        if self.list == None:
            ADDON     = xbmcaddon.Addon(id = 'script.tvcatchup')
            self.list = dict()
            index     = 1

            while index < 150:
                find  = 'c' + str(index)
                id    = ADDON.getSetting(find)
                if id:                
                    self.list[id] = index
                index = index + 1          

        try:
            channel = str(int(channel))
            id = self.list[channel]
        except:
            return -1

        return id


    def onInit(self):
        try:            
            self.logoPath = os.path.join(xbmc.translatePath(xbmcaddon.Addon(id = 'script.tvcatchup').getAddonInfo('profile')),'long_logos')
            self.setChannel(self.channel)
            self.resetCloseTimer()
 
        except Exception:
            raise


    def onAction(self, action):
        try:
            xbmc.log("[script.tvcatchup] ************* channel_changer.py onAction *********************", xbmc.LOGDEBUG)
            xbmc.log("[script.tvcatchup] " + str(action.getId()),         xbmc.LOGDEBUG)
            xbmc.log("[script.tvcatchup] " + str(action.getButtonCode()), xbmc.LOGDEBUG)

            actionId = action.getId()
            buttonId = action.getButtonCode()            

            self.resetCloseTimer()        

            if actionId == KEY_ESC_ID and buttonId == KEY_ESC_CODE:
                self.close()
                return

            if actionId == ACTION_BACK: 
                if self.channel == '':
                    self.close()
                    return
                self.channel = self.channel[:-1]
                self.setChannel(self.channel)

            if actionId in [ACTION_UP, ACTION_PAGE_UP]:
                self.ChannelUp()

            if actionId in [ACTION_DOWN, ACTION_PAGE_DOWN]:
                self.ChannelDown();

            if actionId == ACTION_X or actionId == ACTION_STOP:
                self.close()
                return

            if actionId == ACTION_PLAY or actionId == ACTION_SELECT:
                self.playChannel(self.channel)
                return                   

            if actionId >= ACTION_0 and actionId <= ACTION_9:
                self.channel = self.channel + str(actionId - ACTION_0)

            try:
                self.channel = self.channel[-3:]
                if int(self.channel) < 0:
                    self.channel = '999'
            except:
                 pass

            self.setChannel(self.channel)
          
        except Exception:
            raise

    def ChannelUp(self):
        if self.channel == '':
            self.channel = '0'
        
        #prevent wrapping
        #if self.channel == '999':
        #    self.channel = '998'

        ch = int(self.channel) + 1
        ch = self.FindNearestAbove(ch)

        self.channel = str(ch)


    def ChannelDown(self):
        if self.channel == '':
            self.channel = '1000'

        #prevent wrapping
        #if self.channel == '1':
        #    self.channel = '2'

        ch = int(self.channel) - 1        
        ch = self.FindNearestBelow(ch)

        self.channel = str(ch)


    def FindNearestAbove(self, ch):
        id = -1
        ch = ch - 1

        while id < 0:
            ch = ch + 1
            if ch == 1000:
                ch = 1
            id = self.getID(ch)            

        return ch


    def FindNearestBelow(self, ch):
        id = -1
        ch = ch + 1

        while id < 0:
            ch = ch - 1
            if ch == 0:
                ch = 999
            id = self.getID(ch)            

        return ch


if __name__ == '__main__':
    channel = ChannelChanger('')
    channel.doModal()     
    del channel
