#
#      Copyright (C) 2012 Tommy Winther
#      http://tommy.winther.nu
#
#      Modified on behalf of TVCatchup
#      by Chris Grove (tvc@killergerbils.co.uk)
#      and Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import os
import datetime
import time
import random

import xbmc
import xbmcgui

import source
import notification

from strings import *
import buggalo

from threading import Timer 

from player import TVCPlayer
from help import HelpMenu
from info import InfoWindow

import dialogue
import program_list

import favourite

ACTION_LEFT = 1
ACTION_RIGHT = 2
ACTION_UP = 3
ACTION_DOWN = 4
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6
ACTION_SELECT_ITEM = 7
ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10
ACTION_SHOW_INFO = 11
ACTION_NEXT_ITEM = 14
ACTION_PREV_ITEM = 15
ACTION_TOUCH_MOVE = 225
ACTION_BACK = 92
ACTION_PLAY = 79

MOUSE_CLICK       = 100
MOUSE_WHEEL_UP    = 104
MOUSE_WHEEL_DOWN  = 105
ACTION_MOUSE_MOVE = 107

KEY_NAV_BACK = 92
KEY_CONTEXT_MENU = 117

KEY_HOME = 159
ACTION_HOME = -1

KEY_ESC_ID   = 10
KEY_ESC_CODE = 61467

KEY_F = 61510
KEY_G = 61511
KEY_H = 61512
KEY_I = 61513
KEY_L = 61516
KEY_M = 61517
KEY_N = 61518
KEY_R = 61522
KEY_T = 61524

global INIT
INIT = False

CHANNELS_PER_PAGE = 9

CELL_HEIGHT         = 50
CELL_WIDTH_CHANNELS = 164

HALF_HOUR = datetime.timedelta(minutes = 30)

ADDON = xbmcaddon.Addon(id = 'script.tvcatchup')
THEME = ADDON.getSetting('skin')

xmlfile = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')), 'resources', 'skins',  'Default', '720p', THEME + '-script-tvcatchup-main.xml')
if not os.path.exists(xmlfile):
    PREFIX = ""
else:
    PREFIX = THEME + '-'
    
TEXTURE_BUTTON_NOFOCUS         = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')), 'resources', 'skins',  'Default', 'media', PREFIX + 'tvcatchup-normal-program.png')
TEXTURE_BUTTON_FOCUS           = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')), 'resources', 'skins',  'Default', 'media', PREFIX + 'tvcatchup-normal-program-focus.png')
TEXTURE_BUTTON_NOFOCUS_NOTIFY  = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')), 'resources', 'skins',  'Default', 'media', PREFIX + 'tvcatchup-reminder.png')
TEXTURE_BUTTON_FOCUS_NOTIFY    = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')), 'resources', 'skins',  'Default', 'media', PREFIX + 'tvcatchup-reminder-focus.png')
TEXTURE_BUTTON_NOFOCUS_SHOWING = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')), 'resources', 'skins',  'Default', 'media', PREFIX + 'tvcatchup-current-showing.png')
TEXTURE_BUTTON_FOCUS_SHOWING   = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')), 'resources', 'skins',  'Default', 'media', PREFIX + 'tvcatchup-current-showing-focus.png')


class TVGuide(xbmcgui.WindowXML):
    C_MAIN_TITLE       = 4020
    C_MAIN_TIME        = 4021
    C_MAIN_DESCRIPTION = 4022
    C_MAIN_IMAGE       = 4023
    C_MAIN_LOGO        = 4024
    C_MAIN_THUMB       = 4025
    C_MAIN_DATE        = 4000
    
    C_MAIN_LOADING          = 4200
    C_MAIN_LOADING_PROGRESS = 4201

    C_MAIN_MOUSE_CONTROLS = 4300
    C_MAIN_MOUSE_HOME     = 4301
    C_MAIN_MOUSE_LEFT     = 4302
    C_MAIN_MOUSE_UP       = 4303
    C_MAIN_MOUSE_DOWN     = 4304
    C_MAIN_MOUSE_RIGHT    = 4305
    C_MAIN_MOUSE_EXIT     = 4306
    C_MAIN_MOUSE_ZOOM_IN  = 4307
    C_MAIN_MOUSE_ZOOM_OUT = 4308

    C_MAIN_BACKGROUND = 4600
    C_MAIN_EPG = 5000

    def __new__(cls):
        return super(TVGuide, cls).__new__(cls, PREFIX + 'script-tvcatchup-main.xml', ADDON.getAddonInfo('path'))

    def __init__(self):        
        super(TVGuide, self).__init__()
        self.source              = source.XMLTVSource()
        self.notification        = notification.Notification()
        self.controlToProgramMap = dict()
        self.controlStore        = list()
        self.focusX     = 0
        self.page       = 0
        self.prevCtrl   = -1   
        self.mouseCount = 0
        self.program    = None
        self.firstTime  = True

        self.fetchTime     =  1
        self.fetchChannel  = -1
        self.fetchInterval = -1

        self.clearProgramCache()

        self.ATV2  = xbmc.getCondVisibility("System.Platform.ATV2") == 1
        self.IOS   = xbmc.getCondVisibility("System.Platform.IOS")  == 1
        self.touch = self.IOS and not self.ATV2

        xbmc.log("[script.tvcatchup] **********************************",    xbmc.LOGDEBUG)
        xbmc.log("[script.tvcatchup] System.Platform.ATV2 = %s" % self.ATV2, xbmc.LOGDEBUG)
        xbmc.log("[script.tvcatchup] System.Platform.IOS  = %s" % self.IOS,  xbmc.LOGDEBUG) 

        if ADDON.getSetting('force_touch') == 'true':
            self.touch = True
                
        #add and removeControls were added post-eden
        self.hasAddControls    = hasattr(self, 'addControls')
        self.hasRemoveControls = hasattr(self, 'removeControls')       

        self.showMouseCtrl = self.touch or ADDON.getSetting('mouse_control') == 'true'
       
        #find nearest half hour
        self.viewStartDate = datetime.datetime.today()
        self.viewStartDate -= datetime.timedelta(minutes = self.viewStartDate.minute % 30)  


    def onInit(self):
        try:
            self._hideControl(self.C_MAIN_MOUSE_CONTROLS)
            self._showControl(self.C_MAIN_EPG)           

            self.setControlImage(self.C_MAIN_IMAGE, PREFIX + 'tvcatchup-logo.png')

            self.range = -1
            self.setRange(int(ADDON.getSetting('range')))
        except Exception:
            buggalo.onExceptionRaised()

        try:
            self.m = Timer(1, self.onMouseTimer)
            self.m.start()
        except:
            pass

        try:
            self.thumb = Timer(999, self.onThumbTimer)
            #self.i.start()
        except:
            pass

        try:
            self.t = Timer(5*60, self.onTimer)
            self.t.start()
        except:
            pass

        global INIT
        INIT = True

        self.onRedrawEPG(self.page, self.viewStartDate, autoChangeFocus = True, showLoading = True)

              
    def close(self):
        self.stopMouseTimer()
        self.stopTimer()
        self.stopFetchTimer()
        self.stopThumbTimer()

        try:
            del self.m
            del self.t
            del self.f
            del self.i
        except:
            pass
    
        xbmcgui.WindowXML.close(self)          
        
    def onMouseTimer(self):
        try:        
            id = 0 if self.touch else self.getFocus().getId()
            if id in[self.C_MAIN_MOUSE_CONTROLS, self.C_MAIN_MOUSE_HOME, self.C_MAIN_MOUSE_LEFT, self.C_MAIN_MOUSE_UP,  self.C_MAIN_MOUSE_DOWN, self.C_MAIN_MOUSE_RIGHT, self.C_MAIN_MOUSE_EXIT, self.C_MAIN_MOUSE_ZOOM_IN,  self.C_MAIN_MOUSE_ZOOM_OUT]:
                self.stopMouseTimer()
                return
        except:
            pass

        self._hideControl(self.C_MAIN_MOUSE_CONTROLS)
               
    def resetMouseTimer(self):
        self.mouseCount = 0
        self.stopMouseTimer()
        try:
            self.m = Timer(10 if self.touch else 3, self.onMouseTimer)
            self.m.start()
        except:
            pass
        
    def stopMouseTimer(self):
        try:
            self.m.cancel()
        except:
            pass
    
    def onTimer(self):
          #clear program cache every 24 hours
          self.counter += 1
          if self.counter >= 24 * (60 / 5):#24 hours
              self.clearProgramCache()

          # update current time
          c = self.getControl(4100)
          (x, y) = c.getPosition()

          timeDelta = datetime.datetime.today() - self.viewStartDate
          secs      = timeDelta.seconds
          days      = timeDelta.days

          if timeDelta.days == 0 and secs > 0*60 and secs < self.RANGE.seconds:
               if secs > self.INTERVAL.seconds:
                   self.viewStartDate += self.INTERVAL
               self.onRedrawEPG(self.page, self.viewStartDate, autoChangeFocus=False, showLoading = True)

          self.resetTimer()
          
    def resetTimer(self):                   
        try:
            self.stopTimer()
            self.t = Timer(5*60, self.onTimer)        
            self.t.start()
        except:
            pass
        
    def stopTimer(self):                   
        try:
            self.t.cancel()        
        except:
            pass

    def onFetchTimer(self):          
        try:
            channels = self.source.getChannelList()

            self.fetchInterval += 1

            viewStartDate = self.viewStartDate + (self.fetchInterval * self.RANGE)
            viewEndDate   = viewStartDate + self.RANGE

            while self.getProgramKey(channels[self.fetchChannel], viewStartDate) in self.cache:
                if self.fetchInterval > 1:
                    self.fetchChannel  += 1
                    self.fetchInterval  = 0
                else:
                    self.fetchInterval += 1
                viewStartDate = self.viewStartDate + (self.fetchInterval * self.RANGE)
                viewEndDate   = viewStartDate + self.RANGE         

            #cmd = 'XBMC.Notification(Fetching = %s, Time = %s)' % (str(self.fetchChannel), self.getProgramKey(channels[self.fetchChannel], viewStartDate))
            #xbmc.executebuiltin(cmd)

            programList = self.getProgramList(channels[self.fetchChannel], viewStartDate, viewEndDate)             
            if self.fetchInterval > 1:
                self.fetchChannel  += 1
                self.fetchInterval  = -1
           
            self.resetFetchTimer()    

        except:
            pass


    def resetFetchTimer(self):                
        try:
            self.stopFetchTimer()
            self.f = Timer(self.fetchTime, self.onFetchTimer)
            self.f.start()
        except:
            pass


    def stopFetchTimer(self):
        try:
            self.f.cancel()        
        except:
            pass


    def onThumbTimer(self): 
        self.updateThumb(self.source.getThumb(self.program))


    def resetThumbTimer(self):
        try:
            self.stopThumbTimer()
            self.thumb = Timer(1, self.onThumbTimer)
            self.thumb.start()
        except:
            pass


    def stopThumbTimer(self):
        try:
            self.i.cancel()        
        except:
            pass


    def showThumb(self, show):
        if xbmc.Player().isPlaying():
            self.getControl(self.C_MAIN_IMAGE).setVisible(False)
            self.getControl(self.C_MAIN_THUMB).setVisible(False)
            return

        self.getControl(self.C_MAIN_IMAGE).setVisible(not show)
        self.getControl(self.C_MAIN_THUMB).setVisible(show)



    def updateThumb(self, thumb):
        self.showThumb(thumb != None)
        self.setControlImage(self.C_MAIN_THUMB, thumb)
        #self.setControlImage(4600, thumb)

            
    def setRange(self, value):                
        if value < 0  or value > 5:
            return False
            
        if self.range == value:
            return
            
        self.range = value

        if self.range   == 0:
            extent = 1
        elif self.range == 1:
            extent = 2
        elif self.range == 2:
            extent = 4
        elif self.range == 3:
            extent = 6
        elif self.range == 4:
            extent = 12
        elif self.range == 5:
            extent = 24

        self.INTERVAL   = datetime.timedelta(hours = extent/4.0)
        self.CELL_WIDTH = 564 / extent
        self.RANGE      = datetime.timedelta(hours = extent)

        xbmcaddon.Addon(id = 'script.tvcatchup').setSetting('range', str(self.range))

        self.clearProgramCache()

        self.setFont()
        return True

    def setFont(self):
        if THEME == 'large-text':
            self.FONT = 'font30'
        elif self.touch:
            if self.range   == 0:
                self.FONT = 'font13'
            elif self.range == 1:
                self.FONT = 'font12'
            elif self.range == 2:
                self.FONT = 'font10'
            elif self.range == 3:
                self.FONT = 'font10'
            elif self.range == 4:
                self.FONT = 'font10'
            elif self.range == 5:
                self.FONT = 'font10'
        else:
            if self.range == 0:
                self.FONT = 'font30'
            elif self.range == 1:
                self.FONT = 'font13'
            elif self.range == 2:
                self.FONT = 'font13'
            elif self.range == 3:
                self.FONT = 'font13'
            elif self.range == 4:
                self.FONT = 'font10'
            elif self.range == 5:
                self.FONT = 'font10'

        self.onRedrawEPG(self.page, self.viewStartDate, autoChangeFocus = True, showLoading = True)

    def getProgressDialog(self):
        dp = None
        if ADDON.getSetting('showLoadingbar') == 'true':
            xbmc.sleep(50) # allows keyboard to close, hack to prevents graphical glitch in Dharma/Eden!
            dp = xbmcgui.DialogProgress()
            dp.create('TVCatchup','Searching...', '')
            dp.update(0)

        return dp

    def doMovies(self):  
        dp       = self.getProgressDialog()
        programs = self.source.getMovies(dp)
        selected = program_list.show(programs, self.source.getChannelList(), 'Movies', True, dp)

        if selected:
            self.jumpTo(selected[0], selected[2], selected[3])

    def doSimilar(self):
        try:
            controlInFocus = self.getFocus()
            if controlInFocus == None:
                return
        except:
            return

        if self.program == None:
            return

        dp = self.getProgressDialog()

        programs = self.source.getSimilar(self.program, dp)
        selected = program_list.show(programs, self.source.getChannelList(), '%s' % self.program.title, True, dp)

        if selected:
            self.jumpTo(selected[0], selected[2], selected[3])

    def doRepeats(self):        
        try:
            controlInFocus = self.getFocus()
            if controlInFocus == None:
                return
        except:
            return

        if self.program == None:
            return

        dp       = self.getProgressDialog()
        programs = self.source.getRepeats(self.program, dp)
        selected = program_list.show(programs, self.source.getChannelList(), 'Repeats of %s' % self.program.title, True, dp)

        if selected:
            self.jumpTo(selected[0], selected[2], selected[3])

    def doNow(self):
        dp       = self.getProgressDialog()
        programs = self.source.getNow(dp)
        selected = program_list.show(programs, self.source.getChannelList(), 'Now Showing', False, dp)

        if selected:
            self.jumpTo(selected[0], selected[2], selected[3])


    def doFind(self):       
        kb = xbmc.Keyboard('', 'Find', False)
        kb.doModal()
        if not kb.isConfirmed():
            return

        text = kb.getText()
        if text == '':
            return      

        dp       = self.getProgressDialog()
        programs = self.source.getFind(text, dp)
        selected = program_list.show(programs, self.source.getChannelList(), 'Find - %s' % text, True, dp)

        if selected:
            self.jumpTo(selected[0], selected[2], selected[3])


    def parseDate(self, dateString):
        if type(dateString) in [str, unicode]:            
            dt = dateString.split(' ')
            d  = dt[0]
            t  = dt[1]
            ds = d.split('-')
            ts = t.split(':')
            return datetime.datetime(int(ds[0]), int(ds[1]) ,int(ds[2]), int(ts[0]), int(ts[1]), int(ts[2]))

        return dateString


    def jumpTo(self, title, channel, theTime):
        startTime = self.parseDate(theTime)

        self.viewStartDate = startTime
        self.viewStartDate -= datetime.timedelta(minutes = self.viewStartDate.minute % 30)

        theChannels = self.source.getChannelList()
        index = -1
        for c in theChannels:
            index = index + 1
            if c.id == channel:
                break

        self.page = (index / CHANNELS_PER_PAGE)
        self.onRedrawEPG(self.page, self.viewStartDate, autoChangeFocus=False, showLoading = True)

        control = None

        for key in self.controlToProgramMap.keys():
            p = self.controlToProgramMap[key]
            if title == p.title and startTime == p.startDate:
                control = self.getControl(key)
                break

        if control is not None:
            self.doFocus(control)            


    def onAction(self, action):
        global INIT
        if not INIT:
            return

        xbmc.log("[script.tvcatchup] *******************onAction***************************",xbmc.LOGDEBUG)
        xbmc.log("[script.tvcatchup] "+ str(action.getId()),xbmc.LOGDEBUG)
        xbmc.log("[script.tvcatchup] "+ str(action.getButtonCode()),xbmc.LOGDEBUG)    
            
        try:
            actionId = action.getId()
            buttonId = action.getButtonCode()

            #xbmc.executebuiltin('XBMC.Notification(ActionID = %s, ButtonID = %s, 1)' % (str(actionId), str(buttonId)))

            if actionId == KEY_ESC_ID and buttonId == KEY_ESC_CODE:
                self.close()
                return
                            
            if actionId == ACTION_PARENT_DIR:
                self.close()
                return           
            
            if self.ATV2 and actionId == ACTION_PREVIOUS_MENU:
                self.close()
                return

            if actionId == KEY_NAV_BACK:
                self.close()
                return
                
            control        = None
            controlInFocus = None
            
            try:
                controlInFocus = self.getFocus()
                (left, top) = controlInFocus.getPosition()
                currentX = left + (controlInFocus.getWidth() / 2)
                currentY = top + (controlInFocus.getHeight() / 2)
                self.mouseCount = 0
            except:
                currentX = -1
                currentY = -1

            if actionId == ACTION_PLAY:
                if controlInFocus is not None:
                    controlID = controlInFocus.getId()
                    self.onClick(controlID)                
                return

            if actionId in [ACTION_LEFT, ACTION_RIGHT, ACTION_UP, ACTION_DOWN]:
                if currentX < 0 or currentY < 0:
                    if len(self.controlToProgramMap.keys()) > 0:
                        self.setFocusId(self.controlToProgramMap.keys()[0])
                    else:
                        self.goHome()
                    return

            if actionId == ACTION_LEFT:
                control = self._left(currentX, currentY)
            elif actionId == ACTION_RIGHT:
                control = self._right(currentX, currentY)
            elif actionId == ACTION_UP:
                control = self._up(currentY)
            elif actionId == ACTION_DOWN:
                control = self._down(currentY)
            elif actionId == ACTION_NEXT_ITEM:
                control= self._nextDay( currentY)
            elif actionId == ACTION_PREV_ITEM:
                control= self._previousDay(currentY)
            elif actionId == ACTION_PAGE_UP:
                control = self._pageUp()
            elif actionId == ACTION_PAGE_DOWN:
                control = self._pageDown()
            elif actionId in [KEY_CONTEXT_MENU, ACTION_PREVIOUS_MENU] and controlInFocus is not None:
                program = self._getProgramFromControlId(controlInFocus.getId())
                if program is not None:
                    self._showContextMenu(program, controlInFocus)
            elif actionId == KEY_HOME or actionId == ACTION_HOME:
                self.goHome()
            elif actionId == MOUSE_WHEEL_UP:
                control = self._pageUp()
            elif actionId == MOUSE_WHEEL_DOWN:
                control = self._pageDown()                
            elif (actionId == ACTION_MOUSE_MOVE) or (actionId == ACTION_TOUCH_MOVE):
                if not controlInFocus:
                    self.mouseCount = self.mouseCount + 1
                    if self.mouseCount > 10:
                        self.resetMouseTimer()
                        if self.showMouseCtrl:                        
                            self._showControl(self.C_MAIN_MOUSE_CONTROLS)
                return
            elif buttonId == KEY_M:
                self.setRange(self.range + 1)
            elif buttonId == KEY_L:
                self.setRange(self.range - 1)
            elif buttonId == KEY_H:
                helpscreen = HelpMenu()
                helpscreen.doModal()     
                del helpscreen
            elif buttonId == KEY_I or actionId == ACTION_SHOW_INFO:
                if self.program and self.program.id > 0:
                    infowindow = InfoWindow(self.program.id)
                    infowindow.doModal()     
                    del infowindow            
            elif self.touch and actionId == MOUSE_CLICK:
                if controlInFocus == None:
                    self.resetMouseTimer()
                    if self.showMouseCtrl:
                        self._showControl(self.C_MAIN_MOUSE_CONTROLS)
            elif buttonId == KEY_F:
                self.doFind()
            elif buttonId == KEY_G:
                self.doMovies()
            elif buttonId == KEY_N:
                self.doNow()
            elif buttonId == KEY_R:
                self.doRepeats()
            elif buttonId == KEY_T:
                self.doSimilar()
            if control is not None:
                self.doFocus(control)

        except Exception:
            buggalo.onExceptionRaised()
            xbmcgui.WindowXML.close(self)
                   
               
    def onClick(self, controlId):
        global INIT
        if not INIT:
            return

        xbmc.log("[script.tvcatchup] *******************onClick***************************",xbmc.LOGDEBUG)
        xbmc.log("[script.tvcatchup] "+str(controlId),xbmc.LOGDEBUG)               
                        
        try:        
            control = None
        
            if controlId == self.C_MAIN_MOUSE_EXIT:
                self.close()
                return

            if not self.touch:                                                      
                self.stopMouseTimer()
               
            try:
                if controlId == self.C_MAIN_MOUSE_HOME:
                    self.viewStartDate = datetime.datetime.today()
                    self.viewStartDate -= datetime.timedelta(minutes = self.viewStartDate.minute % 30)
                    self.onRedrawEPG(self.page, self.viewStartDate, autoChangeFocus = True)                           
                    control = self.getControl(self.controlToProgramMap.keys()[0])                

                if controlId == self.C_MAIN_MOUSE_LEFT:
                    self.viewStartDate -= self.RANGE
                    self.onRedrawEPG(self.page, self.viewStartDate, autoChangeFocus = True)
                    control = self.getControl(self.controlToProgramMap.keys()[0])                                                                      
                if controlId == self.C_MAIN_MOUSE_UP:
                    control = self._pageUp() 
          
                if controlId == self.C_MAIN_MOUSE_DOWN:
                    control = self._pageDown()
          
                if controlId == self.C_MAIN_MOUSE_RIGHT:
                    self.viewStartDate += self.RANGE
                    self.onRedrawEPG(self.page, self.viewStartDate, autoChangeFocus=True)                
                    control = self.getControl(self.controlToProgramMap.keys()[0])          
            except:
                pass 
                       
                
            if controlId in [self.C_MAIN_MOUSE_HOME, self.C_MAIN_MOUSE_LEFT, self.C_MAIN_MOUSE_UP,  self.C_MAIN_MOUSE_DOWN, self.C_MAIN_MOUSE_RIGHT]:
                if self.touch: self.resetMouseTimer() 
                if control:    self.doFocus(control)                    
                return                
                
            if controlId == self.C_MAIN_MOUSE_ZOOM_IN:
                if self.touch: self.resetMouseTimer()                   
                self.setRange(self.range - 1)
                self.doFocus()          
                return                    
                    
            elif controlId == self.C_MAIN_MOUSE_ZOOM_OUT:
                if self.touch: self.resetMouseTimer()                   
                self.setRange(self.range + 1)
                self.doFocus()          
                return
                      
            prevCtrl      = self.prevCtrl
            self.prevCtrl = controlId
            if self.touch:
                if prevCtrl != self.prevCtrl:
                    return
                                 
            program = self._getProgramFromControlId(controlId)
            if program is None:
                if self.touch:
                    self.resetMouseTimer()
                    if self.showMouseCtrl:
                        self._showControl(self.C_MAIN_MOUSE_CONTROLS)
                return             

            if self.isOnNow(program) and not self.touch:
                self.play(program.channel)
            else:
               self._showContextMenu(program, self.getControl(controlId))   

        except Exception:
            buggalo.onExceptionRaised()

    def isOnNow(self, program):
        if program.title == "Close":
            return False

        now   = datetime.datetime.today()
        start = program.startDate
        end   = program.endDate

        return now >= start and now < end

    def play(self, channel):                      
        TVCPlayer().playStream(channel)

    def _hideEPG(self):
        self._hideControl(self.C_MAIN_EPG)
        self._clearEPG()

    def _clearEPG(self):        
        if self.hasRemoveControls:
           try:
               self.removeControls(self.controlStore)
           except:
               pass
        else:
            for control in self.controlStore:
                try:
                    self.removeControl(control)  
                except:
                    pass

        del self.controlStore[:]    


    def _showContextMenu(self, program, control):
        isNotificationRequiredForProgram = self.notification.isNotificationRequiredForProgram(program)
        isNotificationRequiredForSeries  = self.notification.isNotificationRequiredForSeries(program)

        d = PopupMenu(self.source, program, not isNotificationRequiredForProgram, not isNotificationRequiredForSeries)
        d.doModal()
        buttonClicked = d.buttonClicked
        del d

        if buttonClicked == 4012:
            helpscreen = HelpMenu()
            helpscreen.doModal()     
            del helpscreen
            return

        if buttonClicked == 4014:
            if self.program and self.program.id > 0:
                infowindow = InfoWindow(self.program.id)
                infowindow.doModal()     
                del infowindow
            return

        if buttonClicked == 4015:
            if self.program and self.program.channel.id > 0:                
                ch    = self.program.channel
                name  = '%s (TVCatchup)' % ch.title
                thumb = 'special://home/userdata/addon_data/script.tvcatchup/square_logos/channel_%s.png' % ch.id
                cmd   = 'RunScript(&quot;script.tvcatchup&quot;,%s,%s)' % (ch.id, ch.title)
                favourite.add(name, cmd, thumb)
            return

        elif buttonClicked == 4013:
            searchmenu = PopupSearchMenu(self.source, program)
            searchmenu.doModal() 
            button = searchmenu.buttonClicked
            del searchmenu
            if button == 4301:
                self.doFind()
            elif button == 4302:
                self.doNow()
            elif button == 4303:
                self.doMovies()
            elif button == 4304:
                self.doRepeats()
            elif button == 4305:
                self.doSimilar()
            return

        if buttonClicked == PopupMenu.C_POPUP_REMIND:
            if isNotificationRequiredForProgram:
                self.notification.delProgram(program)
            else:
                self.notification.addProgram(program)

        elif buttonClicked == PopupMenu.C_POPUP_SERIES:
            if isNotificationRequiredForSeries:
                self.notification.delSeries(program)
            else:
                self.notification.addSeries(program)

        if buttonClicked == PopupMenu.C_POPUP_SERIES or buttonClicked == PopupMenu.C_POPUP_REMIND:
            #force refresh
            (left, top) = control.getPosition()
            y = top + (control.getHeight() / 2)
            self.onRedrawEPG(self.page, self.viewStartDate, autoChangeFocus = False)
            self.doFocus(self._findControlOnRight(left, y))

        elif buttonClicked == PopupMenu.C_POPUP_PLAY:
            self.play(program.channel)            

    def _showHelpMenu(self):
        d = HelpMenu()
        d.doModal()
        buttonClicked = d.buttonClicked
        del d
        
    def onFocus(self, controlId):
        try:
            try:
                controlInFocus = self.getControl(controlId)
            except:
                return

            self.program = self._getProgramFromControlId(controlId)
            if self.program is None:    
                return

            (left, top) = controlInFocus.getPosition()
            if left > self.focusX or left + controlInFocus.getWidth() < self.focusX:
                self.focusX = left

            self.getControl(self.C_MAIN_TITLE).setLabel('[B]%s[/B]' % self.program.title)
            self.getControl(self.C_MAIN_TIME).setLabel('[B]%s - %s[/B]' % (self.program.startDate.strftime('%H:%M'), self.program.endDate.strftime('%H:%M')))
            self.getControl(self.C_MAIN_DESCRIPTION).setText(self.program.description)
            self.getControl(self.C_MAIN_DESCRIPTION).setVisible(self.program.description != '')

            if self.program.channel.logo is not None:
                self.setControlImage(self.C_MAIN_LOGO, self.program.channel.logo)

            thumb, fetch = self.source.getCachedThumb(self.program)
            if thumb:
                self.updateThumb(thumb)
            elif fetch:  
                self.resetThumbTimer()
            else:
                self.showThumb(False)

        except Exception:
            buggalo.onExceptionRaised()

    def setControlImage(self, controlId, image):
        if image == None:
            return

        control = self.getControl(controlId)
        if control:
            control.setImage(image)


    def _left(self, currentX, currentY):
        control = None
        try:
            control = self._findControlOnLeft(currentX, currentY)
        except:
            pass

        if control is None:
            self.viewStartDate -= self.RANGE
            self.onRedrawEPG(self.page, self.viewStartDate)
            control = self._findControlOnLeft(1280, currentY)

        if control is not None:
            (left, top) = control.getPosition()
            self.focusX = left
        return control

    def _right(self, currentX, currentY):
        control = None
        try:
            control = self._findControlOnRight(currentX, currentY)
        except:
            pass

        if control is None:
            self.viewStartDate += self.RANGE
            self.onRedrawEPG(self.page, self.viewStartDate)
            control = self._findControlOnRight(0, currentY)

        if control is not None:
            (left, top) = control.getPosition()
            self.focusX = left
        return control

    def _up(self, currentY):
        control = self._findControlAbove(currentY)
        if control is None:
            self.page = self.onRedrawEPG(self.page - 1, self.viewStartDate)
            control = self._findControlAbove(720)
        return control

    def _down(self, currentY):
        control = self._findControlBelow(currentY)
        if control is None:
            self.page = self.onRedrawEPG(self.page + 1, self.viewStartDate)
            control = self._findControlBelow(0)
        return control

    def _nextDay(self, currentY):
        self.viewStartDate += datetime.timedelta(days = 1)
        self.page = self.onRedrawEPG(self.page, self.viewStartDate)
        return self._findControlOnLeft(0, currentY)

    def _previousDay(self, currentY):
        self.viewStartDate -= datetime.timedelta(days = 1)
        self.page = self.onRedrawEPG(self.page, self.viewStartDate)
        return self._findControlOnLeft(1280, currentY)

    def _pageUp(self):
        self.page = self.onRedrawEPG(self.page - 1, self.viewStartDate)
        return self._findControlAbove(720)

    def _pageDown(self):
        self.page = self.onRedrawEPG(self.page+ 1, self.viewStartDate)
        return self._findControlBelow(0)

    def getProgramKey(self, channel, startDate):
        if type(channel.id) in [str, unicode]:
            id = channel.id.encode('utf-8', 'ignore')
        else:
            id = str(channel.id)   

        key = '%s' % (startDate)
        key = key.rsplit(':', 1)[0]
        key = key + '-%s-%s' % (self.range, id)

        return key

    def clearProgramCache(self):
        self.counter = 0
        self.cache   = dict()
        self.source.clearProgramCache()

    def getProgramList(self, channel, startDate, endDate):
        key             = self.getProgramKey(channel, startDate)
        self.cache[key] = True   

        return self.source.getProgramList(channel, startDate, endDate)

    def goHome(self):
        self.viewStartDate = datetime.datetime.today()
        self.viewStartDate -= datetime.timedelta(minutes = self.viewStartDate.minute % 30)
        self.onRedrawEPG(self.page, self.viewStartDate, showLoading = True)

    def onRedrawEPG(self, page, startTime, autoChangeFocus = True, showLoading = True):
        global INIT
        if not INIT:
            return

        if ADDON.getSetting('showLoadingbar') == 'true':
            showLoading = True
        else:
            showLoading = False

        self.fetchInterval = 0
        self.fetchChannel  = 0

        self.controlToProgramMap.clear()

        progressControl = self.getControl(self.C_MAIN_LOADING_PROGRESS)
        progressControl.setPercent(0.1)
        self.getControl(self.C_MAIN_LOADING).setVisible(showLoading)

        # move timebar to current time
        timeDelta = datetime.datetime.today() - self.viewStartDate
        c = self.getControl(4100)
        (x, y) = c.getPosition()
        c.setPosition(self._secondsToXposition(timeDelta), y)        
        c.setVisible(timeDelta.days == 0)

        # date and time row
        self.getControl(self.C_MAIN_DATE).setLabel(self.viewStartDate.strftime('%a, %d. %b'))
        for col in range(1, 5):
            self.getControl(self.C_MAIN_DATE + col).setLabel(startTime.strftime('%H:%M'))
            startTime += self.INTERVAL

        # channels
        try:
            channels = self.source.getChannelList()
        except source.SourceException as ex:
            self.onEPGLoadError()
            return page

        if channels == None:
            return page

        totalPages = len(channels) / CHANNELS_PER_PAGE
        if not len(channels) % CHANNELS_PER_PAGE:
            totalPages -= 1

        if page < 0:
            page = totalPages
        elif page > totalPages:
            page = 0

        channelStart = page * CHANNELS_PER_PAGE
        channelEnd   = page * CHANNELS_PER_PAGE + CHANNELS_PER_PAGE

        viewEndDate = self.viewStartDate + self.RANGE
        dayEndDate  = self.viewStartDate + datetime.timedelta(hours = 24)        

        viewChannels = channels[channelStart : channelEnd]

        controlsToAdd = list()
        nmrPrograms   = 0
        nmrChannels   = len(viewChannels)

        for idx, channel in enumerate(viewChannels):
            progressControl.setPercent((idx * 100 / len(viewChannels)) + 1)

            # Loads programs for yesterday as well to compensate for midnight
            programs = list()
            try:
                programList = self.getProgramList(channel, self.viewStartDate, viewEndDate)
                if programList:
                    programs += programList
                if not isinstance(self.source, source.XMLTVSource):
                    programList = self.getProgramList(channel, self.viewStartDate - datetime.timedelta(days =  1))
                    if programList:
                        programs += programList
            except source.SourceException as ex:
                self.onEPGLoadError()
                return page

            if programs is None:
                self.onEPGLoadError()
                return page

            nmrPrograms = nmrPrograms + len(programs)

            for program in programs:   
                startDelta = program.startDate - self.viewStartDate
                stopDelta  = program.endDate   - self.viewStartDate

                cellStart = self._secondsToXposition(startDelta)
                if startDelta.days < 0:
                    cellStart = CELL_WIDTH_CHANNELS
                cellWidth = self._secondsToXposition(stopDelta) - cellStart
                if cellStart + cellWidth > 1260:
                    cellWidth = 1260 - cellStart                
                
                if cellWidth > 2:
                    if self.notification.isNotificationRequiredForProgram(program) or  self.notification.isNotificationRequiredForSeries(program) :
                        noFocusTexture = TEXTURE_BUTTON_NOFOCUS_NOTIFY
                        focusTexture   = TEXTURE_BUTTON_FOCUS_NOTIFY
                    elif self.isOnNow(program):                    
                        noFocusTexture = TEXTURE_BUTTON_NOFOCUS_SHOWING
                        focusTexture   = TEXTURE_BUTTON_FOCUS_SHOWING
                    else:
                        noFocusTexture = TEXTURE_BUTTON_NOFOCUS
                        focusTexture   = TEXTURE_BUTTON_FOCUS

                    if cellWidth < 25:
                        title = '' # Text will overflow outside the button if it is to narrow
                    else:
                        title = program.title

                    if self.FONT == None:
                        control = xbmcgui.ControlButton(
                            cellStart,
                            60 + CELL_HEIGHT * idx,
                            cellWidth   - 2,
                            CELL_HEIGHT - 2,
                            title,
                            noFocusTexture = noFocusTexture,
                            focusTexture   = focusTexture
                        )
                    else:
                        control = xbmcgui.ControlButton(
                            cellStart,
                            60 + CELL_HEIGHT * idx,
                            cellWidth   - 2,
                            CELL_HEIGHT - 2,
                            title,
                            noFocusTexture = noFocusTexture,
                            focusTexture   = focusTexture,
                            font           = self.FONT
                        )
                   
                    controlsToAdd.append([control, program])    

        # remove program controls
        self._clearEPG()

        # add program controls and then create map
        for control, program in controlsToAdd:
            if not self.hasAddControls:
                self.addControl(control)
            self.controlStore.append(control)

        if self.hasAddControls:
            self.addControls(self.controlStore)

        for control, program in controlsToAdd:            
            self.controlToProgramMap[control.getId()] = program

        try:
            self.getFocus()
        except:
            autoChangeFocus = True

        if autoChangeFocus:
            if len(self.controlToProgramMap.keys()) > 0:
                self.setFocusId(self.controlToProgramMap.keys()[0])
               
        self.getControl(self.C_MAIN_LOADING).setVisible(False)

        # set channel logo or text
        channelsToShow = channels[channelStart : channelEnd]
        for idx in range(0, CHANNELS_PER_PAGE):
            if idx >= len(channelsToShow):
                self.setControlImage(4110 + idx, '')
                self.getControl(4010 + idx).setLabel('')
            else:
                channel = channelsToShow[idx]
                self.getControl(4010 + idx).setLabel(channel.title)
                if channel.logo is not None:
                    self.setControlImage(4110 + idx, channel.logo)
                else:
                    self.setControlImage(4110 + idx, '')
       
        if self.firstTime:
            self.firstTime = False

            #avg = nmrPrograms / float(nmrChannels)
            #if avg < 1.75:
            #   self.guideLow()

            xbmcaddon.Addon(id = 'script.tvcatchup').setSetting('show_license', 'false')

        self.resetTimer()
        self.resetFetchTimer()
        return page

    def guideLow(self):
        if dialogue.doYesNo('TVCatchup', ['', 'Program Guide Data is low.', '', 'Do you want to download', 'the latest data now?'], 'Yes', 'No') == 0:
            return

        self.source.downloadDB()
        self.onRedrawEPG(self.page, self.viewStartDate)

    def doFocus(self, control = None):    
        if control == None:
            control = self.getControl(self.controlToProgramMap.keys()[0])                
            
        self.setFocus(control)
        self.prevCtrl = control.getId()


    def onEPGLoadError(self):
        self.getControl(self.C_MAIN_LOADING).setVisible(False)

        dialogue.doOK(strings(LOAD_ERROR_TITLE), ['', '', strings(LOAD_ERROR_LINE1), strings(LOAD_ERROR_LINE2)])

        self.close()
        #xbmcaddon.Addon(id='script.tvcatchup').openSettings()

    def _secondsToXposition(self, timedelta):
        return CELL_WIDTH_CHANNELS + (((timedelta.days * 86400) + timedelta.seconds) * self.CELL_WIDTH / 1800)

    def _findControlOnRight(self, currentX, currentY):
        distanceToNearest = 10000
        nearestControl = None

        for controlId in self.controlToProgramMap.keys():
            control = self.getControl(controlId)
            (left, top) = control.getPosition()
            x = left + (control.getWidth() / 2)
            y = top + (control.getHeight() / 2)

            if currentX < x and currentY == y:
                distance = abs(currentX - x)
                if distance < distanceToNearest:
                    distanceToNearest = distance
                    nearestControl = control

        return nearestControl


    def _findControlOnLeft(self, currentX, currentY):
        distanceToNearest = 10000
        nearestControl = None

        for controlId in self.controlToProgramMap.keys():
            control = self.getControl(controlId)
            (left, top) = control.getPosition()
            x = left + (control.getWidth() / 2)
            y = top + (control.getHeight() / 2)

            if currentX > x and currentY == y:
                distance = abs(currentX - x)
                if distance < distanceToNearest:
                    distanceToNearest = distance
                    nearestControl = control

        return nearestControl

    def _findControlBelow(self, currentY):
        nearestControl = None

        y = currentY

        for controlId in self.controlToProgramMap.keys():
            try:
                control = self.getControl(controlId)
                (leftEdge, top) = control.getPosition()
                y = top + (control.getHeight() / 2)

            except:
                pass
            
            if currentY < y:
                rightEdge = leftEdge + control.getWidth()
                if(leftEdge <= self.focusX < rightEdge
                   and (nearestControl is None or nearestControl.getPosition()[1] > top)):
                    nearestControl = control

        return nearestControl

    def _findControlAbove(self, currentY):
        nearestControl = None

        y = currentY

        for controlId in self.controlToProgramMap.keys():
            try:
                control = self.getControl(controlId)           
                (leftEdge, top) = control.getPosition()
                y = top + (control.getHeight() / 2)

            except:
                pass

            if currentY > y:
                rightEdge = leftEdge + control.getWidth()
                if(leftEdge <= self.focusX < rightEdge
                   and (nearestControl is None or nearestControl.getPosition()[1] < top)):
                    nearestControl = control

        return nearestControl

    def _getProgramFromControlId(self, controlId):
        if self.controlToProgramMap.has_key(controlId):
            return self.controlToProgramMap[controlId]
        return None
        
    def _hideControl(self, *controlIds):
        #Visibility is inverted in skin
        for controlId in controlIds:
            try:
                self.getControl(controlId).setVisible(True)
            except:
                pass

    def _showControl(self, *controlIds):
        #Visibility is inverted in skin
        for controlId in controlIds:
            try:
                self.getControl(controlId).setVisible(False)
            except:
                pass

class PopupMenu(xbmcgui.WindowXMLDialog):
    C_POPUP_PLAY = 4000
    C_POPUP_SERIES = 4001
    C_POPUP_REMIND = 4002
    C_POPUP_CHANNEL_LOGO = 4100
    C_POPUP_CHANNEL_TITLE = 4101
    C_POPUP_PROGRAM_TITLE = 4102
    C_POPUP_HELP = 4012

    def __new__(cls, source, program, showRemind, showSeries):
        xmlfile = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')), 'resources', 'skins',  'Default', '720p', THEME + '-script-tvcatchup-menu.xml')
        if not os.path.exists(xmlfile):
            PREFIX = ""
        else:
            PREFIX = THEME + "-"
        return super(PopupMenu, cls).__new__(cls, PREFIX + 'script-tvcatchup-menu.xml', ADDON.getAddonInfo('path'))
        
    def __init__(self, source, program, showRemind, showSeries):
        """

        @type source: source.Source
        @param program:
        @type program: source.Program
        @param showRemind:
        @param showSeries:
        """
        super(PopupMenu, self).__init__()
        self.source        = source
        self.program       = program
        self.showRemind    = showRemind
        self.showSeries    = showSeries
        self.buttonClicked = None

    def onInit(self):
        try:
            playControl         = self.getControl(self.C_POPUP_PLAY)
            remindControl       = self.getControl(self.C_POPUP_REMIND)
            channelLogoControl  = self.getControl(self.C_POPUP_CHANNEL_LOGO)
            channelTitleControl = self.getControl(self.C_POPUP_CHANNEL_TITLE)
            programTitleControl = self.getControl(self.C_POPUP_PROGRAM_TITLE)

            seriesControl = self.getControl(self.C_POPUP_SERIES)
            if self.showSeries:
                seriesControl.setLabel(strings(REMIND_SERIES))
            else:
                seriesControl.setLabel(strings(DONT_REMIND_SERIES))

            playControl.setLabel(strings(WATCH_CHANNEL, self.program.channel.title))

            if self.program.channel.logo is not None:
                channelLogoControl.setImage(self.program.channel.logo)
                channelTitleControl.setVisible(False)
            else:
                channelTitleControl.setLabel(self.program.channel.title)
                channelLogoControl.setVisible(False)

            programTitleControl.setLabel(self.program.title)

            if self.showRemind:
                remindControl.setLabel(strings(REMIND_PROGRAM))
            else:
                remindControl.setLabel(strings(DONT_REMIND_PROGRAM))

        except Exception:
            buggalo.onExceptionRaised()

    def onAction(self, action):
        try:
            if action.getId() in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, KEY_NAV_BACK, KEY_CONTEXT_MENU]:
                self.close()
                return
        except Exception:
            buggalo.onExceptionRaised()

    def onClick(self, controlId):
        try:            
            self.buttonClicked = controlId
            self.close()            
        except Exception:
            buggalo.onExceptionRaised()

    def onFocus(self, controlId):
        pass

class PopupSearchMenu(xbmcgui.WindowXMLDialog):
    C_SEARCH_CHANNEL_LOGO = 4100
    C_SEARCH_CHANNEL_TITLE = 4101
    C_SEARCH_PROGRAM_TITLE = 4102
    C_SEARCH_TITLE        = 4301
    C_SEARCH_NOW          = 4302
    C_SEARCH_FILMS        = 4303
    C_SEARCH_REPEATS      = 4304
    C_SEARCH_SIMILAR      = 4305
    C_SEARCH_CANCEL       = 4310

    def __new__(cls, source, program):
        xmlfile = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')), 'resources', 'skins',  'Default', '720p', THEME + '-script-tvcatchup-search-menu.xml')
        if not os.path.exists(xmlfile):
            PREFIX = ""
        else:
            PREFIX = THEME + "-"
        return super(PopupSearchMenu, cls).__new__(cls, PREFIX + 'script-tvcatchup-search-menu.xml', ADDON.getAddonInfo('path'))
        
    def __init__(self, source, program):
        """

        @type source: source.Source
        @param program:
        @type program: source.Program
        @param showRemind:
        @param showSeries:
        """
        super(PopupSearchMenu, self).__init__()
        self.source        = source
        self.program       = program
        self.buttonClicked = None
        
    def onInit(self):
        try:
            cancelControl       = self.getControl(self.C_SEARCH_CANCEL)
            channelLogoControl  = self.getControl(self.C_SEARCH_CHANNEL_LOGO)
            channelTitleControl = self.getControl(self.C_SEARCH_CHANNEL_TITLE)
            programTitleControl = self.getControl(self.C_SEARCH_PROGRAM_TITLE)

            if self.program.channel.logo is not None:
                channelLogoControl.setImage(self.program.channel.logo)
                channelTitleControl.setVisible(False)
            else:
                channelTitleControl.setLabel(self.program.channel.title)
                channelLogoControl.setVisible(False)

            programTitleControl.setLabel(self.program.title)
        
        except Exception:
            raise
            buggalo.onExceptionRaised()

    def setControlText(self, controlId, text):
        control = self.getControl(controlId)
        if control:
            control.setText(text)

    def onAction(self, action):
        try:
            if action.getId() in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, KEY_NAV_BACK, ACTION_BACK, KEY_ESC_ID]:
                self.close()
                return
        except Exception:
            buggalo.onExceptionRaised()

    def onClick(self, controlId):
        try:            
            self.buttonClicked = controlId
            self.close()
        except Exception:
            buggalo.onExceptionRaised()

    def onFocus(self, controlId):
        pass
