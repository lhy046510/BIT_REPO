#       Copyright (C) 2012 
#       Written on behalf of TVCatchup
#       by Chris Grove (tvc@killergerbils.co.uk)
#       and Sean Poyser (seanpoyser@gmail.com)
#

import xbmc
import dialogue
from source import Channel
#from player import TVCPlayer

program = sys.argv[1]
channel = sys.argv[2]
text    = sys.argv[3]

logo       = Channel(channel, program)
squareLogo = logo.logo.replace('long_logo','square_logo')

if dialogue.doYesNo('TVCatchup', ['', program, text, '', 'Would you like to watch it?'], 'Watch', 'Ignore', squareLogo):   
    ch  = Channel(channel, program)
    cmd = 'RunScript(script.tvcatchup,%s,%s)' % (ch.id, ch.title)

    xbmc.executebuiltin(cmd)

    #TVCPlayer().playStream(Channel(channel, program)) 