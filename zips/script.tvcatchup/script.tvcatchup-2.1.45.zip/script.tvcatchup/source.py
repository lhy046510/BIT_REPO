#
#      Copyright (C) 2012 Tommy Winther
#      http://tommy.winther.nu
#
#      Modified on behalf of TVCatchup
#      by Chris Grove (tvc@killergerbils.co.uk)
#      and Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import os
import simplejson
import datetime
import time
import random
import re
import urllib2
from xml.etree import ElementTree
from strings import *

import xbmc
import xbmcaddon
import xbmcgui
import xbmcgui
import xbmcvfs
from sqlite3 import dbapi2 as sqlite3

import dialogue
import TVC

import geturllib
import urllib2
import re


class Channel(object):
    def __init__(self, id, title):
        self.id = id
        self.title = title        

        longLogoPath   = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('profile')),'long_logos')
        squareLogoPath = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('profile')),'square_logos')

        if not os.path.exists(longLogoPath):
            os.makedirs(longLogoPath)

        if not os.path.exists(squareLogoPath):
            os.makedirs(squareLogoPath)

        self.logo   = os.path.join(longLogoPath , 'channel_' + id + '.png')
        squareLogos = self.logo.replace('long_logos','square_logos')

        if not os.path.exists(self.logo) or not os.path.exists(squareLogos):
            dp = xbmcgui.DialogProgress()
            dp.create("TVCatchup","Caching " + self.title + "'s logo(s) to speed future loading","Please Wait...")
            dp.update(1)

        if not os.path.exists(self.logo):
            try:
                print self.title
                print id
                u = urllib2.urlopen('http://plugins.tvcatchup.com/~xbmc/long_logos/channel_' + id + '.png')
                content = u.read()
                u.close()
                f = open(self.logo,mode='wb')
                f.write(content)
                f.close()
            except:
                pass
            dp.update(50)
        
        if not os.path.exists(squareLogos):
            dp.update(51)
            try:
                u = urllib2.urlopen('http://plugins.tvcatchup.com/~xbmc/square_logos/channel_' + id + '.png')
                content = u.read()
                u.close()
                f = open(squareLogos,mode='wb')
                f.write(content)
                f.close()
            except:
                pass
            dp.update(100)

    def __repr__(self):
        return 'Channel(id=%s, title=%s, logo=%s)' % (self.id, self.title, self.logo)

class Program(object):
    def __init__(self, id, channel, title, startDate, endDate, description, episode, genre):
        self.id          = id
        self.channel     = channel
        self.title       = title
        self.startDate   = self.parseDate(startDate)
        self.endDate     = self.parseDate(endDate)
        self.description = description
        self.episode     = episode
        self.genre       = genre

    def __repr__(self):
        return 'Program(id=%s, channel=%s, title=%s, startDate=%s, endDate=%s, description=%s, episode=%s, genre=%s)' % (str(self.id), self.channel, self.title, self.startDate, self.endDate, self.description, self.episode, self.genre)


    def parseDate(self, dateString):
        if type(dateString) in [str, unicode]:            
            dt = dateString.split(' ')
            d  = dt[0]
            t  = dt[1]
            ds = d.split('-')
            ts = t.split(':')
            return datetime.datetime(int(ds[0]), int(ds[1]) ,int(ds[2]), int(ts[0]), int(ts[1]), int(ts[2]))

        return dateString


class SourceException(Exception):
    pass


class XMLTVSource(object):
    KEY       = "xmltv"
    SOURCE_DB = 'guide1.db'

    def __init__(self):
        self.doc = None      

        # calculate nearest hour
        self.time = time.time()
        self.time -= self.time % 3600   

        ADDON       = xbmcaddon.Addon(id = 'script.tvcatchup')
        self.dbPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))

        geturllib.SetCacheDir(xbmc.translatePath(os.path.join(self.dbPath,'cache' ) ) )
        
        self.initDB()
        #self._checkVersion()

        self.clearProgramCache()

        #delete existing cached channels
        self.channelList = None        
                        
    def __del__(self):
        self.conn.close()


    def downloadDB(self):
        self.conn.close()
        import download_data
        ret = download_data.download_data(True)
        self.clearProgramCache()
        self.initDB()
        return ret


    def initDB(self):
        self.conn = sqlite3.connect(os.path.join(self.dbPath, self.SOURCE_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False)
        self.conn.row_factory = sqlite3.Row


    def rebuildChannelAndProgramListCachesIfNecessary(self): 
        result = None
        try:
            c = self.conn.cursor()
            c.execute("SELECT 1 FROM channels WHERE id LIKE ?", ['%'])       
            result = c.fetchone()
            c.close()
        except:
            pass
       
        if result == None:
            return self.downloadDB()
       
        result = None
        try:
            c = self.conn.cursor()
            c.execute("SELECT 1 FROM programs WHERE channel LIKE ?", ['%'])
            result = c.fetchone()
            c.close()
        except:
            pass
       
        if result != None:
            if not self.dataLow():
                return True            

        xbmc.log("[script.tvcatchup] Empty database detected")
        return self.downloadDB()


    def dataLow(self):
        channels = self.getChannelList()
        visible  = channels[0 : 10]
        programs = list()

        startDate  = datetime.datetime.today()
        startDate -= datetime.timedelta(minutes = startDate.minute % 30)
        endDate    = startDate + datetime.timedelta(hours = 4)
        
        for channel in visible:
            programs += self.getProgramList(channel, startDate, endDate)    

        avg = len(programs) / float(len(visible))

        if avg >  2.75:
            return False

        return dialogue.doYesNo('TVCatchup', ['', 'Program Guide Data is low.', '', 'Do you want to download', 'the latest data now?'], 'Yes', 'No') != 0            
                             

    def getChannelList(self):

        if self.channelList != None:
            return self.channelList

        localList = []
    
        c = self.conn.cursor()        
        c.execute("SELECT id, title FROM channels WHERE source = ?", (self.KEY,))        
        
        for row in c:            
            localList.append(Channel(row["id"], row["title"]))
            
        if len(localList) < 1:              
            xbmc.log("[script.tvcatchup] Getting Channel List...Failed")    
            return None                                

        c.close() 

        #remove channels not enabled in settings
        self.channelList = []  
        for chn in localList:
            enabledChannel = "channel_" + chn.id
            if ADDON.getSetting(enabledChannel) == "true":
                self.channelList.append(chn)     
        
        xbmc.log("[script.tvcatchup] Getting Channel List...Done (Using Database)")
        return self.channelList

    def clearProgramCache(self):
        self.cache = dict()


    def getProgramList(self, channel, startDate, endDate, addCache = True):
        if type(channel.id) in [str, unicode]:
            id = channel.id.encode('utf-8', 'ignore')
        else:
            id = str(channel.id)               

        range = xbmcaddon.Addon(id = 'script.tvcatchup').getSetting('range')

        key = '%s' % (startDate)
        key = key.rsplit(':', 1)[0]
        key = key + '-%s-%s' % (range, id)

        if key in self.cache:
            return self.cache[key]       
            
        programList = []

        c = self.conn.cursor()        
        
        c.execute("SELECT id, title, startDate, endDate, description, episode, genre FROM programs WHERE channel = ? AND endDate >= ? AND startDate < ?", (channel.id, startDate, endDate))        
        for row in c:
            program = Program(row["id"], channel, row["title"], row["startDate"], row["endDate"], row["description"], row["episode"], row["genre"])
            programList.append(program)    

        if addCache:
            self.cache[key] = programList

        return programList  
       

    def _checkVersion(self):
        latestVersion = [1, 2]
        version       = [0, 0]

        c = self.conn.cursor()
        try:
            c.execute('SELECT major, minor FROM version')
            (major, minor) = c.fetchone()
            version = [major, minor]
            c.execute('DROP TABLE version')
        except:
            version = latestVersion

        try:
            c.execute('CREATE TABLE version (major INTEGER, minor INTEGER)')            
            c.execute("INSERT INTO version(major, minor) VALUES(?, ?)", [latestVersion[0], latestVersion[1]])
        except:
            xbmcgui.Window(10000).setProperty("TVCatchup_EPG_Clear_Database", "True")
            dialogue.doOK('TVCatchup', ['', 'A problem has been', 'detected with the EPG data', '', 'Please restart the addon to refresh the data'])
            exit()

        if version < latestVersion:
            xbmc.log("[script.tvcatchup] Old database format detected")

            try:
                c.execute('DROP TABLE channels')
            except:
                pass

            try:
                c.execute('DROP TABLE programs')        
            except:
                pass           

            try:
                c.execute('DROP TABLE last_update')
            except:
                pass           


        self.conn.commit()
        c.close()


    def parseSearch(self, c, dp):

        programList = []  

        if dp:
            dp.update(5)      

        for row in c:
            program = [row["title"], row["description"], row["channel"], row["startDate"], row["endDate"]]
            programList.append(program) 

        if dp:
            dp.update(10)

        return programList


    def getNow(self, dp):
        now = datetime.datetime.today()

        c = self.conn.cursor()
        c.execute("SELECT * FROM programs WHERE startDate <= ? AND endDate >= ?", [now, now])

        return self.parseSearch(c, dp)


    def getFind(self, text, dp):
        includeDesc = True

        text = '%'+text+'%'

        c = self.conn.cursor()

        if includeDesc :
            c.execute("SELECT * FROM programs WHERE title LIKE ? or description LIKE ?ORDER BY startDate ASC LIMIT 0,1000", [text, text])
        else:
            c.execute("SELECT * FROM programs WHERE title LIKE ? ORDER BY startDate ASC LIMIT 0,1000", [text])
        
        return self.parseSearch(c, dp)


    def getRepeats(self, program, dp):
        title   = program.title
        episode = program.episode

        c = self.conn.cursor()
        c.execute("SELECT * FROM programs WHERE title=? AND episode=? ORDER BY startDate ASC", [title, episode])
        
        return self.parseSearch(c, dp)


    def getSimilar(self, program, dp):
        title   = '%'+program.title+'%'

        c = self.conn.cursor()
        c.execute("SELECT * FROM programs WHERE title LIKE ? ORDER BY startDate ASC", [title])

        return self.parseSearch(c, dp)


    def getMovies(self, dp):
        if dp:
            dp.update(1)

        c = self.conn.cursor()
        c.execute("SELECT * FROM programs WHERE genre = ? ORDER BY startDate ASC", ['Film'])
        
        return self.parseSearch(c, dp)


    
    def getThumb(self, program):
        #returns location of thumb if one is available from local or remote source (i.e can be slow)
        return None


    def getCachedThumb(self, program):
        #returns location of thumb if one is available from local source only (i.e. should be very quick)
        #second return parameter is whether GUI should then try standard getThumb (above) method
        return None, False