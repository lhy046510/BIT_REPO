#       Copyright (C) 2012 
#       Written on behalf of TVCatchup
#       by Chris Grove (tvc@killergerbils.co.uk)
#       and Sean Poyser (seanpoyser@gmail.com)
#

import xbmc
import xbmcgui
import xbmcaddon

import threading

from source import Channel
import TVC
import check
import dialogue
import buggalo


class TVCPlayer(xbmc.Player):
    
    def __init__(self, *args, **kwargs):
        xbmc.Player.__init__(self)

    def playStream(self, channel, notify = False):  
                   
        check.keymap()
        ADDON = xbmcaddon.Addon(id = 'script.tvcatchup')   
      
        maxIdle = int(ADDON.getSetting('idle')) * 60 * 60      
        error = None
        
        try:
            playlist, error = TVC.getTVCStreamUrl(None, channel, ADDON.getSetting('NumberOfPlays'))
            if playlist:
                xbmcgui.Window(10000).setProperty("TVCatchup_Channel", channel.id)

                self.play(playlist)
            
                if notify:      
                    header       = 'TVCatchup'
                    message      = 'Switching to %s' % channel.title
                    notification = 'XBMC.Notification(%s, %s, 7500, %s)' % (header, message, channel.logo.replace('long_logo','square_logo'))
                    xbmc.executebuiltin(notification)
                
                while self.isPlaying():
                    xbmc.sleep(1000)
                    if maxIdle > 0:
                        self.CheckIdle(maxIdle)  

                xbmc.sleep(1000)
                
                if not self.isPlaying():
                    xbmcgui.Window(10000).clearProperty("TVCatchup_Channel")
  
                return

        except Exception, e:
            #print e         
            #raise
            pass

        if error:
           dialogue.doOK('TVCatchup', ['', 'Playback Link Error', error])
        else:
           dialogue.doOK('TVCatchup', ['', 'There was a problem trying to stream', channel.title, '', 'Please try again later'])


    def CheckIdle(self, maxIdle):
        idle = xbmc.getGlobalIdleTime()
        if idle < maxIdle:
            return

        delay = 60
        count = delay
        dp = xbmcgui.DialogProgress()
        dp.create("TVCatchup","Streaming will automatically quit in %d seconds" % count, "Press Cancel to contine viewing")
        dp.update(0)
              
        while self.isPlaying() and count > 0 and not dp.iscanceled():
            xbmc.sleep(1000)
            count -= 1
            perc = int(((delay - count) / float(delay)) * 100)
            if count > 1:
                dp.update(perc,"Streaming will automatically quit in %d seconds" % count, "Press Cancel to contine viewing")
            else:
                dp.update(perc,"Streaming will automatically quit in %d second" % count, "Press Cancel to contine viewing")            

        if not dp.iscanceled():
            self.stop()
    

    def Count(self):
        return len(xbmc.PlayList(xbmc.PLAYLIST_VIDEO))


    def Index(self):
        return xbmc.PlayList(xbmc.PLAYLIST_VIDEO).getposition()

   
    def onPlayBackStarted(self):
        pass
        #TVC.viewingStats("PLAYBACK STARTED")        

    def onPlayBackPaused(self):
        pass       

    def onPlayBackResumed(self):
        pass       

    def onPlayBackEnded(self):
        if self.Count() == 1:
            pass
            #TVC.viewingStats("STREAM ENDED")
        elif self.Index() == 0:
            pass
            #TVC.viewingStats("ADVERT ENDED")
        else:
            pass
            #TVC.viewingStats("ADVERT ENDED")


    def onPlayBackStopped(self):        
        if self.Count() == 1:
            pass
            #TVC.viewingStats("STREAM STOPPED")
        elif self.Index() == 0:
            pass
            #TVC.viewingStats("ADVERT STOPPED")
        else:
            pass
            #TVC.viewingStats("STREAM STOPPED")


    def onPlayBackSeek(self, time, seekOffset):
        pass       

    def onPlayBackSeekChapter(self, chapter):
        pass       

    def onPlayBackSpeedChanged(self, speed):
        pass       

    def onQueueNextItem(self):
        pass       
