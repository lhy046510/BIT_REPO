import xbmc, xbmcgui
 
#get actioncodes from keymap.xml
ACTION_PREVIOUS_MENU = 10


class MyClass(xbmcgui.Window):
  def __init__(self):
#buttonTexture      : [opt] string - filename for focus texture.
#buttonFocusTexture : [opt] string - filename for no focus texture.

    self.strActionInfo = xbmcgui.ControlLabel(250, 80, 200, 200, 'font14', '0xFFBBBBFF')
    self.addControl(self.strActionInfo)
    self.strActionInfo.setLabel('Push BACK to quit')
    self.list = xbmcgui.ControlList(200, 150, 300, 400)
    self.addControl(self.list)
    for j in range(1,20):
        self.list.addItem('Item %s' % str(j))
    self.setFocus(self.list)
 
  def onAction(self, action):
    if action == ACTION_PREVIOUS_MENU:
      self.close()
 
  def onControl(self, control):
    if control == self.list:
      item = self.list.getSelectedItem()
      self.message('You selected : ' + item.getLabel())  
 
  def message(self, message):
    dialog = xbmcgui.Dialog()
    dialog.ok(" My message title", message)
 
def go():
    mydisplay = MyClass()
    mydisplay.doModal()
    del mydisplay