#
#      Copyright (C) 2012 Tommy Winther
#      http://tommy.winther.nu
#
#       Modified on behalf of TVCatchup
#       by Chris Grove (tvc@killergerbils.co.uk)
#       and Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import buggalo
import xbmcaddon

import notification
import source 
import os

import datetime 

import check

try:  
    check.delete()

    ADDON       = xbmcaddon.Addon(id = 'script.tvcatchup')
    profilePath = xbmc.translatePath(ADDON.getAddonInfo('profile'))

    if ADDON.getSetting('notifications.enabled') == 'true':        
        try:                     
            n = notification.Notification()
            n.scheduleNotifications()

            del n
        except Exception:
            xbmc.log('[script.tvcatchup] Unable to schedules notifications!', xbmc.LOGDEBUG)

    refreshFile = int(ADDON.getSetting('dayCheck')) + 1

    try:
       mtime      = int(os.path.getmtime(os.path.join(profilePath, 'data.xml')))
       updateFile = datetime.datetime.fromtimestamp(mtime)
    except:
       updateFile = datetime.datetime.today() - datetime.timedelta(days = refreshFile)

    wasPlaying = False
    delta      = updateFile - datetime.datetime.today()
    days       = delta.days
    secs       = (days * 86400) + delta.seconds
    mins       = secs / 60

    addonPath = ADDON.getAddonInfo('path')
    name      = 'HouseKeeping'
    script    = os.path.join(addonPath, 'house_keeping.py')
    version   = 3
    args      = str(-mins) + ',' + str(wasPlaying) + ',' + str(version)
    cmd       = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (name.encode('utf-8', 'replace'), script.encode('utf-8', 'replace'), args.encode('utf-8', 'replace'), 0)     

    xbmc.executebuiltin(cmd)

    if ADDON.getSetting('autoStart') == "true":
        xbmc.executebuiltin('RunScript(%s)' % os.path.join(addonPath, 'addon.py'))

except Exception:
    buggalo.onExceptionRaised()

