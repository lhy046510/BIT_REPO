#
#      Copyright (C) 2012 Tommy Winther
#      http://tommy.winther.nu
#
#      Modified on behalf of TVCatchup
#      by Chris Grove (tvc@killergerbils.co.uk)
#      and Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import datetime
import time
import os
import xbmc
import xbmcgui
import xbmcaddon

from strings import *
from sqlite3 import dbapi2 as sqlite3

import source

class Notification(object):
    NOTIFICATION_DB = 'notification.db'

    def __init__(self):
        self.source = source.XMLTVSource() 

        ADDON          = xbmcaddon.Addon(id = 'script.tvcatchup')
        profilePath    = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        self.addonPath = xbmc.translatePath(ADDON.getAddonInfo('path'))

        self.conn = sqlite3.connect(os.path.join(profilePath, self.NOTIFICATION_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False)
        self._createTables()
        
        self.channels  = None

    def __del__(self):
        self.conn.close()

    def createAlarmClockName(self, program):
        return 'tvguide-%s-%s' % (program.channel.id, program.startDate)

    def parseDate(self, dateString):
        if type(dateString) in [str, unicode]:            
            dt = dateString.split(' ')
            d  = dt[0]
            t  = dt[1]
            ds = d.split('-')
            ts = t.split(':')
            return datetime.datetime(int(ds[0]), int(ds[1]) ,int(ds[2]), int(ts[0]), int(ts[1]), int(ts[2]))

        return dateString

    def removeOld(self):
        now  = datetime.datetime.now()
        when = now - datetime.timedelta(hours = 48)

        c = self.conn.cursor()
        c.execute("DELETE FROM notification WHERE start < ?", [when])
        self.conn.commit()
        c.close()
          

    def scheduleNotifications(self):    
       xbmc.log("[script.tvcatchup] Scheduling program notifications")

       try:
           self.removeOld()                       
           self.channels = self.source.getChannelList()

           programs = self.getPrograms()
           for index in range(0, len(programs)): 
               channelId    = programs[index][0]
               programTitle = programs[index][1]
               startDate    = programs[index][2]
               emailed      = programs[index][3]
               if emailed == None:
                   emailed = 0
               self._processSingleNotification(channelId, programTitle, startDate, emailed == 1, self._scheduleNotification)

           dayCheck = int(xbmcaddon.Addon(id = 'script.tvcatchup').getSetting('dayCheck')) + 1

           series = self.getSeries()       
           for channelId, programTitle in series:
               now = datetime.datetime.now()
               end = now + datetime.timedelta(hours = 24*dayCheck)
               for channel in self.channels:
                   if channel.id == channelId:
                       for p in self.source.getProgramList(channel, now, end): 
                           if p.title == programTitle:
                               self.addProgram(p)
                       break

           xbmc.log("[script.tvcatchup] Scheduling program notifications...Done")

       except:
           xbmc.log("[script.tvcatchup] Error during scheduling program notifications", xbmc.LOGDEBUG)          
       

    def _processSingleNotification(self, channelId, programTitle, startDate, emailed, action):
        dayCheck = int(xbmcaddon.Addon(id = 'script.tvcatchup').getSetting('dayCheck')) + 1
        theRange = range(-1, dayCheck+1)

        start = self.parseDate(startDate)
        now   = datetime.datetime.now()
        end   = now + datetime.timedelta(hours = 24*dayCheck)
        
        if self.channels == None:
            self.channels = self.source.getChannelList()        

        for channel in self.channels:
            if channelId == channel.id:
                for program in self.source.getProgramList(channel, now, end):
                    if programTitle == program.title:                        
                        if start == program.startDate: 
                            if self._timeToNotification(program).days in theRange:#[-1, 0, 1]:                                   
                                action(program, channel, emailed)
                                return                                                         


    def _scheduleNotification(self, program, channel, emailed):
        if ADDON.getSetting('email') == 'true' and not emailed:
            self._scheduleEmail(program)

        if ADDON.getSetting('watch_prompt') == 'true':
            self._scheduleDialog(program)
            return

        t = self._timeToNotification(program)
        timeToNotification = ((t.days * 86400) + t.seconds) / 60        
        
        if timeToNotification < 0:
            #check if program is actually on now            
            if (program.endDate - datetime.datetime.now()).days < 0:
                return
                           
        name = self.createAlarmClockName(program)
        #cancel alarm first just in case it already exists
        xbmc.executebuiltin('CancelAlarm(%s,True)' % name)        

        xbmc.log("[script.tvcatchup] Alarm notification created for " + program.title + " at " + str(program.startDate))
        
        preNotify = ADDON.getSetting('pre_notify')
        if preNotify   == "0" : preNotify = 1
        elif preNotify == "1" : preNotify = 2
        elif preNotify == "2" : preNotify = 5
        elif preNotify == "3" : preNotify = 10
        elif preNotify == "4" : preNotify = 15
        elif preNotify == "5" : preNotify = 30
        
        notifyLength = ADDON.getSetting('notify_length')
        if notifyLength   == "0" : notifyLength = 5000
        elif notifyLength == "1" : notifyLength = 10000
        elif notifyLength == "2" : notifyLength = 15000
        elif notifyLength == "3" : notifyLength = 20000
        elif notifyLength == "4" : notifyLength = 30000
        elif notifyLength == "5" : notifyLength = 60000
        
        description = strings(NOTIFICATION_TEMPLATE, program.channel.title)                
        startsIn    = self._timeToNotification(program).seconds
        if startsIn / 60 > preNotify:
            startsIn = preNotify * 60
        
        if timeToNotification < 0:
            text = "now..."
        elif startsIn <= 60:
            text = "in " + str(startsIn) + " seconds(s)..."
        else:
            text = "in " + str((startsIn) /60) + " minute(s)..."
        
        description = description + text
                
        xbmc.executebuiltin('AlarmClock(%s,Notification(%s,%s,%s,%s),%d,True)' %
            (name.encode('utf-8', 'replace'), program.title.encode('utf-8', 'replace'), description.encode('utf-8', 'replace'), notifyLength, channel.logo.replace('long_logo','square_logo'), timeToNotification - preNotify))


    def _unscheduleNotification(self, program, channel, emailed):
        name = self.createAlarmClockName(program)
        xbmc.executebuiltin('CancelAlarm(%s,True)' % name)

        self._unscheduleEmail(program)
        self._unscheduleDialog(program)


    def _timeToNotification(self, program):
        return program.startDate - datetime.datetime.now()

    def addProgram(self, program):
        """
        @type program: source.program
        """
        c = self.conn.cursor()
        c.execute("INSERT OR REPLACE INTO notification(channel, program, start, emailed) VALUES(?, ?, ?, ?)", [program.channel.id, program.title, program.startDate, False])
        self.conn.commit()
        c.close()

        self._processSingleNotification(program.channel.id, program.title, program.startDate, False, self._scheduleNotification)
        
    def addSeries(self, program):
        """
        @type program: source.program
        """
        c = self.conn.cursor()
        c.execute("INSERT OR REPLACE INTO series(channel, program) VALUES(?, ?)", [program.channel.id, program.title])
        self.conn.commit()
        c.close()
        
        if self.channels == None:
            self.channels = self.source.getChannelList()
        
        now = datetime.datetime.now()
        end = now + datetime.timedelta(hours = 36)
        for channel in self.channels:
            if channel.id == program.channel.id:                
                for p in self.source.getProgramList(channel, now, end):
                    if p.title == program.title:
                        self.addProgram(p)
                return            

        #self._processSingleNotification(program.channel.id, program.title, None, self._scheduleNotification)

    def delProgram(self, program):
        """
        @type program: source.program
        """
        c = self.conn.cursor()
        c.execute("DELETE FROM notification WHERE channel=? AND program=? AND start=?", [program.channel.id, program.title, program.startDate])
        self.conn.commit()
        c.close()                

        self._processSingleNotification(program.channel.id, program.title, program.startDate, False, self._unscheduleNotification)
        
    def delSeries(self, program):
        """
        @type program: source.program
        """
        c = self.conn.cursor()
        c.execute("DELETE FROM series WHERE channel=? AND program=?", [program.channel.id, program.title])
        self.conn.commit()
        c.close()
        
        if self.channels == None:
            self.channels = self.source.getChannelList()
        
        now = datetime.datetime.now()
        end = now + datetime.timedelta(hours = 36)
        for channel in self.channels:
            if channel.id == program.channel.id:                
                for p in self.source.getProgramList(channel, now, end):
                    if p.title == program.title:
                        self.delProgram(p)

        #self._processSingleNotification(program.channel.id, program.title, None, self._unscheduleNotification)


    def getPrograms(self):
       c = self.conn.cursor()
       c.execute("SELECT DISTINCT channel, program, start, emailed FROM notification")
       programs = c.fetchall()
       c.close()
       return programs

    def getSeries(self):
       c = self.conn.cursor()
       c.execute("SELECT DISTINCT channel, program FROM series")
       series = c.fetchall()
       c.close()
       return series

    def isNotificationRequiredForProgram(self, program):
        """
        @type program: source.program
        """
        c = self.conn.cursor()
        c.execute("SELECT 1 FROM notification WHERE channel=? AND program=? AND start=?", [program.channel.id, program.title, program.startDate])
        result = c.fetchone()
        c.close()
        return result
        
    def isNotificationRequiredForSeries(self, program):
        """
        @type program: source.program
        """
        c = self.conn.cursor()
        c.execute("SELECT 1 FROM series WHERE channel=? AND program=?", [program.channel.id, program.title])
        result = c.fetchone()
        c.close()
        return result

    def clearAllNotifications(self):
        c = self.conn.cursor()
        c.execute('DELETE FROM notification')
        c.execute('DELETE FROM series')
        self.conn.commit()
        c.close()
        
    def _createTables(self):
        c = self.conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS notification (channel TEXT, program TEXT, start DATETIME)")
        c.execute("CREATE TABLE IF NOT EXISTS series       (channel TEXT, program TEXT)")
        try:
            c.execute("ALTER TABLE notification add column 'emailed' 'BOOLEAN'")
        except:
            pass
        c.close()
        
    def _scheduleDialog(self, program):        
        #in case it is already set
        self._unscheduleDialog(program)

        t = self._timeToNotification(program)
        timeToNotification = (t.days * 86400) + t.seconds
        now = datetime.datetime.now()
        startPadding = 30#seconds before program actually starts
        timeToNotification = timeToNotification - startPadding
        label = 'is about to start.'

        if timeToNotification < 0:
            #check if program is actually on now
            if (program.endDate - now).days < 0:
                return
            else:
                label              = 'has started.'
                timeToNotification = 0
                startDate          = now
        else:
            startDate = program.startDate - datetime.timedelta(seconds = startPadding)
            #modify startDate if necessary; it shouldn't be earlier that 'now'
            if startDate < now:
                startDate = now

        xbmc.log('[script.tvcatchup] Dialog created for %s (%s) at %s' % (program.title, str(program.startDate), str(startDate)))

        name   = self.createAlarmClockName(program)+' Dialog'
        script = os.path.join(self.addonPath, 'dialog.py')
        args   = program.title + ',' + str(program.channel.id) + ',' + label

        #not too sure whether timeToNotification/60 will be accurate enough
        xbmc.executebuiltin('AlarmClock(%s,RunScript(%s,%s),%d,True)' %
            (name.encode('utf-8', 'replace'), script.encode('utf-8', 'replace'), args.encode('utf-8', 'replace'), timeToNotification/60))

    def _unscheduleDialog(self, program):
        name = self.createAlarmClockName(program)+' Dialog'
        xbmc.executebuiltin('CancelAlarm(%s,True)' % name)

    def _scheduleEmail(self, program):        
        #in case it is already set
        self._unscheduleEmail(program)

        preNotify = ADDON.getSetting('email.time')
        if preNotify   == "0" : preNotify = 1  * 60
        elif preNotify == "1" : preNotify = 2  * 60
        elif preNotify == "2" : preNotify = 5  * 60
        elif preNotify == "3" : preNotify = 10 * 60
        elif preNotify == "4" : preNotify = 15 * 60
        elif preNotify == "5" : preNotify = 30 * 60
        t = self._timeToNotification(program)
        timeToNotification = (t.days * 86400) + t.seconds
        now                = datetime.datetime.now()
        timeToNotification = timeToNotification - preNotify

        if timeToNotification < 0:
            #check if program is actually on now
            if (program.endDate - now).days < 0:
                return
            else:
                timeToNotification = 0
                startDate          = now
        else:
            startDate = program.startDate - datetime.timedelta(seconds = preNotify)
            #modify startDate if necessary; it shouldn't be earlier that 'now'
            if startDate < now:
                startDate = now

        xbmc.log('[script.tvcatchup] Email notification created for %s (%s) at %s' % (program.title, str(program.startDate), str(startDate)))

        name   = self.createAlarmClockName(program)+' Email'
        script = os.path.join(self.addonPath, 'emailNotify.py')  
        args   = program.title + ',' + str(program.channel.id) + ',' + str(program.startDate)

        #not too sure whether timeToNotification/60 will be accurate enough
        xbmc.executebuiltin('AlarmClock(%s,RunScript(%s,%s),%d,True)' %
            (name.encode('utf-8', 'replace'), script.encode('utf-8', 'replace'), args.encode('utf-8', 'replace'), timeToNotification/60))

    def _unscheduleEmail(self, program):
        name = self.createAlarmClockName(program)+' Email'
        xbmc.executebuiltin('CancelAlarm(%s,True)' % name)

if __name__ == '__main__':
    n = Notification(None, ADDON.getAddonInfo('path'), dataPath)
    n.clearAllNotifications()
    xbmcgui.Dialog().ok(strings(CLEAR_NOTIFICATIONS), strings(DONE))
