#       Copyright (C) 2012 
#       Written on behalf of TVCatchup
#       by Chris Grove (tvc@killergerbils.co.uk)
#       and Sean Poyser (seanpoyser@gmail.com)
#

from source import Channel

import xbmcgui
import xbmcaddon
import sys
import datetime

from osd             import OSD
from help            import HelpMenu
from info            import InfoWindow
from player          import TVCPlayer
from sqlite3         import dbapi2 as sqlite3
from channel_changer import ChannelChanger

def action(key):

    if xbmcgui.Window(10000).getProperty("TVCatchup_EPG_Running") != "True":
        return

    if not key in ['SELECT', 'PGUP', 'PGDOWN', 'UP', 'DOWN', 'LEFT', 'RIGHT', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'X', 'H', 'I']:
        return

    if xbmcgui.Window(10000).getProperty("TVCatchup_Script") == "Running":
        return

    xbmcgui.Window(10000).setProperty("TVCatchup_Script", "Running")


    if key in ['UP', 'DOWN', 'LEFT', 'RIGHT']:
        osd = OSD()
        osd.doModal()     
        del osd
        return


    if key == "H":
        helpscreen = HelpMenu()
        helpscreen.doModal()     
        del helpscreen
        return

    
    if key == 'X':
        xbmc.Player().stop()
        return

    ADDON = xbmcaddon.Addon(id = 'script.tvcatchup')


    if key == 'SELECT':
        key     = ADDON.getSetting('c1')
        channel = ChannelChanger(key)
        channel.doModal()     
        del channel
        return


    if key in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']:
        channel = ChannelChanger(key)
        channel.doModal()     
        del channel
        return

    
    SOURCE_DB = 'guide1.db'
    dbPath    = xbmc.translatePath(ADDON.getAddonInfo('profile'))    

    fullList    = []
    channelList = []

    conn             = sqlite3.connect(os.path.join(dbPath, SOURCE_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False)
    conn.row_factory = sqlite3.Row
    
    c = conn.cursor()        
    c.execute("SELECT id, title FROM channels")        
        
    for row in c:            
        fullList.append(Channel(row["id"], row["title"]))    
            
    c.close() 

    id = xbmcgui.Window(10000).getProperty("TVCatchup_Channel")
    if id == "":
        id = "0"

    index = -1

    #remove channels not enabled in settings
    for chn in fullList:
        if ADDON.getSetting('channel_' + chn.id) == "true":
            channelList.append(chn) 
            if chn.id == id:
                index = len(channelList)-1

    maxChannel = len(channelList)-1

    if key == 'I':
        channel = channelList[index]
        program = None
        now     = datetime.datetime.now()
        c       = conn.cursor()
        c.execute('SELECT * FROM programs WHERE channel=? AND startDate <= ? AND endDate >= ? LIMIT 1', [channel.id, now, now])
        row = c.fetchone()
        c.close()
        if row:        
            infowindow = InfoWindow(row["id"])
            infowindow.doModal()     
            del infowindow
        return

    try:   
        index = int(key) - 1 #'-1' because array is zero based
        if index < 0 or index > 8:
            return

        #are we already on this channel
        chn = channelList[index]
        if chn.id == id:
            return       
    except:
        pass

    if key == "PGUP":
        index = index + 1
    if key == "PGDOWN":
        index = index - 1

    if index < 0:
        index = maxChannel 
    if index > maxChannel:
        index = 0
   
    #xbmcgui.Window(10000).clearProperty("TVCatchup_Script")
        
    TVCPlayer().playStream(channelList[index], notify = True) 


action(sys.argv[1].upper())
xbmcgui.Window(10000).clearProperty("TVCatchup_Script")
