#       Copyright (C) 2012 
#       Written on behalf of TVCatchup
#       by Chris Grove (tvc@killergerbils.co.uk)
#       and Sean Poyser (seanpoyser@gmail.com)
#

import os
import xbmc
import xbmcgui
import xbmcaddon


def keymap():
    ADDON = xbmcaddon.Addon(id = 'script.tvcatchup')

    #ensure keymap file exists   
    keyboardDst = os.path.join(xbmc.translatePath('special://userdata/keymaps'), "tvcatchup.xml")
    if not os.path.exists(keyboardDst):
        addonPath   = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        keyboardSrc = os.path.join(addonPath, "tvcatchup.xml")
     
        if not os.path.exists(keyboardSrc):  
            addonPath   = xbmc.translatePath(ADDON.getAddonInfo('path'))
            keyboardSrc = os.path.join(addonPath, "tvcatchup.xml")

        f = open(keyboardSrc, mode='r')
        t = f.read()
        f.close()

        try:
            f = open(keyboardDst, mode='w')
            f.write(t)
            f.close()
        except:
            #problem writing file so just return
            return


        while not os.path.exists(keyboardDst):  
            f = open(keyboardDst, mode='w')
            f.write(t)
            f.close()

        xbmc.sleep(1000)
        xbmc.executebuiltin('Action(reloadkeymaps)')                

def script():
    pass
    
      
def delete():
    #delete keymap file
    keyboardDst = os.path.join(xbmc.translatePath('special://userdata/keymaps'), "tvcatchup.xml")
    while os.path.exists(keyboardDst): 
        try: 
            os.remove(keyboardDst) 
            break 
        except: 
            pass 

    xbmc.sleep(1000)                                
    xbmc.executebuiltin('Action(reloadkeymaps)')                
                 
