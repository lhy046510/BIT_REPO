#       Copyright (C) 2012 
#       Written on behalf of TVCatchup
#       by Chris Grove (tvc@killergerbils.co.uk)
#       and Sean Poyser (seanpoyser@gmail.com)
#

import xbmc
import xbmcgui
import xbmcaddon
import buggalo
import os

KEY_NAV_BACK = 92
KEY_ESC_ID   = 10
KEY_ESC_CODE = 61467

ACTION_BACK          = 92
ACTION_PARENT_DIR    = 9
ACTION_PREVIOUS_MENU = 10

ADDON = xbmcaddon.Addon(id = 'script.tvcatchup')

THEME = ADDON.getSetting('skin')

xmlfile = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')), 'resources', 'skins',  'Default', '720p', THEME + '-script-tvcatchup-help.xml')
if not os.path.exists(xmlfile):
    PREFIX = ""
else:
    PREFIX = THEME + '-'

class HelpMenu(xbmcgui.WindowXMLDialog):
    C_HELP_CANCEL       = 6001
    C_HELP_TEXT_KEYS    = 6003
    C_HELP_TEXT_ACTIONS = 6004

    def __new__(cls):
        return super(HelpMenu, cls).__new__(cls, PREFIX + 'script-tvcatchup-help.xml', ADDON.getAddonInfo('path'))
        
    def __init__(self):
        super(HelpMenu, self).__init__()
        self.buttonClicked = None
        self.ATV2  = xbmc.getCondVisibility("System.Platform.ATV2") == 1
        self.IOS   = xbmc.getCondVisibility("System.Platform.IOS")  == 1
        
    def onInit(self):
        try:
            cancelControl = self.getControl(self.C_HELP_CANCEL)
            if self.IOS == True:
                if self.ATV2 == True:
                    f = open(ADDON.getAddonInfo('path') + os.sep + 'atvhelp.txt','r')
                else:
                    f = open(ADDON.getAddonInfo('path') + os.sep + 'ioshelp.txt','r')
            else:
                f = open(ADDON.getAddonInfo('path') + os.sep + 'help.txt','r')
            helpTextlines = f.readlines()
            f.close()

            keyText    = ''
            actionText = ''

            for text in helpTextlines:
                text = text.rsplit('-', 1)
                if len(text) == 2:
                    keyText    = keyText    + text[0] + '\n'
                    actionText = actionText + text[1]
                else:
                    keyText    = keyText    + '\n'
                    actionText = actionText + text[0]

            self.setControlText(self.C_HELP_TEXT_KEYS,    keyText)
            self.setControlText(self.C_HELP_TEXT_ACTIONS, actionText)

        except Exception:
            raise
            #buggalo.onExceptionRaised()

    def setControlText(self, controlId, text):
        control = self.getControl(controlId)
        if control:
            control.setText(text)

    def onAction(self, action):
        try:
            if action.getId() in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, KEY_NAV_BACK, ACTION_BACK, KEY_ESC_ID]:
                self.close()
                return
        except Exception:
            buggalo.onExceptionRaised()

    def onClick(self, controlId):
        try:            
            self.buttonClicked = controlId
            self.close()
        except Exception:
            buggalo.onExceptionRaised()

    def onFocus(self, controlId):
        pass

if __name__ == '__main__':
    helpscreen = HelpMenu()
    helpscreen.doModal()     
    del helpscreen
