#
#      Copyright (C) 2012
#      Written on behalf of TVCatchup
#      by Chris Grove (tvc@killergerbils.co.uk)
#      and Sean Poyser (seanpoyser@gmail.com)
#      
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import xbmcaddon
import xbmc
import xbmcgui
import os
import sys

import TVC
import tv_grab_uk_rt_aps
import notification
import source

from strings import *

import dialogue

def download_data(showProgress = True):
    try:
        if xbmcgui.Window(10000).getProperty("TVCatchup_EPG_Downloading") == "True":
            return True    

        path    = xbmc.translatePath(ADDON.getAddonInfo('path'))
        profile = xbmc.translatePath(ADDON.getAddonInfo('profile'))

        xbmc.sleep(100) #just to make sure settings are up to date
        show = xbmcaddon.Addon(id = 'script.tvcatchup').getSetting('show_license') == 'true'
        xbmcaddon.Addon(id = 'script.tvcatchup').setSetting('show_license', 'false')

        if show:
            dialogue.doOK('TVCatchup & Radio Times Listings', ['All data downloaded with the Radio Times grabber is copyright of the RT website (http://www.radiotimes.com).', 'The use of the data is restricted to personal use only.', 'Also be aware that this service may not remain free and in future may become a paid-for service.'])                                    
        xmlTvFile = os.path.join(profile, 'data.xml')
        
        xbmc.log("[script.tvcatchup] Getting XMLTV Listings")
        #TVC.CheckRegion()

        xbmcgui.Window(10000).setProperty("TVCatchup_EPG_Downloading", "True")

        success = tv_grab_uk_rt_aps.GetListingsData(xmlTvFile, showProgress)

        xbmcgui.Window(10000).clearProperty("TVCatchup_EPG_Downloading")

        if not success:
            return False
                           
        xbmc.log('[script.tvcatchup] New XMLTV Data Retrieved')       
       
        if xbmcaddon.Addon(id = 'script.tvcatchup').getSetting('notifications.enabled') == 'true':
            notification.Notification().scheduleNotifications()
        
    except:
        xbmcgui.Window(10000).clearProperty("TVCatchup_EPG_Downloading")
        xbmc.log('[script.tvcatchup] Caught exception while downloading data!', xbmc.LOGDEBUG)
        return False

    return True

if __name__ == '__main__':
    if download_data():
        dialogue.doOK('TVCatchup', ['', 'EPG data successfully downloaded.'])
    xbmcaddon.Addon(id = 'script.tvcatchup').openSettings()       
