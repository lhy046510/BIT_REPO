#       Copyright (C) 2012 
#       Written on behalf of TVCatchup
#       by Chris Grove (tvc@killergerbils.co.uk)
#       and Sean Poyser (seanpoyser@gmail.com)
#

import urllib2,urllib
import datetime
import base64
import xbmcaddon
import xbmcgui
import xbmc
import os
import re
import platform
from xml.etree import ElementTree

import dialogue

fuscat1=xbmcaddon.Addon(id='script.tvcatchup')

def mroftap():
 if hasattr(os, 'uname'):
  (sysname, nodename, release, version, machine) = os.uname()
 else:
  (sysname, nodename, release, version, machine, processor) = platform.uname()
 if sysname == "Windows" or sysname == "windows" :
    if release == "post2008Server" :
        return "Windows 8"
    else:
        return sysname + " " + release
 if sysname == "Linux" or sysname == "linux" : return sysname + " " + nodename
 if sysname == "Darwin" or sysname == "darwin" : return sysname + " " + nodename

def Niswanob1(ordemo2):
 fuscat2=ord(ordemo2)
 return fuscat2

OW9Gb39WYWZ8ejs = mroftap()

def fuscat3(bitboostdotcom1):
 bitboostdotcom2=chr(bitboostdotcom1)
 return bitboostdotcom2

def fuscat4(ordemo3):
 bitboostdotcom3=len(ordemo3)
 return bitboostdotcom3

def Chri3(Chri2,ordemo4):
 Niswanob2=int(Chri2,ordemo4)
 return Niswanob2

def bitboostdotcom5(Chri4,Niswanob3):
 bitboostdotcom4=''
 ordemo5=0
 Niswanob4=base64.b64decode(Chri4)
 Chri5=[Chri6 for Chri6 in       Niswanob4 if (Chri6!='\n') ]
 fuscat5=[Chri6 for Chri6 in       Niswanob3 if (Chri6!='\n') ]
 for Niswanob5 in range(0,fuscat4(Chri5),16):
  for Niswanob6 in range(0,8):
   if ((ordemo5 + Chri3(fuscat5[Niswanob6],16))<=fuscat4(Chri5)):
    bitboostdotcom4=(bitboostdotcom4 + fuscat3((Niswanob1(Chri5[(ordemo5 + Chri3(fuscat5[Niswanob6],16))]) - Chri3(fuscat5[(Niswanob6 + 8)],16))))


  ordemo5=(ordemo5 + 16)

 return bitboostdotcom4.rstrip(' ')

def fuscat7(Chri7,Chri8):
 if (Chri8==1):
  fuscat6='ba98763223b38343'
 elif (Chri8==2):
  fuscat6='d37e194813579bdf'
 elif (Chri8==3):
  fuscat6='38a7629b43303002'
 elif (Chri8==4):
  fuscat6='38d762ce433833b2'

 ordemo7=bitboostdotcom5(Chri7,fuscat6)
 return ordemo7

YV5SWko3TFtIa05NWVUiaQ=fuscat1.getAddonInfo(fuscat7('elhvenl1bHNobnUiUUsiNA==',3))

def bitboostdotcom7():
 today=datetime.datetime.today()
 ordemo8=today.strftime('%d')
 Chri9=today.strftime('%m')
 ChriA=today.strftime('%y')
 Niswanob7=today.strftime('%H')
 bitboostdotcom6=today.strftime('%M')
 Niswanob8=''
 Niswanob8=(Niswanob8 + ordemo8)
 Niswanob8=(Niswanob8 + fuscat3((Chri3(ordemo8,10) + 64)))
 Niswanob8=(Niswanob8 + fuscat3(((Chri3(ordemo8,10)*    2) + 64)))
 Niswanob8=(Niswanob8 + Chri9)
 Niswanob8=(Niswanob8 + fuscat3((Chri3(Chri9,10) + 64)))
 Niswanob8=(Niswanob8 + fuscat3(((Chri3(Chri9,10)*    2) + 64)))
 Niswanob8=(Niswanob8 + ChriA)
 Niswanob8=(Niswanob8 + fuscat3((Chri3(ChriA,10) + 64)))
 Niswanob8=(Niswanob8 + fuscat3(((Chri3(ChriA,10)*    2) + 64)))
 Niswanob8=(Niswanob8 + Niswanob7)
 Niswanob8=(Niswanob8 + fuscat3((Chri3(Niswanob7,10) + 64)))
 Niswanob8=(Niswanob8 + fuscat3(((Chri3(Niswanob7,10)*    2) + 64)))
 return base64.b64encode(Niswanob8)

def loadTVCXml():
 NiswanobA=bitboostdotcom7()
 AbitboostdotcomA=[(fuscat7('eilydi0tOWovKzkpK3Z5OA==',2),fuscat1.getSetting(fuscat7('JyFxdjFnaHt4bnl2bXJSUmpsIyRvSyMoI3BwY2hLOnc=',1))),(fuscat7('bjAjdFZlI3tkND85K3YiWA==',4),fuscat1.getSetting(fuscat7('ZEZzeG9aZHB5c2Z5d1s+QE91IHMvYiMgdSBnIndZXGg=',3))),(fuscat7('WGAjZzhndnZrO1kwK2QiVQ==',4),fuscat7('TjwgZy5FI25rIGQiIndmMQ==',3)),(fuscat7('KCYjfT1BaHN2fmRybFxZeQ==',1),NiswanobA),(fuscat7('JDtvei9lbHNobnUiUUA/Yg==',3),YV5SWko3TFtIa05NWVUiaQ),(fuscat7('OW9Gb39WYWZ8ejs+cHF7N0MpOyMtTS0lLysqQDIhJy0=',2),OW9Gb39WYWZ8ejs)]
 AbitboostdotcomA=urllib.urlencode(AbitboostdotcomA)
 bitboostdotcomA=fuscat7('OmAvbEh5PXB3L3dyL0AiWVtGc3A5VnFpeC5qdlhXRkwzYmh6RiJmdGZ1ZHIlTSs0TU9+Mm5EMm1meHJkbTVacDdqbXFUeWV4ZmMyZyVDW1M+Q2h0Z1VzLmpwNSJvbzFI',3)
 req=urllib2.Request(bitboostdotcomA, AbitboostdotcomA)
 req.add_header("Content-type", "application/x-www-form-urlencoded")
 bitboostdotcom8=urllib2.urlopen(req).read()
 IiII1I1Tit = re.compile('<div style="background: red; padding: 10px; color: #FFFFFF">(.+?)</div>').findall(bitboostdotcom8)
 if len(IiII1I1Tit) <> 0:
  dialogue.doOK('TVCatchup', ['', 'Listings Download Error', IiII1I1Tit[0]])
  xbmc.log('script.tvcatchup - Plugin halted. '+IiII1I1Tit[0]+' http://plugins.tvcatchup.com/~xbmc/')
  exit()
 else:
  try:
   ret = ElementTree.fromstring(bitboostdotcom8)
  except:
   dialogue.doOK('TVCatchup', ['', 'XMLTV Location Issue', 'Please check you Location\Time Zone settings'])
   xbmc.log('[script.tvcatchup] - XMLTV Location Issue Tripped')
   xbmc.log('script.tvcatchup ' + bitboostdotcom8)
   exit()
  if ret <> None:
   return ret
  else:
   dialogue.doOK('TVCatchup', ['', 'Listings Download Error', 'Please check your settings and try again.'])
   xbmc.log('[script.tvcatchup] - Plugin halted due to the XML being empty. Check you can connect to http://plugins.tvcatchup.com/~xbmc/')
   exit()

def getMissingNow(bitboostdotcom6):
 bitboostdotcom9=None
 NiswanobA=bitboostdotcom7()
 AbitboostdotcomA=[(fuscat7('KCYjfT1BaHN2fmRybFxZeQ==',1),NiswanobA),(fuscat7('NGcjJGIiIyh1cHZ3U05ubw==',1),(fuscat1.getSetting(fuscat7('QmZxdngnaHt4bnl2OC0qOnRYIyQnOyMoI3BwY04hMEk=',1)))),(fuscat7('XlN4cmhXaG5ydHoiIT1OSw==',3),fuscat7('IylMci1VK3wvK3ckWG8nNQ==',2)),(fuscat7('a3c+a3liKWYvcElWO2R1Zw==',2),bitboostdotcom6),(fuscat7('JDtvei9lbHNobnUiUUA/Yg==',3),YV5SWko3TFtIa05NWVUiaQ),(fuscat7('OW9Gb39WYWZ8ejs+cHF7N0MpOyMtTS0lLysqQDIhJy0=',2),OW9Gb39WYWZ8ejs)]
 AbitboostdotcomA=urllib.urlencode(AbitboostdotcomA)
 ordemo9=fuscat7('ckwvbEx3PXB3L3dyTz0kVnI9c3BgTnFpeC5qdlNWczxtNWh6JDhmdGZ1ZHI4ZFVMemN+Ml4nMm1meHJkOFUtbzJIbXE2VWV4ZmMyZ3VuQEhlSWh0U2NzLmpwNSJpN0M+',3)
 req=urllib2.Request(ordemo9, AbitboostdotcomA)
 req.add_header("Content-type", "application/x-www-form-urlencoded")
 bitboostdotcom8=urllib2.urlopen(req).read()
 IiII1I1Tit = re.compile('<title>(.+?)</title>').findall(bitboostdotcom8)
 IiII1I1Sta = re.compile('<start>(.+?)</start>').findall(bitboostdotcom8)
 IiII1I1End = re.compile('<end>(.+?)</end>').findall(bitboostdotcom8)
 bitboostdotcom9=[IiII1I1Tit[0],IiII1I1Sta[0],IiII1I1End[0]]
 return bitboostdotcom9

def getMissingNext(bitboostdotcom6):
 NiswanobA=bitboostdotcom7()
 AbitboostdotcomA=[(fuscat7('KCYjfT1BaHN2fmRybFxZeQ==',1),NiswanobA),(fuscat7('NGcjJGIiIyh1cHZ3U05ubw==',1),(fuscat1.getSetting(fuscat7('QmZxdngnaHt4bnl2OC0qOnRYIyQnOyMoI3BwY04hMEk=',1)))),(fuscat7('XlN4cmhXaG5ydHoiIT1OSw==',3),fuscat7('SUQjclF4I3xoMkMpK3siMg==',4)),(fuscat7('a3c+a3liKWYvcElWO2R1Zw==',2),bitboostdotcom6),(fuscat7('JDtvei9lbHNobnUiUUA/Yg==',3),YV5SWko3TFtIa05NWVUiaQ),(fuscat7('OW9Gb39WYWZ8ejs+cHF7N0MpOyMtTS0lLysqQDIhJy0=',2),OW9Gb39WYWZ8ejs)]
 AbitboostdotcomA=urllib.urlencode(AbitboostdotcomA)
 ordemo9=fuscat7('ckwvbEx3PXB3L3dyTz0kVnI9c3BgTnFpeC5qdlNWczxtNWh6JDhmdGZ1ZHI4ZFVMemN+Ml4nMm1meHJkOFUtbzJIbXE2VWV4ZmMyZ3VuQEhlSWh0U2NzLmpwNSJpN0M+',3)
 req=urllib2.Request(ordemo9, AbitboostdotcomA)
 req.add_header("Content-type", "application/x-www-form-urlencoded")
 bitboostdotcom8=urllib2.urlopen(req).read()
 IiII1I1Tit = re.compile('<title>(.+?)</title>').findall(bitboostdotcom8)
 IiII1I1Sta = re.compile('<start>(.+?)</start>').findall(bitboostdotcom8)
 IiII1I1End = re.compile('<end>(.+?)</end>').findall(bitboostdotcom8)
 bitboostdotcom9=[IiII1I1Tit[0],IiII1I1Sta[0],IiII1I1End[0]]
 return bitboostdotcom9

def getTVCStreamUrl(NiswanobB,fuscat8,fuscata):
 fuscat9=bitboostdotcom7()
 bitboostdotcomP = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
 bitboostdotcomP.clear()
 AbitboostdotcomA=[(fuscat7('djQjJGBDIyh1cHZ3b2g3JA==',1),fuscat1.getSetting(fuscat7('JyFxdjFnaHt4bnl2bXJSUmpsIyRvSyMoI3BwY2hLOnc=',1))),(fuscat7('RXYgdFAhI3NkIHYiVUZFWQ==',3),fuscat1.getSetting(fuscat7('b2pkeYAsaWiGfnAwenV3SFApdXUtVy9pLys1aDZwJ3U=',2))),(fuscat7('W1AgZ2EjI25rIGQiTFonWg==',3),fuscat8.id),(fuscat7('THgjfVdIaHN2fmRyXydbLQ==',1),fuscat9),(fuscat7('elhvenl1bHNobnUiUUsiNA==',3),YV5SWko3TFtIa05NWVUiaQ),(fuscat7('RSsjfUY4d3FvbHhzN1tdVA==',1),fuscat1.getSetting(fuscat7('Ilxfem1NcmVsc2d2LGNUclRHIHZKPiNtaCBkIic0JS0=',3))),(fuscat7('XmpEd3Y5Wnd9eERDM3RsLCF9cHNwczJ3fnolZ0JodixqKVQjLWwwJS8rIl1ObScn',2),fuscat1.getSetting(fuscat7('aEptd1xAZGV3aXVwZWZdP2lHdGtJcnJyYm9zZV13Vyd6bSBzaigjIG8gIyJCZ25J',3))),(fuscat7('OW9Gb39WYWZ8ejs+cHF7N0MpOyMtTS0lLysqQDIhJy0=',2),OW9Gb39WYWZ8ejs),(fuscat7('KCl5dzFRcGlofXd1QyMvT0srIyRkNyNsaIJoa2MjP14=',1),fuscat1.getSetting(fuscat7('bk9yUiY/aGJ4T3BocGdeQEdiIFRSMXZ5byBkIkYyX2k=',3)))]
 AbitboostdotcomA=urllib.urlencode(AbitboostdotcomA)
 bitboostdotcomA=fuscat7('UEMxdzxqRnmCOk5NQ2l3NjdsdWt6Ml5mf3o4bD5wdDpRfCN3f0cvaoVwVCtFdnkkPzddZnw4Smo9bklVPWp6WjpZQW48I140glRcX0h2SGRLbUxycjJjfIGBTzVFaUgndnlZMS0zSHUvK2BxTHVvbA==',2)
 req=urllib2.Request(bitboostdotcomA, AbitboostdotcomA)
 req.add_header("Content-type", "application/x-www-form-urlencoded")
 bitboostdotcomB=urllib2.urlopen(req).read()
 if bitboostdotcomB <> "":
  if bitboostdotcomB.startswith('rtmp://') or bitboostdotcomB.startswith('http://') == True:
   L = xbmcgui.ListItem (fuscat8.title)
   L.setThumbnailImage(fuscat8.logo.replace('long_logo','square_logo'))
   bitboostdotcomP.add(bitboostdotcomB,L)
 bitboostdotcomL = xbmcgui.ListItem (fuscat8.title)
 bitboostdotcomL.setThumbnailImage(fuscat8.logo.replace('long_logo','square_logo'))
 AbitboostdotcomA=[(fuscat7('djQjJGBDIyh1cHZ3b2g3JA==',1),fuscat1.getSetting(fuscat7('JyFxdjFnaHt4bnl2bXJSUmpsIyRvSyMoI3BwY2hLOnc=',1))),(fuscat7('RXYgdFAhI3NkIHYiVUZFWQ==',3),fuscat1.getSetting(fuscat7('b2pkeYAsaWiGfnAwenV3SFApdXUtVy9pLys1aDZwJ3U=',2))),(fuscat7('W1AgZ2EjI25rIGQiTFonWg==',3),fuscat8.id),(fuscat7('THgjfVdIaHN2fmRyXydbLQ==',1),fuscat9),(fuscat7('elhvenl1bHNobnUiUUsiNA==',3),YV5SWko3TFtIa05NWVUiaQ),(fuscat7('RSsjfUY4d3FvbHhzN1tdVA==',1),fuscat1.getSetting(fuscat7('Ilxfem1NcmVsc2d2LGNUclRHIHZKPiNtaCBkIic0JS0=',3))),(fuscat7('XmpEd3Y5Wnd9eERDM3RsLCF9cHNwczJ3fnolZ0JodixqKVQjLWwwJS8rIl1ObScn',2),fuscat1.getSetting(fuscat7('aEptd1xAZGV3aXVwZWZdP2lHdGtJcnJyYm9zZV13Vyd6bSBzaigjIG8gIyJCZ25J',3))),(fuscat7('OW9Gb39WYWZ8ejs+cHF7N0MpOyMtTS0lLysqQDIhJy0=',2),OW9Gb39WYWZ8ejs)]
 AbitboostdotcomA=urllib.urlencode(AbitboostdotcomA)
 bitboostdotcomA=fuscat7('O1dzM3lRMkJzf3dqOmoqMS4ydzJVdXZ2bHJ4bmEnXG1ucnN5dEtra3dsZngpZE4wQz9lfGwhgTdwemYweV5tVktkaGduZ3Bqezpmb1RsW1EvOCN0R2NreDE9anIxVlp0',1)
 req=urllib2.Request(bitboostdotcomA, AbitboostdotcomA)
 req.add_header("Content-type", "application/x-www-form-urlencoded")
 bitboostdotcomB=urllib2.urlopen(req).read()
 if bitboostdotcomB.startswith('rtmp://') or bitboostdotcomB.startswith('http://') == True:
  bitboostdotcomP.add(bitboostdotcomB, bitboostdotcomL)
  fuscat1.setSetting(fuscat7('bk9yUiY/aGJ4T3BocGdeQEdiIFRSMXZ5byBkIkYyX2k=',3), str(int(fuscata) + 1))
  return bitboostdotcomP, None

 errorCode=re.compile('>(.+?)</').findall(bitboostdotcomB)
 e='Unknown Error'
 if len(errorCode) > 0:
  e = errorCode[0]
 xbmc.log('[script.tvcatchup] - Playback Link failed. ' + e)
 return None, e

def ConvertToTVCChannels(ordemoC):
 xbmc.log('[script.tvcatchup] Converting XMLTV ident to TVC ident')
 AbitboostdotcomA=[(fuscat7('Kikldi1aXWovK08xZnZ5Yw==',2),fuscat1.getSetting(fuscat7('JyFxdjFnaHt4bnl2bXJSUmpsIyRvSyMoI3BwY2hLOnc=',1))),(fuscat7('ZSkjdEwwI3tkYG5nK3YiQA==',4),fuscat1.getSetting(fuscat7('b2pkeYAsaWiGfnAwenV3SFApdXUtVy9pLys1aDZwJ3U=',2))),(fuscat7('QClgeC1hWHMvK0xUaWdqZQ==',2),fuscat7('O2l1Z0pDaH5yVCtnf3EieQ==',4)),(fuscat7('QXdUa3lXVWYvcCUsWWR1LQ==',2),ordemoC),(fuscat7('TGhvenknbHNobnUiSVRhdg==',3),YV5SWko3TFtIa05NWVUiaQ),(fuscat7('OW9Gb39WYWZ8ejs+cHF7N0MpOyMtTS0lLysqQDIhJy0=',2),OW9Gb39WYWZ8ejs)]
 AbitboostdotcomA=urllib.urlencode(AbitboostdotcomA)
 bitboostdotcomA=fuscat7('UkNxdzwmTnmCOkVvN2l3aT1sUmt6ZCRmf3o9K2twdFtFfE93fz5TaoVwWkp2dnlacDdiZnxxImo9bjlHSGp6SzxZd248Ol00eFRFeGd2SChiNzVndVc4an97Pidlb39IeClmIy1tUiUvK1ZsTSEnag==',2)
 req=urllib2.Request(bitboostdotcomA, AbitboostdotcomA)
 req.add_header("Content-type", "application/x-www-form-urlencoded")
 try:
  ordemoCd = urllib2.urlopen(req).read()
 except Exception,c:
  print str(c)
  ordemoCd = None
 return ordemoCd

def GetEmptyChannelTitle(ordemoC):
 title = GetChannelTitle(ordemoC)
 if title == "Unknown":
  return 'Sorry no EPG Data is available for this channel'
 return title

def GetChannelTitle(ordemoC):
 if ordemoC == '1'  : return 'BBC One'
 if ordemoC == '91'  : return 'BBC One HD'
 if ordemoC == '2'  : return 'BBC Two'
 if ordemoC == '90'  : return 'BBC Two HD'
 if ordemoC == '3'  : return 'ITV1'
 if ordemoC == '4'  : return 'Channel 4'
 if ordemoC == '5'  : return 'Channel 5'
 if ordemoC == '12' : return 'BBC Three'
 if ordemoC == '13' : return 'BBC Four'
 if ordemoC == '18' : return 'CBBC Channel'
 if ordemoC == '24' : return 'CBeebies'
 if ordemoC == '65' : return 'Red Button'
 if ordemoC == '125' : return 'Red Button HD'
 if ordemoC == '17' : return 'BBC News'
 if ordemoC == '31' : return 'BBC Parliament'
 if ordemoC == '50' : return 'Al Jazeera'
 if ordemoC == '37' : return 'Viva'
 if ordemoC == '58' : return 'Movies4Men'
 if ordemoC == '60' : return 'Movies4Men +1'
 if ordemoC == '33' : return 'QVC'
 if ordemoC == '169' : return 'NHK'
 if ordemoC == '154' : return 'Ideal World'
 if ordemoC == '155' : return 'Ideal Extra'
 if ordemoC == '41' : return 'Ideal and More'
 if ordemoC == '156' : return 'Create and Craft'
 if ordemoC == '63' : return 'Vintage TV'
 if ordemoC == '67' : return 'Channel AKA'
 if ordemoC == '68' : return 'Showcase TV'
 if ordemoC == '70' : return 'Greatest Hits'
 if ordemoC == '71' : return 'Clubbing TV'
 if ordemoC == '72' : return 'BritAsia TV'
 if ordemoC == '78' : return 'Russia Today'
 if ordemoC == '159' : return 'Russia Today HD'
 if ordemoC == '94' : return 'Catch My Bet'
 if ordemoC == '93' : return 'Bid TV'
 if ordemoC == '95' : return 'Price-Drop TV'
 if ordemoC == '96' : return 'Speed Auction'
 if ordemoC == '140' : return 'Insportive'
 if ordemoC == '141' : return 'DocuBox'
 if ordemoC == '142' : return 'FightBox'
 if ordemoC == '143' : return 'FashionBox'
 if ordemoC == '144' : return 'S4C'
 if ordemoC == '152' : return 'BBC One Scotland'
 if ordemoC == '153' : return 'BBC One Wales'
 if ordemoC == '32' : return 'BBC Alba'
 if ordemoC == '158' : return 'Community Channel'
 if ordemoC == '149' : return '360 Tunebox'
 if ordemoC == '146' : return 'CCTV News'
 if ordemoC == '87' : return 'EuroNews'
 if ordemoC == '151' : return 'Sail TV'
 if ordemoC == '157' : return 'Create Extra'
 if ordemoC == '172' : return 'BBC News HD'
 if ordemoC == '173' : return 'BBC Three HD'
 if ordemoC == '174' : return 'BBC Four HD'
 if ordemoC == '175' : return 'CBBC Channel HD'
 if ordemoC == '176' : return 'CBeebies HD'
 if ordemoC == '177' : return 'Sub TV'
 
 return 'Unknown'

def verifyCredentials():
 cFsgZ1tJI25rIGQiNT5ccw = '1'
 fuscat9=bitboostdotcom7()
 AbitboostdotcomA=[(fuscat7('djQjJGBDIyh1cHZ3b2g3JA==',1),fuscat1.getSetting(fuscat7('JyFxdjFnaHt4bnl2bXJSUmpsIyRvSyMoI3BwY2hLOnc=',1))),(fuscat7('RXYgdFAhI3NkIHYiVUZFWQ==',3),fuscat1.getSetting(fuscat7('b2pkeYAsaWiGfnAwenV3SFApdXUtVy9pLys1aDZwJ3U=',2))),(fuscat7('W1AgZ2EjI25rIGQiTFonWg==',3),cFsgZ1tJI25rIGQiNT5ccw),(fuscat7('THgjfVdIaHN2fmRyXydbLQ==',1),fuscat9),(fuscat7('elhvenl1bHNobnUiUUsiNA==',3),YV5SWko3TFtIa05NWVUiaQ),(fuscat7('RSsjfUY4d3FvbHhzN1tdVA==',1),fuscat1.getSetting(fuscat7('Ilxfem1NcmVsc2d2LGNUclRHIHZKPiNtaCBkIic0JS0=',3))),(fuscat7('OW9Gb39WYWZ8ejs+cHF7N0MpOyMtTS0lLysqQDIhJy0=',2),OW9Gb39WYWZ8ejs)]
 AbitboostdotcomA=urllib.urlencode(AbitboostdotcomA)
 bitboostdotcomA=fuscat7('O1dzM3lRMkJzf3dqOmoqMS4ydzJVdXZ2bHJ4bmEnXG1ucnN5dEtra3dsZngpZE4wQz9lfGwhgTdwemYweV5tVktkaGduZ3Bqezpmb1RsW1EvOCN0R2NreDE9anIxVlp0',1)
 req=urllib2.Request(bitboostdotcomA, AbitboostdotcomA)
 req.add_header("Content-type", "application/x-www-form-urlencoded")
 bitboostdotcomB=urllib2.urlopen(req).read()
 if bitboostdotcomB.startswith('rtmp://') == True:
  return ''
 else:
  errorCode=re.compile('>(.+?)</').findall(bitboostdotcomB)
  e='Unknown Error'
  if len(errorCode) > 0:
   e = errorCode[0]
  return e

def checkLatestMessage():
 AbitboostdotcomA=[(fuscat7('eGkjJDIqIyhmeXhoQlwmYQ==',1),fuscat7('Py50cGMjdmVkIHcieGRfZg==',3)),(fuscat7('OW9Gb39WYWZ8ejs+cHF7N0MpOyMtTS0lLysqQDIhJy0=',2),OW9Gb39WYWZ8ejs),(fuscat7('TGhvenknbHNobnUiSVRhdg==',3),YV5SWko3TFtIa05NWVUiaQ),(fuscat7('O2UjJF5VIyh1cHZ3UShcbg==',1),fuscat1.getSetting(fuscat7('X0pxdnBmaHt4bnl2ODBtM0ZeIyRsKCMoI3BwYy81IVI=',1)))]
 AbitboostdotcomA=urllib.urlencode(AbitboostdotcomA)
 bitboostdotcomA=fuscat7("KGV2Mz55MkJzf3dqRzY5O1lCc3FOcnJrcGxrcSxmYFdyPnl2T0doe3Vwd3dYMF88VFsxc05NZjZ2cGZrSW4xOCNTcDM2LkxYRDpud3g4YD11RnMySFlob2R+dmddc21oUlsjJFtHIygjK3NqLC1naw==",1)
 req=urllib2.Request(bitboostdotcomA, AbitboostdotcomA)
 req.add_header("Content-type", "application/x-www-form-urlencoded")
 try:
  ordemoCd = urllib2.urlopen(req).read()
 except:
  ordemoCd = None
 return ordemoCd

def getLatestMessage():
 AbitboostdotcomA=[(fuscat7('QClgeC1hWHMvK0xUaWdqZQ==',2),fuscat7('PyxqcSdhZHtoano8cHYiYQ==',4)),(fuscat7('OW9Gb39WYWZ8ejs+cHF7N0MpOyMtTS0lLysqQDIhJy0=',2),OW9Gb39WYWZ8ejs),(fuscat7('TGhvenknbHNobnUiSVRhdg==',3),YV5SWko3TFtIa05NWVUiaQ),(fuscat7('O2UjJF5VIyh1cHZ3UShcbg==',1),fuscat1.getSetting(fuscat7('X0pxdnBmaHt4bnl2ODBtM0ZeIyRsKCMoI3BwYy81IVI=',1)))]
 AbitboostdotcomA=urllib.urlencode(AbitboostdotcomA)
 bitboostdotcomA=fuscat7("OWkvbHVTPXB3L3d1USgwWT5Tb3MjN2Zta21kclt1P2I3MmV5NEh2cndyaHhKRSI/N3NjbTBZMXNmb2gwZS50alMvSXlSV1NBbi8yb2xMX1FLImVpUlpqYXYudnJKS3IrKU4gbDVTIyBzICMiU1wvbg==",3)
 req=urllib2.Request(bitboostdotcomA, AbitboostdotcomA)
 req.add_header("Content-type", "application/x-www-form-urlencoded")
 try:
  ordemoCd = urllib2.urlopen(req).readlines()
 except:
  ordemoCd = None
 return ordemoCd

def reportError(exceptionType,exceptionData):
 AbitboostdotcomA=[(fuscat7('WzFhWGg+R2VsdHBneDZaOmMwICRWPyMgIyAjIixVIm0=',3),datetime.datetime.now().strftime(fuscat7('OEswKVRVcC1cOjRnMDBmd0ZTUCQpWihCKDVBJ0VLJ09HOiNXUXojKCNIaiorIyIx',4))),(fuscat7('ZldUdnpBdWp0bEdxK1Z5K1kpOCMtcmElLytAWXUhJz4=',2),fuscat1.getSetting(fuscat7('PTJxdjI3aHt4bnl2WFluJWttIyRLTCMoI3BwY3k0YVc=',1))),(fuscat7('MWFvWmokbHNobnUicGxrcw==',3),YV5SWko3TFtIa05NWVUiaQ),(fuscat7('Q28yb387TmZ8eidYZVF7IUUpTyMtV1YlLystOmEhJ0s=',2),OW9Gb39WYWZ8ejs),(fuscat7('I2ZsSjtqd2t4Nz4tenFwJG9TI1ImWiNtZG1RbitwIkg=',4),fuscat7('cFgjRT5JcXdnXD0tUGd0bF12I3ZnIjAoclhlJyt1Iio=',4) + " " + exceptionType),('additionalInfo',base64.b64encode('\n\r'.join(exceptionData)))]
 AbitboostdotcomA=urllib.urlencode(AbitboostdotcomA)
 bitboostdotcomA=fuscat7('YlEvbFwoPXB3L3d1Qnh3ZTpVb3MkKGZta21kcml0UXVoNmV5PU92cndyaHghc0pIaWJjbSE3MXNmb2gweStRZWwxbXlbNmV4bmMyL2BnSnhxS2hpPkpzLnNwaiIpWXRG',3)
 req=urllib2.Request(bitboostdotcomA, AbitboostdotcomA)
 req.add_header("Content-type", "application/x-www-form-urlencoded")
 ordemoCd = urllib2.urlopen(req).readlines()
 
def ezilatiniCVT():
 fuscat1.setSetting(fuscat7('QWJ1ZXhfd1toeGxWWFpvL10vIyQoMSMoIysjdml4RW8=',1),str(datetime.datetime.now().strftime(fuscat7('OEswKVRVcC1cOjRnMDBmd0ZTUCQpWihCKDVBJ0VLJ09HOiNXUXojKCNIaiorIyIx',4))))
 AbitboostdotcomA=[(fuscat7('WzFhWGg+R2VsdHBneDZaOmMwICRWPyMgIyAjIixVIm0=',3),datetime.datetime.now().strftime(fuscat7('OEswKVRVcC1cOjRnMDBmd0ZTUCQpWihCKDVBJ0VLJ09HOiNXUXojKCNIaiorIyIx',4))),(fuscat7('ZldUdnpBdWp0bEdxK1Z5K1kpOCMtcmElLytAWXUhJz4=',2),fuscat1.getSetting(fuscat7('PTJxdjI3aHt4bnl2WFluJWttIyRLTCMoI3BwY3k0YVc=',1))),(fuscat7('MWFvWmokbHNobnUicGxrcw==',3),YV5SWko3TFtIa05NWVUiaQ),(fuscat7('Q28yb387TmZ8eidYZVF7IUUpTyMtV1YlLystOmEhJ0s=',2),OW9Gb39WYWZ8ejs),(fuscat7('I2ZsSjtqd2t4Nz4tenFwJG9TI1ImWiNtZG1RbitwIkg=',4),fuscat7("LnB4bD5JZnxkTllWa2BJX08jb1ReKiNPU1AjcjAuM2BsVWR4RDx2KHF0andHVGUxTlkjJHUqIzZncHd0JiRhOg==",1)),(fuscat7("NX4zdy1dZWYvfmYpM3R7JA==",2),fuscat7("K1lUWlE6VldMQUhWMk49PilCICRANCMgIyAjIkUsdiw=",3))]
 AbitboostdotcomA=urllib.urlencode(AbitboostdotcomA)
 bitboostdotcomA=fuscat7('YlEvbFwoPXB3L3d1Qnh3ZTpVb3MkKGZta21kcml0UXVoNmV5PU92cndyaHghc0pIaWJjbSE3MXNmb2gweStRZWwxbXlbNmV4bmMyL2BnSnhxS2hpPkpzLnNwaiIpWXRG',3)
 req=urllib2.Request(bitboostdotcomA, AbitboostdotcomA)
 req.add_header("Content-type", "application/x-www-form-urlencoded")
 ordemoCd = urllib2.urlopen(req).readlines()
 if fuscat1.getSetting(fuscat7('bk9yUiY/aGJ4T3BocGdeQEdiIFRSMXZ5byBkIkYyX2k=',3))<>"1":
  fuscat1.setSetting(fuscat7('bk9yUiY/aGJ4T3BocGdeQEdiIFRSMXZ5byBkIkYyX2k=',3),'1')

def nehwteg(bitboost):
 bb=bitboost.split(' ')
 b1=bb[0]
 b2=bb[1]
 b11=b1.split('-')
 b22=b2.split(':')
 return datetime.datetime(int(b11[0]), int(b11[1]) ,int(b11[2]), int(b22[0]), int(b22[1]), int(b22[2]))

def nigulPnwodtuhS(): 
 nuRnigulp = datetime.datetime.now() - nehwteg(fuscat1.getSetting(fuscat7('QWJ1ZXhfd1toeGxWWFpvL10vIyQoMSMoIysjdml4RW8=',1)))
 AbitboostdotcomA=[(fuscat7('WzFhWGg+R2VsdHBneDZaOmMwICRWPyMgIyAjIixVIm0=',3),datetime.datetime.now().strftime(fuscat7('OEswKVRVcC1cOjRnMDBmd0ZTUCQpWihCKDVBJ0VLJ09HOiNXUXojKCNIaiorIyIx',4))),(fuscat7('ZldUdnpBdWp0bEdxK1Z5K1kpOCMtcmElLytAWXUhJz4=',2),fuscat1.getSetting(fuscat7('PTJxdjI3aHt4bnl2WFluJWttIyRLTCMoI3BwY3k0YVc=',1))),(fuscat7('MWFvWmokbHNobnUicGxrcw==',3),YV5SWko3TFtIa05NWVUiaQ),(fuscat7('Q28yb387TmZ8eidYZVF7IUUpTyMtV1YlLystOmEhJ0s=',2),OW9Gb39WYWZ8ejs),(fuscat7('I2ZsSjtqd2t4Nz4tenFwJG9TI1ImWiNtZG1RbitwIkg=',4),fuscat7("W1xjWFZxd2FZaEZ3OEl1SWhZIHQyRUpQI1BIbiwpbGA/MWN5X3MjbmpsbHFYeDBLQ0Mgd0hjIy5oIGciWm50bQ==",3)),(fuscat7('NE1sZT8vd3FnXSdzemdwaUApcmV1S2l2b09uJCtMIjs=',4),fuscat1.getSetting(fuscat7("OS9oeFUmdn15Nmd0fWZwUF1JI2VcVSMocCJwVytoIm4=",4)) + fuscat7("RG0oeIFaZHh3K3ksOiFsNGV+USN2ZDF1fXI2eHBmc0pfKSZpLS8wdC8rSjZDIXkq",2) + str(nuRnigulp)),(fuscat7("NX4zdy1dZWYvfmYpM3R7JA==",2),fuscat7("K1lUWlE6VldMQUhWMk49PilCICRANCMgIyAjIkUsdiw=",3))]
 AbitboostdotcomA=urllib.urlencode(AbitboostdotcomA)
 bitboostdotcomA=fuscat7('YlEvbFwoPXB3L3d1Qnh3ZTpVb3MkKGZta21kcml0UXVoNmV5PU92cndyaHghc0pIaWJjbSE3MXNmb2gweStRZWwxbXlbNmV4bmMyL2BnSnhxS2hpPkpzLnNwaiIpWXRG',3)
 req=urllib2.Request(bitboostdotcomA, AbitboostdotcomA)
 req.add_header("Content-type", "application/x-www-form-urlencoded")
 ordemoCd = urllib2.urlopen(req).readlines()
 
def viewingStats(statType):
 if statType == "PLAYBACK STARTED":
  fuscat1.setSetting(fuscat7('I25tdyd1ZGV3U3V2XHFCRVZ4IGVXWyMgdSB3Ing/O08=',3),str(datetime.datetime.now().strftime(fuscat7('OEswKVRVcC1cOjRnMDBmd0ZTUCQpWihCKDVBJ0VLJ09HOiNXUXojKCNIaiorIyIx',4))))
  egassem = fuscat1.getSetting(fuscat7("OS9oeFUmdn15Nmd0fWZwUF1JI2VcVSMocCJwVytoIm4=",4)) + fuscat7("JWhnaVlCd3pkf3Yib1RoWzZYanJsZWx/aHR5ImhnRCxhVWRpc3Z1fHYrZCIyKmJlL0UjJHM+IygjKzFvNXBEbg==",1)
  NE1sZT8vd3FnXSdzemdwaUApcmV1S2l2b09uJCtMIjs = ""
 elif statType == "ADVERT ENDED":
  egassem = fuscat1.getSetting(fuscat7("OS9oeFUmdn15Nmd0fWZwUF1JI2VcVSMocCJwVytoIm4=",4)) + fuscat7("dXJzJE4obG5paGxnWVk8cXQ5d2gkd2hpI2l5cHhZcmc/R2FrW3MjbiNkZHg/J2ItWWkgaUhlIy51IHciKS8neg==",3)
  NE1sZT8vd3FnXSdzemdwaUApcmV1S2l2b09uJCtMIjs = ""
 else:
  nuRlatot = datetime.datetime.now() - nehwteg(fuscat1.getSetting(fuscat7('I25tdyd1ZGV3U3V2XHFCRVZ4IGVXWyMgdSB3Ing/O08=',3)))
  egassem = fuscat1.getSetting(fuscat7("OS9oeFUmdn15Nmd0fWZwUF1JI2VcVSMocCJwVytoIm4=",4)) + fuscat7("U3J2aXUsVG50fkAkMSF1L1BuKSN2NU97fYI0ITllcFFPfDEjf2FXZnR/OiwnaCdtcCklcC1NQTMvK3RkX2InaA==",2)
  NE1sZT8vd3FnXSdzemdwaUApcmV1S2l2b09uJCtMIjs = "They watched a stream for " + str(nuRlatot)
 AbitboostdotcomA=[(fuscat7('WzFhWGg+R2VsdHBneDZaOmMwICRWPyMgIyAjIixVIm0=',3),datetime.datetime.now().strftime(fuscat7('OEswKVRVcC1cOjRnMDBmd0ZTUCQpWihCKDVBJ0VLJ09HOiNXUXojKCNIaiorIyIx',4))),(fuscat7('ZldUdnpBdWp0bEdxK1Z5K1kpOCMtcmElLytAWXUhJz4=',2),fuscat1.getSetting(fuscat7('PTJxdjI3aHt4bnl2WFluJWttIyRLTCMoI3BwY3k0YVc=',1))),(fuscat7('MWFvWmokbHNobnUicGxrcw==',3),YV5SWko3TFtIa05NWVUiaQ),(fuscat7('Q28yb387TmZ8eidYZVF7IUUpTyMtV1YlLystOmEhJ0s=',2),OW9Gb39WYWZ8ejs),(fuscat7('I2ZsSjtqd2t4Nz4tenFwJG9TI1ImWiNtZG1RbitwIkg=',4),egassem),(fuscat7('NE1sZT8vd3FnXSdzemdwaUApcmV1S2l2b09uJCtMIjs=',4),NE1sZT8vd3FnXSdzemdwaUApcmV1S2l2b09uJCtMIjs),(fuscat7("NX4zdy1dZWYvfmYpM3R7JA==",2),fuscat7("K1lUWlE6VldMQUhWMk49PilCICRANCMgIyAjIkUsdiw=",3))]
 AbitboostdotcomA=urllib.urlencode(AbitboostdotcomA)
 bitboostdotcomA=fuscat7('YlEvbFwoPXB3L3d1Qnh3ZTpVb3MkKGZta21kcml0UXVoNmV5PU92cndyaHghc0pIaWJjbSE3MXNmb2gweStRZWwxbXlbNmV4bmMyL2BnSnhxS2hpPkpzLnNwaiIpWXRG',3)
 req=urllib2.Request(bitboostdotcomA, AbitboostdotcomA)
 req.add_header("Content-type", "application/x-www-form-urlencoded")
 ordemoCd = urllib2.urlopen(req).readlines()
  
def LoadConfig ():
  conf = { 'channel' : [] }
  config_file = None
  
  try:
    ADDON    = xbmcaddon.Addon(id='script.tvcatchup')
    VERSION  = ADDON.getAddonInfo('version')
    PLATFORM = mroftap()
    mydata=[(fuscat7('O2UjJF5VIyh1cHZ3UShcbg==',1),ADDON.getSetting('tvcusername')),(fuscat7('VjQgdCkvI3NkIHYiNmg3NA==',3),ADDON.getSetting('tvcpassword')),(fuscat7("eGkjJDIqIyhmeXhoQlwmYQ==",1),fuscat7('N290cjxQdmlyIG8iWmRfVQ==',3)),('version',VERSION),(fuscat7('OW9Gb39WYWZ8ejs+cHF7N0MpOyMtTS0lLysqQDIhJy0=',2),PLATFORM)]
    #print mydata
    mydata=urllib.urlencode(mydata)
    path=fuscat7("c0NzdzxUXHmCOnUiSml3cHNsY2t6WkBmf3p2ZTRwdG9jfE53fyZXaoVwYihsdnk4VDd1ZnwuYWo9bio2Imp6PyJZUG48JHQ0eFRjcyd2SEokN1tndVlNan97a18ub39OYCllIy0yWiUvK1pdVyEnWQ==",2)
    req=urllib2.Request(path, mydata)
    req.add_header("Content-type", "application/x-www-form-urlencoded")
    channelnumbers=urllib2.urlopen(req).readlines()
    mydata=[(fuscat7('Kikldi1aXWovK08xZnZ5Yw==',2),ADDON.getSetting(fuscat7('JyFxdjFnaHt4bnl2bXJSUmpsIyRvSyMoI3BwY2hLOnc=',1))),(fuscat7('ZSkjdEwwI3tkYG5nK3YiQA==',4),ADDON.getSetting(fuscat7('b2pkeYAsaWiGfnAwenV3SFApdXUtVy9pLys1aDZwJ3U=',2))),(fuscat7('QClgeC1hWHMvK0xUaWdqZQ==',2),fuscat7('W1xqZ0xUbG5ybzhfK3EiLQ==',4)),('version',VERSION),(fuscat7('OW9Gb39WYWZ8ejs+cHF7N0MpOyMtTS0lLysqQDIhJy0=',2),PLATFORM)]
    for l in channelnumbers:
      channelID = "channel_" + l
      if ADDON.getSetting(channelID.replace("\n","")) == "true":
        mydata += [(l.replace("\n",""),ADDON.getSetting(channelID.replace("\n","")))]
    #print mydata
    mydata=urllib.urlencode(mydata)
    path=fuscat7("QiwybEw2PXh3IXUvOnd1JnlDcnMzSmZ1a1BcWnhkciYzM2h5PjN2endwcG99aHhkOHNmbTZKMXtmMzJpemgwOTk1THlWJVNJblNgbzoya05TdHNyMWsxgGdPNVlzaHJBTiUjJHIrIygjMTFkKyMiUA==",4)
    req=urllib2.Request(path, mydata)
    req.add_header("Content-type", "application/x-www-form-urlencoded")
    config_file=urllib2.urlopen(req).readlines()
    #print config_file
    if len(config_file) < 3:
      config_file = None
      
  except Exception,c:      
    config_file = None

  if config_file == None:
    backupConfig = os.path.join(ADDON.getAddonInfo('path'), 'tv_grab_uk_rt_aps.conf')
    f = open(backupConfig)
    config_file = f.readlines()
    f.close()
  
  for l in config_file:
    pts = l.strip().split('=')
    if len(pts) != 2: continue
    if pts[0] != 'channel':
      conf[pts[0]] = pts[1]
    else:
      conf['channel'].append(pts[1])

  return conf
