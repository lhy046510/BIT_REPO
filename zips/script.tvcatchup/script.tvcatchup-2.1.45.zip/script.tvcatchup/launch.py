#
#      Copyright (C) 2012 Tommy Winther
#      http://tommy.winther.nu
#
#      Modified on behalf of TVCatchup
#      by Chris Grove (tvc@killergerbils.co.uk)
#      and Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import buggalo
import xbmc
import xbmcaddon
import xbmcgui
import os
import gui
import source
import dialogue
import TVC
import time
import datetime

from player import TVCPlayer
from source import Channel

import check
               
def main():
    try:
        #workaround Python bug in strptime which causes it to intermittently throws an AttributeError
        datetime.datetime.fromtimestamp(time.mktime(time.strptime('2013-01-01 19:30:00'.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
    except:
        return

    try: 
        ADDON       = xbmcaddon.Addon(id = 'script.tvcatchup')
        profilePath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        xmlFile     = os.path.join(profilePath, 'data.xml')

        if not os.path.exists(profilePath):
            os.makedirs(profilePath)    

        if xbmcgui.Window(10000).getProperty("TVCatchup_EPG_Clear_Database") == "True":           
            xbmcgui.Window(10000).clearProperty("TVCatchup_EPG_Clear_Database")
            import clear_cache
            clear_cache.clear_cache()

        if not os.path.exists(xmlFile):
            import download_data
            download_data.download_data()    
        
        #if ADDON.getSetting('tvcusername') == "":          
        #    dialogue.doOK('TVCatchup', ['', 'Please enter your TVC Username', 'and Password.', '', 'Please signup at www.tvcatchup.com if you haven\'t already done so.'])
        #    ADDON.openSettings() 
        #    return False   

        import check
        check.keymap()
        try:
            messageID = TVC.checkLatestMessage()
            #print "Message ID is " + messageID
            if int(ADDON.getSetting('MessageID')) < int(messageID):
                messageText = TVC.getLatestMessage()
                messageTitle = messageText[0]
                messageText[0] = ""
                for j in range(0,len(messageText)-1):
                    messageText[j] = messageText[j].replace("\r","").replace("\n","")
                dialogue.doOK(messageTitle,messageText)
                #print "Message Text is " + messageText
                ADDON.setSetting('MessageID', messageID)
        except:
            pass   
    
        if source.XMLTVSource().rebuildChannelAndProgramListCachesIfNecessary() == True:
            w = gui.TVGuide()
            w.doModal()
            del w            
            
    except Exception:
        buggalo.onExceptionRaised()

    return True

#def do(id = None):    
def do():
    if xbmcgui.Window(10000).getProperty("TVCatchup_EPG_Downloading") == "True":
        dialogue.doOK('TVCatchup', ['', 'EPG Data is currently downloading.', '', 'Please try again in a few minutes.'])
        return

    main()

    #if id == 'RETRY':
    #    if xbmcaddon.Addon(id = 'script.tvcatchup').getSetting('tvcusername') != "":  
    #        main()
    #    return

    #if not main():   
    #    addonPath = xbmcaddon.Addon(id = 'script.tvcatchup').getAddonInfo('path')
    #    name      = 'Addon'
    #    script    = os.path.join(addonPath, 'addon.py')
    #    args      = 'RETRY'
    #    cmd       = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (name.encode('utf-8', 'replace'), script.encode('utf-8', 'replace'), args.encode('utf-8', 'replace'), 0)     

    #    xbmc.executebuiltin(cmd) 

def launch(id, name):
    wasRunning = xbmcgui.Window(10000).getProperty('TVCatchup_EPG_Running') ==  'True'

    xbmcgui.Window(10000).setProperty("TVCatchup_EPG_Running", "True")

    if id == '' and wasRunning: 
        #id was pre-determined using xbmcgui.getCurrentWindowId()
        xbmc.executebuiltin('ActivateWindow(13000)')  
        return
          
    if not wasRunning:
        try:
            TVC.ezilatiniCVT()
        except:
            pass

    if id != '' and name != '':
        TVCPlayer().playStream(Channel(id, name)) 
        if wasRunning:
            return        
    else:
        do()

    try:
        TVC.nigulPnwodtuhS()
    except:
        pass

    xbmcgui.Window(10000).setProperty("TVCatchup_EPG_Running", "False")
    xbmcgui.Window(10000).clearProperty("TVCatchup_Channel")
    check.delete()


if __name__ == '__main__':  
    id   = sys.argv[1]
    name = sys.argv[2]

    launch(id, name)