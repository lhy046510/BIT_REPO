#
#      Copyright (C) 2012 TVCatchup
#
#       Chris Grove (tvc@killergerbils.co.uk)
#       and Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import xbmcaddon
import dialogue
import xbmc
import TVC
from source import Channel

def verifyCredentials():
    return TVC.verifyCredentials()    

def do(argv):
    if len(argv) > 1 and argv[1] == 'RETRY':
        xbmcaddon.Addon(id = 'script.tvcatchup').openSettings() 
        return

    xbmc.sleep(100)
    ADDON = xbmcaddon.Addon(id = 'script.tvcatchup')
    
    tvcusername = ADDON.getSetting('tvcusername') 
    tvcpassword = ADDON.getSetting('tvcpassword') 

    if tvcusername == "":
        dialogue.doOK('TVCatchup', ['', 'Please ensure Username is set.'])    
        
    elif tvcpassword == "":
        dialogue.doOK('TVCatchup', ['', 'Please ensure Password is set.'])    
        
    else:
        verify = verifyCredentials()      
        if verify == '':
            dialogue.doOK('TVCatchup', ['', 'Username and Password verified.'])    
        else:
            dialogue.doOK('TVCatchup', ['', 'Verification Error', verify])

    addonPath = xbmcaddon.Addon(id = 'script.tvcatchup').getAddonInfo('path')
    name      = 'Addon'
    script    = os.path.join(addonPath, 'verify_settings.py')
    args      = 'RETRY'
    cmd       = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (name.encode('utf-8', 'replace'), script.encode('utf-8', 'replace'), args.encode('utf-8', 'replace'), 0)     

    xbmc.executebuiltin(cmd)      

if __name__ == '__main__':  
    do(sys.argv)