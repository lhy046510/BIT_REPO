#       Copyright (C) 2012 
#       Written on behalf of TVCatchup
#       by Chris Grove (tvc@killergerbils.co.uk)
#       and Sean Poyser (seanpoyser@gmail.com)
#

import xbmc
import xbmcgui
import xbmcaddon
import os

import datetime
import time

from source import Channel

KEY_NAV_BACK = 92
KEY_ESC_ID   = 10
KEY_ESC_CODE = 61467

ACTION_BACK          = 92
ACTION_PARENT_DIR    = 9
ACTION_PREVIOUS_MENU = 10

ACTION_UP         = 3
ACTION_DOWN       = 4
ACTION_PAGE_UP    = 5
ACTION_PAGE_DOWN  = 6
ACTION_SELECT     = 7
ACTION_MOUSE_MOVE = 107

ADDON = xbmcaddon.Addon(id = 'script.tvcatchup')

THEME = ADDON.getSetting('skin') + '-'

xmlfile = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')), 'resources', 'skins',  'Default', '720p', THEME + 'script-tvcatchup-program-list.xml')
if not os.path.exists(xmlfile):
    PREFIX = ""
else:
    PREFIX = THEME

C_DIALOG_BOX   = 4300
C_DIALOG_TITLE = 4302
C_DIALOG_TEXT  = 4303
C_DIALOG_YES   = 4301
C_DIALOG_NO    = 4304
C_DIALOG_ICON  = 4305
C_DIALOG_OKAY  = 4306

THEPAST   = -1
THENOW    =  0
THEFUTURE = 1

class DialogList(xbmcgui.WindowXMLDialog):

    def __new__(cls, programs, channels, term , showHits, dp):
        return super(DialogList, cls).__new__(cls, PREFIX + 'script-tvcatchup-program-list.xml', ADDON.getAddonInfo('path'))
        
    def __init__(self, programs, channels, term , showHits, dp):
        super(DialogList, self).__init__()
        self.programs = programs
        self.term     = term
        self.channels = channels
        self.showHits = showHits
        self.dp       = dp
        
    def onInit(self):
        try:
            self.prune()

            nHits   = len(self.programs)
            hitText = 'hit'
            if nHits > 1: hitText = hitText + 's'

            if self.showHits:
                self.getControl(4001).setLabel('%s (%d %s)' % (self.term, len(self.programs), hitText))
            else:
                self.getControl(4001).setLabel(self.term)

            self.programDesc     = self.getControl(4002)
            self.selectedProgram = None
                
            self.list = self.getControl(4003)

            self.listID       = self.list.getId()
            self.currentIndex = -1

            self.populateList()
            
            if len(self.programs) < 1:
                self.setFocus(self.getControl(4005))                                
            else:
                self.setFocus(self.list)
                self.updateDescription()

            if self.dp:
                self.dp.close()

        except:
            raise

    def populateList(self):
        nHits    = len(self.programs)
        colStart = '[COLOR=FF808080]'
        colEnd   = '[/COLOR]'
        when     = THEPAST
 
        count    = 0
        progress = 10
            
        for p in self.programs:
            if self.dp:
                print "*******************"
                print count
                count = count + 1
                value = int(18 * count / nHits)                    
                if progress != value:
                    progress = value
                    self.dp.update(10 + (progress * 5))
            if when != THEFUTURE:
                when = self.isOnWhen(p)
                if when == THEPAST:
                    colStart = '[COLOR=FF808080]'
                elif when == THENOW:
                    colStart = '[COLOR=FF00FF00]'
                elif when == THEFUTURE:
                    colStart = ''
                    colEnd   = ''
                    
            title = '%s%s%s' % (colStart, p[0], colEnd)
            time  = p[3].split(' ')            
            time  = '%s%s  %s%s' % (colStart, time[1][:-3], time[0], colEnd)
            logo  = Channel(p[2],'').logo
            liz   = xbmcgui.ListItem(title, time, iconImage=logo)
            self.list.addItem(liz)


    def prune(self):
        localChannels = []
        for c in self.channels:
            localChannels.append(c.id)

        localPrograms = []
        for p in self.programs:
            if p[2] in localChannels:
                localPrograms.append(p)

        self.programs = localPrograms


    def parseDate(self, dateString):
        if type(dateString) in [str, unicode]:            
            dt = dateString.split(' ')
            d  = dt[0]
            t  = dt[1]
            ds = d.split('-')
            ts = t.split(':')
            return datetime.datetime(int(ds[0]), int(ds[1]) ,int(ds[2]), int(ts[0]), int(ts[1]), int(ts[2]))

        return dateString


    def isOnWhen(self, program):     
        now   = datetime.datetime.today()
        start = program[3]
        end   = program[4]

        start = self.parseDate(start)
        end   = self.parseDate(end)

        if now < start:
            return THEFUTURE

        if now >= end:
            return THEPAST

        return THENOW
               
 
    def onAction(self, action):
        try:
            actionID = action.getId()
            if actionID in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, KEY_NAV_BACK, ACTION_BACK, KEY_ESC_ID]:
                self.close()
                return

            if actionID in [ACTION_UP, ACTION_DOWN, ACTION_PAGE_UP, ACTION_PAGE_DOWN, ACTION_MOUSE_MOVE]:
                self.updateDescription()

            if actionID in [ACTION_SELECT]:
                if self.currentIndex > -1:
                    self.selectedProgram = self.programs[self.currentIndex]
                self.close()
                return                
        except:
            pass


    def onClick(self, controlId):
        if controlId == self.listID:
            self.selectedProgram = self.programs[self.currentIndex]
        else:
            self.currentIndex = -1
        self.close()
 
 
    def onFocus(self, controlId):        
        if controlId == self.listID:
            self.updateDescription()        


    def updateDescription(self):
        try:
            index = self.list.getSelectedPosition()
            if self.currentIndex == index:
                return
            self.currentIndex = index

            self.programDesc.setText(self.programs[self.currentIndex][1])
            self.programDesc.setVisible(self.programs[self.currentIndex][1] != '')

        except:
            self.programDesc.setVisible(False)


def show(programs, channels, term = None, showHits = False, dp = None):
    list = DialogList(programs, channels, term, showHits, dp)
    list.doModal()
    selected = list.selectedProgram 
    del list
    return selected
