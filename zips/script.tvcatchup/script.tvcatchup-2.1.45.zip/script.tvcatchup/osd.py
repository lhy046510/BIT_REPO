#       Copyright (C) 2012 
#       Written on behalf of TVCatchup
#       by Chris Grove (tvc@killergerbils.co.uk)
#       and Sean Poyser (seanpoyser@gmail.com)
#

import xbmc
import xbmcgui
import xbmcaddon

import datetime, time

from threading import Timer 
from source import Channel
from source import Program

import source
import TVC

from player import TVCPlayer
from help   import HelpMenu 
from notification import Notification

import sys
import os

import dialogue

from sqlite3 import dbapi2 as sqlite3

KEY_ESC_ID   = 10
KEY_ESC_CODE = 61467

ACTION_LEFT  = 1
ACTION_RIGHT = 2
ACTION_UP    = 3
ACTION_DOWN  = 4

ACTION_BACK  = 92
ACTION_STOP  = 122

ACTION_HOME       = 159
ACTION_X          = 13
ACTION_PARENT_DIR = 9

ACTION_PLAY   = 79
ACTION_SELECT = 7

KEY_H = 61512

ADDON = xbmcaddon.Addon(id = 'script.tvcatchup')

THEME = ADDON.getSetting('skin')

xmlfile = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')), 'resources', 'skins',  'Default', '720p', THEME + '-script-tvcatchup-osd.xml')
if not os.path.exists(xmlfile):
    PREFIX = ''
else:
    PREFIX = THEME + '-'

class OSD(xbmcgui.WindowXMLDialog):
    C_OSD_TITLE          = 5000
    C_OSD_DESCRIPTION    = 5001
    C_OSD_TIME           = 5002
    C_OSD_NOW            = 5003
    C_OSD_CHANNEL_LOGO   = 5004
    C_OSD_CURRENT_TIME   = 5005
    C_OSD_IMAGE          = 5006
    C_OSD_REMINDER_IMAGE = 5007

    def __new__(cls):
        return super(OSD, cls).__new__(cls, PREFIX + 'script-tvcatchup-osd.xml', xbmcaddon.Addon(id = 'script.tvcatchup').getAddonInfo('path'))

    def __init__(self):
        super(OSD, self).__init__()

        self.ADDON  = xbmcaddon.Addon(id = 'script.tvcatchup')
        self.path   = xbmc.translatePath(self.ADDON.getAddonInfo('profile'))    
        self.KEY    = 'xmltv'

        SOURCE_DB = 'guide1.db'        

        self.source = source.XMLTVSource()
        self.notify = Notification()       

        self.timer      = None
        self.closeTimer = None
        self.dialogUp   = False

        self.conn             = sqlite3.connect(os.path.join(self.path, SOURCE_DB), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False)
        self.conn.row_factory = sqlite3.Row 

        self.channels = self.getChannels()
        self.force    = False


    def close(self):
        if self.timer != None:
            self.timer.cancel()            

        if self.closeTimer != None:
            self.closeTimer.cancel()            

        xbmcgui.WindowXMLDialog.close(self) 


    def resetCloseTimer(self):
        if self.closeTimer != None:
            self.closeTimer.cancel()
            
        self.closeTimer = Timer(30, self.onCloseTimer)
        self.closeTimer.start()


    def onCloseTimer(self):
        if self.closeTimer == None:
            return

        if self.dialogUp:
            self.resetCloseTimer()
        else:
            self.closeTimer.cancel()
            self.close()


    def updateDetails(self):
        self.setControlLabel(self.C_OSD_TITLE,       '[B]%s[/B]' % self.program.title)        
        self.setControlText( self.C_OSD_DESCRIPTION, self.program.description)                       
        if self.program.channel.logo is not None:
            self.setControlImage(self.C_OSD_CHANNEL_LOGO, self.program.channel.logo)
        else:
            self.setControlImage(self.C_OSD_CHANNEL_LOGO, '')

        self.setControlLabel(self.C_OSD_TIME, '[B]%s - %s[/B]' % (self.program.startDate.strftime('%H:%M'), self.program.endDate.strftime('%H:%M')))

        if self.notify.isNotificationRequiredForProgram(self.program):
            self.setControlImage(self.C_OSD_REMINDER_IMAGE, 'reminder.png')
        else:
            self.setControlImage(self.C_OSD_REMINDER_IMAGE, '')

        self.updateTime()


    def updateTime(self):
        isOn = self.isOnWhen(self.program)
        if isOn == 0:
            when = 'Showing Now'
        elif isOn == -1:
            when = 'Already Shown'
        elif isOn == 1:
            when = 'Showing Later'
        else:
            when = ''

        self.setControlLabel(self.C_OSD_NOW,  '[B]%s[/B]' % (when))        
        self.setControlLabel(self.C_OSD_CURRENT_TIME, '[B]%s[/B]' % (datetime.datetime.today().strftime('%a, %d %b %H:%M')))

        if self.timer != None:
            self.timer.cancel()            
        self.timer = Timer(1, self.updateTime)
        self.timer.start()


    def clear(self):
        self.setControlLabel(self.C_OSD_TITLE,        '')        
        self.setControlText( self.C_OSD_DESCRIPTION,  '')               
        self.setControlLabel(self.C_OSD_TIME,         '')
        self.setControlImage(self.C_OSD_CHANNEL_LOGO, '')
        self.setControlLabel(self.C_OSD_NOW,          '')        
        self.setControlLabel(self.C_OSD_CURRENT_TIME, '')


    def getChannels(self):
        fullList    = []
        channelList = []

        c = self.conn.cursor()      
        c.execute("SELECT id, title FROM channels")        
        
        for row in c:            
            fullList.append(Channel(row["id"], row["title"]))    
            
        c.close() 

        #remove channels not enabled in settings
        for chn in fullList:
            if self.ADDON.getSetting('channel_' + chn.id) == "true":
                channelList.append(chn) 
                
        return channelList


    def setControlImage(self, controlId, image):
        control = self.getControl(controlId)
        if control:
            control.setImage(image)


    def setControlLabel(self, controlId, label):
        control = self.getControl(controlId)
        if control:
            control.setLabel(label)


    def setControlText(self, controlId, text):
        control = self.getControl(controlId)
        if control:
            control.setText(text)


    def onInit(self):
        try:
            id = xbmcgui.Window(10000).getProperty("TVCatchup_Channel")
            if id == "":
                id = "1"
                self.force = True

            self.channel     = self.getInitialChannel(id)
            self.homeChannel = self.channel
            self.program     = self.getCurrentProgram(self.channel)

            self.setControlImage(self.C_OSD_IMAGE, PREFIX + 'tvcatchup-logo.png')

            self.updateDetails()

            self.resetCloseTimer()

        except Exception:
            pass


    def onAction(self, action):
        try:
            xbmc.log("[script.tvcatchup] *******************onAction***************************", xbmc.LOGDEBUG)
            xbmc.log("[script.tvcatchup] " + str(action.getId()),                                 xbmc.LOGDEBUG)
            xbmc.log("[script.tvcatchup] " + str(action.getButtonCode()),                         xbmc.LOGDEBUG)

            actionId = action.getId()
            buttonId = action.getButtonCode()    

            self.resetCloseTimer()        

            if actionId == KEY_ESC_ID and buttonId == KEY_ESC_CODE:
                self.close()
                return

            if actionId == ACTION_BACK:
                self.close()

            if actionId == ACTION_X or actionId == ACTION_STOP:
                self.clear()
                self.close()

            if actionId == ACTION_PLAY or actionId == ACTION_SELECT:
                isOn = self.isOnWhen(self.program)

                change = self.force or self.channel != self.homeChannel

                if isOn == 0 and change:
                    self.force = False
                    self.homeChannel = self.channel
                    TVCPlayer().playStream(self.channel, notify = True)                     

                elif isOn == 1:
                    self.reminder(self.program)                      

            if not actionId in [ACTION_RIGHT, ACTION_LEFT, ACTION_UP, ACTION_DOWN, ACTION_HOME]:
                return

            if actionId == ACTION_RIGHT:
                self.program = self.getNextProgram(self.program)
            if actionId == ACTION_LEFT:
                self.program = self.getPreviousProgram(self.program)
            if actionId == ACTION_UP:
                self.channel = self.getNextChannel(self.channel)
                self.program = self.getCurrentProgram(self.channel)
            if actionId == ACTION_DOWN:
                self.channel = self.getPreviousChannel(self.channel)
                self.program = self.getCurrentProgram(self.channel)
            if actionId == ACTION_HOME:
                self.channel = self.homeChannel
                self.program = self.getCurrentProgram(self.channel)
            if buttonId == KEY_H:
                helpscreen = HelpMenu()
                helpscreen.doModal()     
                del helpscreen

            self.updateDetails()

        except Exception:
            raise


    def onClick(self, controlId):
        try:
            xbmc.log("[script.tvcatchup] *******************onClick***************************", xbmc.LOGDEBUG)
            xbmc.log("[script.tvcatchup] " + str(controlId),                                     xbmc.LOGDEBUG)
        except Exception:
            pass


    def onFocus(self, controlId):
        pass


    def parseDate(self, dateString):
        if type(dateString) in [str, unicode]:            
            dt = dateString.split(' ')
            d  = dt[0]
            t  = dt[1]
            ds = d.split('-')
            ts = t.split(':')
            return datetime.datetime(int(ds[0]), int(ds[1]) ,int(ds[2]), int(ts[0]), int(ts[1]), int(ts[2]))

        return dateString


    def getCurrentProgram(self, channel):
        program = None
        now = datetime.datetime.now()
        c = self.conn.cursor()
        c.execute('SELECT * FROM programs WHERE channel=? AND startDate <= ? AND endDate >= ? LIMIT 1', [channel.id, now, now])
        row = c.fetchone()
        if row:
            program = Program(row["id"], channel, row["title"], row["startDate"], row["endDate"], row["description"], row["episode"], row["genre"])
        c.close()

        if program.description == "":
            xbmc.log('[script.tvcatchup] Possible empty channel, checking...',xbmc.LOGDEBUG)
            IsEmpty = TVC.GetEmptyChannelTitle(channel.id)
            xbmc.log('[script.tvcatchup] ' + IsEmpty,xbmc.LOGDEBUG)
            if IsEmpty == program.title:
                xbmc.log("[script.tvcatchup] It's Empty, let's ask TVC for the info",xbmc.LOGDEBUG)
                missingInfo = TVC.getMissingNow(channel.id)
                program.title = missingInfo[0]
                if missingInfo[1]<>"Offline":
                    program.startDate = self.parseDate(missingInfo[1])
                if missingInfo[2]<>"Offline":
                    program.endDate =  self.parseDate(missingInfo[2])

        return program


    def getNextProgram(self, program):
        nextProgram = None
        when = program.endDate + datetime.timedelta(minutes = 1)
        c = self.conn.cursor()
        c.execute('SELECT * FROM programs WHERE channel=? AND startDate <= ? AND endDate >= ? LIMIT 1', [program.channel.id, when, when])
        row = c.fetchone()
        if row:                       
            nextProgram = Program(row["id"], self.channel, row["title"], row["startDate"], row["endDate"], row["description"], row["episode"], row["genre"])
        c.close()
        
        if nextProgram.description == "":
            xbmc.log('[script.tvcatchup] Possible empty channel, checking...',xbmc.LOGDEBUG)
            IsEmpty = TVC.GetEmptyChannelTitle(program.channel.id)
            xbmc.log('[script.tvcatchup] ' + IsEmpty,xbmc.LOGDEBUG)
            if IsEmpty == nextProgram.title:
                xbmc.log("[script.tvcatchup] It's Empty, let's ask TVC for the info",xbmc.LOGDEBUG)
                missingInfo = TVC.getMissingNext(program.channel.id)
                nextProgram.title = missingInfo[0]
                if missingInfo[1]<>"Offline":
                    nextProgram.startDate = self.parseDate(missingInfo[1])
                if missingInfo[2]<>"Offline":
                    nextProgram.endDate =  self.parseDate(missingInfo[2])

        return nextProgram


    def getPreviousProgram(self, program):
        previousProgram = None
        when = program.startDate - datetime.timedelta(minutes = 1)
        c = self.conn.cursor()
        c.execute('SELECT * FROM programs WHERE channel=? AND startDate <= ? AND endDate >= ? LIMIT 1', [program.channel.id, when, when])
        row = c.fetchone()
        if row:
            previousProgram = Program(row["id"], self.channel, row["title"], row["startDate"], row["endDate"], row["description"], row["episode"], row["genre"])
        c.close()

        return previousProgram


    def getNextChannel(self, channel):
        index = -1
        for chn in self.channels:
            index = index + 1
            if chn.id == channel.id:
                break

        index = index + 1

        maxChannel = len(self.channels)-1
        if index > maxChannel:
            index = 0

        return self.channels[index]


    def getInitialChannel(self, id):
        index = -1
        for chn in self.channels:
            index = index + 1
            if chn.id == id:
                break

        if index < 0:
            index = 0

        maxChannel = len(self.channels)-1
        if index > maxChannel:
            index = maxChannel

        return self.channels[index]


    def getPreviousChannel(self, channel):
        index = -1
        for chn in self.channels:
            index = index + 1
            if chn.id == channel.id:
                break

        index = index - 1

        if index < 0:
            index = len(self.channels)-1

        return self.channels[index]


    def isOnWhen(self, program):
        if program.title == "Close":
            return 99

        now   = datetime.datetime.today()
        start = program.startDate
        end   = program.endDate

        if now < start:
            return 1

        if now >= end:
            return -1

        return 0


    def reminder(self, program):
        self.dialogUp = True

        if self.notify.isNotificationRequiredForProgram(program):
            self.cancelReminder(program)
        else:
            self.createReminder(program)

        self.dialogUp = False
        self.resetCloseTimer()


    def createReminder(self, program):
        #ADDON    = xbmcaddon.Addon(id = 'script.tvcatchup')
        #dataPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
        #self.icon = os.path.join(self.addonPath, 'icon.png')               
        if dialogue.doYesNo('TVCatchup', ['', '', 'Create Reminder for %s?'  % (program.title)]):        
            self.notify.addProgram(program)
            self.updateDetails()


    def cancelReminder(self, program):
        if dialogue.doYesNo('TVCatchup Reminder', ['', '', 'Cancel Reminder for %s?'  % (program.title)]):        
            self.notify.delProgram(program)
            self.updateDetails()


if __name__ == '__main__':
    osd = OSD()
    osd.doModal()     
    del osd
