#       Copyright (C) 2012 
#       Written on behalf of TVCatchup
#       by Chris Grove (tvc@killergerbils.co.uk)
#       and Sean Poyser (seanpoyser@gmail.com)
#

import buggalo
import xbmcaddon
import xbmcgui
import addon

from sqlite3 import dbapi2 as sqlite3

import smtplib
from email.mime.text import MIMEText   

ADDON = xbmcaddon.Addon(id = 'script.tvcatchup')

def markProgram(title, chnId, start):      

    dbPath = xbmc.translatePath(ADDON.getAddonInfo('profile'))    
    conn   = sqlite3.connect(os.path.join(dbPath, 'notification.db'), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False)

    c = conn.cursor()
    c.execute("DELETE FROM notification WHERE channel=? AND program=? AND start=?", [chnId, title, start])
    c.execute("INSERT OR REPLACE INTO notification(channel, program, start, emailed) VALUES(?, ?, ?, ?)", [chnId, title, start, True])
    conn.commit()
    c.close()

def error():
    d = xbmcgui.Dialog()
    d.ok("TVCatchup","Email notification failed", "Please check your username and password")
    ADDON.openSettings()               

def notify(title, chnId, start):
    try:         
        username  = ADDON.getSetting('email.user')
        password  = ADDON.getSetting('email.password')
        recipient = ADDON.getSetting('email.recipient')

        if username  =='' or password == '':
            error()
            return

        username = username.replace('@googlemail.com', '@gmail.com')

        if not username.endswith('@gmail.com'):
            username += '@gmail.com'

        if recipient == '':
            recipient = username        

        dbPath    = xbmc.translatePath(ADDON.getAddonInfo('profile'))    

        conn             = sqlite3.connect(os.path.join(dbPath, 'guide1.db'), timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False)
        conn.row_factory = sqlite3.Row

        c = conn.cursor()
        c.execute('SELECT * FROM channels WHERE id=?', [chnId])
        row = c.fetchone()
        c.close()
        if not row:       
            return

        channel = row["title"]       

        time  = start.split(' ')
        time  = time[1] + ' ' + time[0]

        text = '%s\r%s\r%s' % (title, channel, time)
        message = MIMEText(text)

        message["From"]    = username
        message["To"]      = recipient
        message["Subject"] = "TVCatchup Program Notification"

        s = smtplib.SMTP('smtp.gmail.com:587')
        s.starttls()
        s.login(username, password)
        s.sendmail(username, recipient, message.as_string())        
        s.quit()

        markProgram(title, chnId, start)
                                                            
    except Exception:
        raise

if __name__ == '__main__':
    title = sys.argv[1] 
    chnId = sys.argv[2]
    start = sys.argv[3]
    notify(title, chnId, start)