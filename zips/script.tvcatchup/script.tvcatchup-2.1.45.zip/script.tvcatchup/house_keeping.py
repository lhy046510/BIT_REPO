#      Copyright (C) 2012 TVCatchup
#      Chris Grove (tvc@killergerbils.co.uk)
#      and Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import buggalo
import xbmc
import xbmcgui
import os
import download_data
import xbmcaddon
import check
import clear_cache


def doHouseKeeping(mins, version = 0):
    ADDON       = xbmcaddon.Addon(id = 'script.tvcatchup')
    refreshFile = int(ADDON.getSetting('dayCheck')) + 1
    when        = refreshFile * 24 * 60
    every       = 60

    try:
        mins = int(mins)
    except:
        mins = when / 2 
    
    try:               
       running     = xbmcgui.Window(10000).getProperty("TVCatchup_EPG_Running")     == 'True'  
       downloading = xbmcgui.Window(10000).getProperty("TVCatchup_EPG_Downloading") == 'True'
       playing     = xbmc.Player().isPlaying()

       if not running:            
           if xbmcgui.Window(10000).getProperty("TVCatchup_EPG_Clear_Database") == "True":                          
               clear_cache.clear_cache()
       
       delta = when - mins 
       #print "*************************"
       #print "**** delta when mins ****"
       #print delta
       #print when
       #print mins
       #print "*************************"     
                      
       if (not playing) and (not downloading) and (delta <= 0) and (xbmc.getGlobalIdleTime() > 300):
       #if True:
           if ADDON.getSetting('autoUpdate') == 'true':

              performUpdate = True
              showProgress  = ADDON.getSetting('silent.grab.enabled') == 'false'
              
              if not showProgress:
                  performUpdate = not running

              if performUpdate:   
                 xbmc.log('[script.tvcatchup] *** UPDATING GUIDE DATA ***')
                 mins = when - 30
                 if download_data.download_data(showProgress):
                    mins = -every
       mins = mins + every          
       
       addonPath = ADDON.getAddonInfo('path')
       name      = 'HouseKeeping'
       script    = os.path.join(addonPath, 'house_keeping.py')
       version   = 4
       args      = str(mins) + ',' + str(version)
       cmd       = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (name.encode('utf-8', 'replace'), script.encode('utf-8', 'replace'), args.encode('utf-8', 'replace'), every)     

       xbmc.executebuiltin(cmd)

    except Exception:
        buggalo.onExceptionRaised()


if __name__ == '__main__':  
    if len(sys.argv) == 4: #this will be from version 3 (version 4 has had wasPlaying parameter removed)
        doHouseKeeping(sys.argv[1], sys.argv[3])
    else:
        doHouseKeeping(sys.argv[1], sys.argv[2])