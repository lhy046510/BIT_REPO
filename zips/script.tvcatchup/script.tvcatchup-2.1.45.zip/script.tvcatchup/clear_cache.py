#
#      Copyright (C) 2012 Tommy Winther
#      http://tommy.winther.nu
#
#      Modified on behalf of TVCatchup
#      by Chris Grove (tvc@killergerbils.co.uk)
#      and Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import os
import xbmc
import xbmcgui

from strings import *

import dialogue

#from sqlite3 import dbapi2 as sqlite3

def clear_cache():
    try:
        xbmc.log("Clearing TVGuide [script.tvcatchup] caches...", xbmc.LOGDEBUG)
        dbPath = xbmc.translatePath(xbmcaddon.Addon(id = 'script.tvcatchup').getAddonInfo('profile'))

        delete_file(os.path.join(dbPath, 'guide.db'))
        delete_file(os.path.join(dbPath, 'guide1.db'))

        xbmc.log("[script.tvcatchup] Caches cleared!", xbmc.LOGDEBUG)
        return True

    except Exception:
        xbmc.log('[script.tvcatchup] Caught exception while clearing cache!', xbmc.LOGDEBUG)
        return False

def delete_file(filename):
    while os.path.exists(filename): 
        try: 
            os.remove(filename) 
            break 
        except: 
            pass 

if __name__ == '__main__':
    if clear_cache():
        dialogue.doOK('TVCatchup', ['', 'All EPG data cleared', 'New data will be retrieved next time the addon is started'])                


