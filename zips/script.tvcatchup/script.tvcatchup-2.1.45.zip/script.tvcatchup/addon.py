#       Copyright (C) 2013
#       Written on behalf of TVCatchup
#       by Chris Grove (tvc@killergerbils.co.uk)
#       and Sean Poyser (seanpoyser@gmail.com)
#

import xbmcaddon
import xbmcgui
import xbmc
import os

id   = ''
name = ''

try:
    id = sys.argv[1]
except:
    pass

try:
    name = sys.argv[2]
except:
    pass

addonPath = xbmcaddon.Addon(id = 'script.tvcatchup').getAddonInfo('path')
script    = os.path.join(addonPath, 'launch.py')
args      = id + ',' + name
cmd       = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (name.encode('utf-8', 'replace'), script.encode('utf-8', 'replace'),     args.encode('utf-8', 'replace'), 0)     

xbmc.executebuiltin(cmd) 