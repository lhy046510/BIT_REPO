CrunchyXBMC
==========

Crunchyroll;xbmc
A XBMC plugin for Cruchyroll. 
This plugin a an amalgamation of some of my own code and other's patches.

Legacy Builds at https://code.google.com/p/urlxl-repo/

Forum Posting: http://forum.xbmc.org/showthread.php?tid=129709

Disclaimer:
You MUST be a Crunchyroll Premium Member!

Thanks to the following for code:

maruchan, Voinage, Zehd, mattrk, and le__
